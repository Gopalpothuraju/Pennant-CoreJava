package com.pennant.cricbuzz.cricketer;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;
import java.util.Set;

public class Cricketer {
	private String cricketerName;
	private int cricketerAge;
	private String cricketerCountry;
	private String cricketerTeam;
	private String typeOfCricketer;
	private int odiMatches;
	private int odiScore;
	private int bestInOdi;
	private int testMatches;
	private int testScore;
	private int bestInTest;
	private int t20Matches;
	private int t20Score;
	private int bestInT20;
	private float averageEconomyInBating;
	private int noOfWickets;
	private float averageEconomyInBowling;
	Scanner scanner = new Scanner(System.in);

	public Cricketer() {

	}

	public Cricketer(String cricketerName, int cricketerAge, String cricketerCountry, String cricketerTeam,
			String typeOfCricketer, int odiMatches, int odiScore, int bestInOdi, int testMatches, int testScore,
			int bestInTest, int t20Matches, int t20Score, int bestInT20, float averageEconomyInBating, int noOfWickets,
			float averageEconomyInBowling) {
		super();
		this.cricketerName = cricketerName;
		this.cricketerAge = cricketerAge;
		this.cricketerCountry = cricketerCountry;
		this.cricketerTeam = cricketerTeam;
		this.typeOfCricketer = typeOfCricketer;
		this.odiMatches = odiMatches;
		this.odiScore = odiScore;
		this.bestInOdi = bestInOdi;
		this.testMatches = testMatches;
		this.testScore = testScore;
		this.bestInTest = bestInTest;
		this.t20Matches = t20Matches;
		this.t20Score = t20Score;
		this.bestInT20 = bestInT20;
		this.averageEconomyInBating = averageEconomyInBating;
		this.noOfWickets = noOfWickets;
		this.averageEconomyInBowling = averageEconomyInBowling;
	}

	public String getCricketerName() {
		return cricketerName;
	}

	public int getCricketerAge() {
		return cricketerAge;
	}

	public String getCricketerCountry() {
		return cricketerCountry;
	}

	public String getCricketerTeam() {
		return cricketerTeam;
	}

	public String getTypeOfCricketer() {
		return typeOfCricketer;
	}

	public int getOdiMatches() {
		return odiMatches;
	}

	public int getOdiScore() {
		return odiScore;
	}

	public int getBestInOdi() {
		return bestInOdi;
	}

	public int getTestMatches() {
		return testMatches;
	}

	public int getTestScore() {
		return testScore;
	}

	public int getBestInTest() {
		return bestInTest;
	}

	public int getT20Matches() {
		return t20Matches;
	}

	public int getT20Score() {
		return t20Score;
	}

	public int getBestInT20() {
		return bestInT20;
	}

	public float getAverageEconomyInBating() {
		return averageEconomyInBating;
	}

	public int getNoOfWickets() {
		return noOfWickets;
	}

	public float getAverageEconomyInBowling() {
		return averageEconomyInBowling;
	}

	@Override
	public String toString() {
		return "Cricketer [cricketerName=" + cricketerName + ", cricketerAge=" + cricketerAge + ", cricketerCountry="
				+ cricketerCountry + ", cricketerTeam=" + cricketerTeam + ", typeOfCricketer=" + typeOfCricketer
				+ "\n , odiMatches=" + odiMatches + ", odiScore=" + odiScore + ", bestInOdi=" + bestInOdi
				+ "\n , testMatches=" + testMatches + ", testScore=" + testScore + ", bestInTest=" + bestInTest
				+ "\n , t20Matches=" + t20Matches + ", t20Score=" + t20Score + ", bestInT20=" + bestInT20
				+ "\n , averageEconomyInBating=" + averageEconomyInBating + ", noOfWickets=" + noOfWickets
				+ ", averageEconomyInBowling=" + averageEconomyInBowling + "]" + "\n";
	}

	public Set<Cricketer> countryWise(Set<Cricketer> values) {
		Set<Cricketer> teamWise = new HashSet<>();
		List<Cricketer> seting = new ArrayList<Cricketer>();
		seting.addAll(values);
		ListIterator<Cricketer> iterator = seting.listIterator();
		System.out.println("Enter team name :");
		String team = scanner.next();
		while (iterator.hasNext()) {
			Cricketer cricketer = (Cricketer) iterator.next();
			if (cricketer.getCricketerTeam().equalsIgnoreCase(team)) {
				teamWise.add(cricketer);
			}

		}

		return teamWise;

	}

	public Set<Cricketer> typeOfCricket(Set<Cricketer> cricketerDetails) {
		Set<Cricketer> typeWise = new HashSet<>();
		List<Cricketer> seting = new ArrayList<Cricketer>();
		seting.addAll(cricketerDetails);
		ListIterator<Cricketer> iterator = seting.listIterator();
		System.out.println("Enter type of cricketer(Batsman or Bowler) :");
		String typeOfCricket = scanner.next();
		while (iterator.hasNext()) {
			Cricketer cricketer = (Cricketer) iterator.next();
			if (cricketer.getTypeOfCricketer().equalsIgnoreCase(typeOfCricket)) {
				typeWise.add(cricketer);
			}
		}

		return typeWise;
	}

}
