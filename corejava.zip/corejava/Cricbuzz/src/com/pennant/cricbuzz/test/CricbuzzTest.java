package com.pennant.cricbuzz.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;
import java.util.Set;

import com.pennant.cricbuzz.cricketer.Cricketer;

public class CricbuzzTest {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		Cricketer cricter1=new Cricketer("Sachin", 48, "Indian", "Mumbai", "BatsMen", 190, 45600, 200, 60, 34800, 347, 160, 73000, 112, 126.7f, 20, 0.0f);
		Cricketer cricter2=new Cricketer("Rohit", 38, "Indian", "Mumbai", "BatsMen", 130, 15600, 264, 40, 4800, 247, 190, 61000, 122, 108.7f, 10, 0.0f);
		Cricketer cricter3=new Cricketer("Dhoni", 42, "Indian", "Chennai", "BatsMen", 150, 35600, 183, 80, 38800, 220, 120, 53000, 112, 97.7f, 0, 0.0f);
		Cricketer cricter4=new Cricketer("Raina", 46, "Indian", "Chennai", "BatsMen", 170, 15600, 140, 40, 14800, 217, 200, 23000, 112, 86.7f, 50, 0.0f);
		Cricketer cricter5=new Cricketer("Sehwag", 50, "Indian", "Delhi", "BatsMen", 110, 23600, 219, 60, 24800, 319, 110, 33000, 119, 127.3f, 80, 0.0f);
		
		Cricketer cricter6=new Cricketer("Bumhrah", 28, "Indian", "Mumbai", "Bowler", 190, 600, 60, 80, 4800, 77, 120, 1000, 32, 45.7f, 250, 7.8f);
		Cricketer cricter7=new Cricketer("Harbajan", 41, "Indian", "Chennai", "Bowler", 120, 800, 70, 80, 3800, 67, 80, 1000, 32, 67.7f, 350, 7.2f);
		Cricketer cricter8=new Cricketer("Zaheer Khan", 48, "Indian", "Delhi", "Bowler", 150, 1200, 80, 80, 4100, 37, 110, 1000, 32, 42.7f, 280, 6.8f);
		Cricketer cricter9=new Cricketer("Ashish Nehra", 45, "Indian", "Mumbai", "Bowler", 220, 1000, 90, 80, 6800, 87, 90, 1000, 32, 32.7f, 320, 6.5f);
		
		Cricketer cricter10=new Cricketer("AB Deviliers", 45, "South Africa", "Bengalore", "BatsMen", 140, 25600, 160, 60, 24800, 347, 160, 73000, 112, 120.7f, 450, 0.0f);
		Cricketer cricter11=new Cricketer("Smith", 42, "South Africa", "Rajasthan", "BatsMen", 190, 45600, 160, 60, 24800, 347, 160, 73000, 112, 146.7f, 450, 0.0f);
		Cricketer cricter12=new Cricketer("Decock", 28, "South Africa", "Mumbai", "BatsMen", 190, 45600, 123, 60, 36800, 347, 160, 73000, 112, 106.7f, 450, 0.0f);
	
		
		
		Set<Cricketer> cricketerDetails=new HashSet<>();
		cricketerDetails.add(cricter1);
		cricketerDetails.add(cricter2);
		cricketerDetails.add(cricter3);
		cricketerDetails.add(cricter4);
		cricketerDetails.add(cricter5);
		cricketerDetails.add(cricter6);
		cricketerDetails.add(cricter7);
		cricketerDetails.add(cricter8);
		cricketerDetails.add(cricter9);
		cricketerDetails.add(cricter10);
		cricketerDetails.add(cricter11);
		cricketerDetails.add(cricter12);
		
		Cricketer cric=new Cricketer();
		
		List<Cricketer> list=new ArrayList<Cricketer>();
		list.addAll(cricketerDetails);
		ListIterator<Cricketer> iterator=list.listIterator();
		System.out.println("Which details you want:\n  1.TeamWise \t 2.CricketerType \n 3.Highscore List \t 4.Most Wickets \n 5.Using Name \t 6.Best Scorer \n 7.Top Wickets \t 8.Best Strike Rate \n 9.Best Economy \t 10.Top Scorer \n 11.Exit");
		int option=scanner.nextInt();
		switch(option){
			
			case 1:Set<Cricketer> teamName=cric.countryWise(cricketerDetails);
				System.out.println(teamName);
				
				break;
			case 2:Set<Cricketer> typeWise=cric.typeOfCricket(cricketerDetails);
			System.out.println(typeWise);
				break;
			case 3:
			System.out.println("You want Top Score in (1.ODi 2.TEST 3.T20) ");
			int option1=scanner.nextInt();
			if(option1==1){
				Collections.sort(list,new Comparator<Cricketer>() {

				@Override
				public int compare(Cricketer o1, Cricketer o2) {
					
					return o2.getOdiScore()-o1.getOdiScore();
				}
			});
			}else if(option1==2){
				Collections.sort(list,new Comparator<Cricketer>() {

					@Override
					public int compare(Cricketer o1, Cricketer o2) {
						
						return o2.getTestScore()-o1.getTestScore();
					}
				});
			}else if(option1==3){
				Collections.sort(list,new Comparator<Cricketer>() {

					@Override
					public int compare(Cricketer o1, Cricketer o2) {
						
						return o2.getT20Score()-o1.getT20Score();
					}
				});
			}System.out.println(list);
				break;
			case 4:Collections.sort(list,new Comparator<Cricketer>() {

				@Override
				public int compare(Cricketer o1, Cricketer o2) {
					
					return o2.getNoOfWickets()-o1.getNoOfWickets();
				}
			});System.out.println(list);
				break;
			case 5:System.out.println("Enter Cricket Name :");
			String name=scanner.next();
			while (iterator.hasNext()) {
				Cricketer cricketer = (Cricketer) iterator.next();
				if(cricketer.getCricketerName().equalsIgnoreCase(name)){
					System.out.println(cricketer);
				}
			}
				break;
			case 6:int score=0;
			System.out.println("You want score in (1.ODI 2.TEST 3.T20)");
			option1=scanner.nextInt();
			if(option1==1){
				while (iterator.hasNext()) {
				Cricketer cricketer = (Cricketer) iterator.next();
				if(cricketer.getBestInOdi()>=score){
					score=cricketer.getBestInOdi();
				}
				}
				while (iterator.hasPrevious()) {
					Cricketer cricketer = (Cricketer) iterator.previous();
					if(cricketer.getBestInOdi()==score){
						System.out.println(cricketer);
					}
				}
			}else if(option1==2){
				score=0;
				while (iterator.hasNext()) {
					
					Cricketer cricketer = (Cricketer) iterator.next();
					if(cricketer.getBestInTest()>=score){
						score=cricketer.getBestInTest();
					}
					}
					while (iterator.hasPrevious()) {
						Cricketer cricketer = (Cricketer) iterator.previous();
						if(cricketer.getBestInTest()==score){
							System.out.println(cricketer);
						}
					}
			}else if(option1==3){
				score=0;
				while (iterator.hasNext()) {
					Cricketer cricketer = (Cricketer) iterator.next();
					if(cricketer.getBestInT20()>=score){
						score=cricketer.getBestInT20();
					}
					}
					while (iterator.hasPrevious()) {
						Cricketer cricketer = (Cricketer) iterator.previous();
						if(cricketer.getBestInT20()==score){
							System.out.println(cricketer);
						}
					}
			}
				break;
			case 7:int wickets=0;
			while (iterator.hasNext()) {
				Cricketer cricketer = (Cricketer) iterator.next();
				if(cricketer.getNoOfWickets()>=wickets){
					wickets=cricketer.getNoOfWickets();
				}
			}while (iterator.hasPrevious()) {
				Cricketer cricketer = (Cricketer) iterator.previous();
				if(cricketer.getNoOfWickets()==wickets){
					System.out.println(cricketer);
				}
			}
				break;
			case 8:float strikeRate=0;
			while (iterator.hasNext()) {
				Cricketer cricketer = (Cricketer) iterator.next();
				if(cricketer.getAverageEconomyInBating()>=strikeRate){
					strikeRate=cricketer.getAverageEconomyInBating();
				}
			}while (iterator.hasPrevious()) {
				Cricketer cricketer = (Cricketer) iterator.previous();
				if(cricketer.getAverageEconomyInBating()==strikeRate){
					System.out.println(cricketer);
				}
			}
				break;
			case 9:float economy=0;
			while (iterator.hasNext()) {
				Cricketer cricketer = (Cricketer) iterator.next();
				if(cricketer.getAverageEconomyInBowling()>=economy){
					economy=cricketer.getAverageEconomyInBowling();
				}
			}while (iterator.hasPrevious()) {
				Cricketer cricketer = (Cricketer) iterator.previous();
				if(cricketer.getAverageEconomyInBowling()==economy){
					System.out.println(cricketer);
				}
			}
				break;
			case 10:score=0;
			System.out.println("You want score in (1.ODI 2.TEST 3.T20)");
			option1=scanner.nextInt();
			if(option1==1){
				while (iterator.hasNext()) {
				Cricketer cricketer = (Cricketer) iterator.next();
				if(cricketer.getOdiScore()>=score){
					score=cricketer.getOdiScore();
				}
				}
				while (iterator.hasPrevious()) {
					Cricketer cricketer = (Cricketer) iterator.previous();
					if(cricketer.getOdiScore()==score){
						System.out.println(cricketer);
					}
				}
			}else if(option1==2){
				score=0;
				while (iterator.hasNext()) {
					
					Cricketer cricketer = (Cricketer) iterator.next();
					if(cricketer.getTestScore()>=score){
						score=cricketer.getTestScore();
					}
					}
					while (iterator.hasPrevious()) {
						Cricketer cricketer = (Cricketer) iterator.previous();
						if(cricketer.getTestScore()==score){
							System.out.println(cricketer);
						}
					}
			}else if(option1==3){
				score=0;
				while (iterator.hasNext()) {
					Cricketer cricketer = (Cricketer) iterator.next();
					if(cricketer.getT20Score()>=score){
						score=cricketer.getT20Score();
					}
					}
					while (iterator.hasPrevious()) {
						Cricketer cricketer = (Cricketer) iterator.previous();
						if(cricketer.getT20Score()==score){
							System.out.println(cricketer);
						}
					}
			}
				break;
			case 11:
				System.exit(0);
				break;
				default:
					break;
		}
		
		scanner.close();
	}

}
