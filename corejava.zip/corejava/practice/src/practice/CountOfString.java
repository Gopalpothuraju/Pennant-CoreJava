package practice;

public class CountOfString {

	public static void main(String[] args) {
		// String input="hi welcome to techouts";

		String input = "welcome to techouts and to the system test of techouts";
		String[] words = input.split("\\s");
		
		for (int i = 0; i < words.length; i++) {
			int count = 1;
			int flag = 0;
			for (int j = i+1; j < words.length; j++) {
				
				for (int k = j-1; k >= 0; k--) {
				
					if (words[k].equals(words[j])) {
						flag++;
						break;
					}
				}
				if (words[j].equals(words[i]) && flag ==0) {
					count++;
				}
			}
			if(flag==0){
			System.out.println(words[i] + "-" + count);
			}
		}
	}

}
