package practice;

import java.util.Scanner;

public class ArrayInsideArray {

	public static void main(String[] args) {
		int[] array1={12,25,3,68,8,5};
		int[] array2={9,256,36,89};
		int index;
		int value;
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter index");
		index=scanner.nextInt();
		if(index<0){
			System.out.println("Exception");
		}else if(index>array1.length){
			System.out.println("Exception");
		}else{
			value=array1[index];
			int m=0;
			int[] finalArray=new int[array1.length+array2.length];
			for (int i = 0; i < finalArray.length; i++) {
			
				if(index==i){
					for (int j = 0; j < array2.length; j++) {
						
						finalArray[i]=array2[j];
						i++;
					}
					
				}else{
				
					for (int j = m; j <array1.length; j++) {
						if(index==j){
							m++;
							i--;
							break;
						}else{
							finalArray[i]=array1[j];
							m++;
							i++;
						}
					}
					}
					
				}
				
			
			
			for (int i = 0; i < finalArray.length; i++) {
				if(finalArray[i]==0){
					finalArray[i]=value;
				}
				System.out.print(finalArray[i]+" ");
			}
		}
scanner.close();
	}

}
