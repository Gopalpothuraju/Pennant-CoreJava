package practice;

import java.util.Scanner;

public class WordSpecification {

	public static void main(String[] args) {
		String sentence = "Throw a stone in Techouts company it will hits the Hybris developer.";
		String word;
		int count = 0;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter any word");
		word = scanner.next();
		if (word.length() <= 3) {
			System.out.println("Exception");
		} else {
			String[] spaces = word.split("\\s");
			
			if (spaces.length > 1) {
				System.out.println("Exception");
				
			} else {
				String[] words = sentence.split("\\s");
				for (int j = 0; j < words.length; j++) {
					if (words[j].equals(word)) {
						count++;
						break;
					}
				}
				if (count != 0) {
					System.out.println("Yes," + word + " is present");
				} else {
					System.out.println("No," + word + " is not present");
				}
			}

		}

	scanner.close();
	}

}
