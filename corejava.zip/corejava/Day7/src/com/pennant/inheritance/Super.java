package com.pennant.inheritance;

public class Super {
int superOne;
int superTwo;
String name;

public Super(int superOne){
	super();
	this.superOne=superOne;
}
public Super() {
	super();
}
public Super(int superOne,int superTwo){
	super();
	this.superOne=superOne;
	this.superTwo=superTwo;
}
public Super(int superOne,int superTwo,String name){
	super();
	this.superOne=superOne;
	this.superTwo=superTwo;
	this.name=name;
}
public Super(String name){
	super();
	this.name=name;
}
public String getNames(){
	return "in super : "+name;
}
}
