package com.pennant.inheritance;

public class MainTest {

	public static void main(String[] args) {
		Super s=new Super("Gopal");
		System.out.println(s.getNames());
		SubClass sub=new SubClass("manikanta");
		System.out.println(sub.getNames());
	}

}
