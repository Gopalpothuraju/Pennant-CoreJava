package com.arrays;

import java.util.Scanner;

public class PrintingSubArray {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int[] array = { 12, 43, 67, 89, 76, 45, 32, 1 };
		System.out.println("Enter starting index");
		int startIndex = scanner.nextInt();
		System.out.println("Enter ending index");
		int endIndex = scanner.nextInt();
		if(startIndex < endIndex){
		if (startIndex>0 && endIndex<array.length) {
				int[] subArray=storingSubArray(array, startIndex, endIndex);
				System.out.println("Sub Array is : ");
				for(int i=0;i<subArray.length;i++){
					System.out.print(subArray[i]+" ");
				}
		} else {
			System.err.println("Your given position is not valid start index must be greater than 0 and end index must be"+array.length);
		}
		}else{
			System.err.println("your starting position must be less than ending position");
		}
		scanner.close();

	}

	public static int[] storingSubArray(int[] array, int startIndex, int endIndex) {
		int[] temporaryArray = new int[(endIndex-startIndex)+1];
		for(int i=0;i<temporaryArray.length;i++){
			temporaryArray[i]=array[startIndex+i];
		}
		return temporaryArray;

	}

}
