package com.oops.classndobject;

public class Employee {
	int id=344;
	String name="Gopal";
	String designation="Associate Software Engineer";
	double basicSalary=10000.00;
	double hra=250.00;
	double da=456.00;
	double lta=121.00;
	double pf=578.00;
	double tax=234.00;
	public void getDetails(){
		System.out.println("Employee Details");
		System.out.println(" ID is : "+id);
		System.out.println(" Name is : "+name);
		System.out.println(" Designation is : "+designation);
		
	}
	public void getSalary(){
		double totalSalary=basicSalary+hra+da+lta-pf-tax;
		System.out.println("Basic Salary is :"+basicSalary);
		System.out.println("HRA is : "+hra);
		System.out.println("DA is : "+da);
		System.out.println("LTA is : "+lta);
		System.out.println("PF is : "+pf);
		System.out.println("Income Tax is : "+tax);
		System.out.println("Total salary is : "+totalSalary);
	}
	public static void main(String[] args) {
		Employee emp1=new Employee();
		emp1.getDetails();
		emp1.getSalary();

	}

}
