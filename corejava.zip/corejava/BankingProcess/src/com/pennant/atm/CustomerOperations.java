package com.pennant.atm;

import com.pennant.accounts.AccountHolder;
import com.pennant.card.Card;

public interface CustomerOperations {

	void withDraw(Card cards,AccountHolder accountHolders);

	void transfer(Card[] cards, AccountHolder[] accountHolders,Card card,AccountHolder accountHolder) throws InterruptedException;

	void deposit(Card cards,AccountHolder accountHolders) throws InterruptedException;

}