package com.pennant.atm;

import com.pennant.accounts.AccountHolder;
import com.pennant.card.Card;

public interface AtmVerficationProcess {

	void getBalance(Card card, AccountHolder accountHolders);

}