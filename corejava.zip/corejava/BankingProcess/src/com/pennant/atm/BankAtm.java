package com.pennant.atm;

import java.util.Scanner;

import com.pennant.accounts.AccountHolder;
import com.pennant.card.Card;
import com.pennant.exceptions.DayLimitExceeded;
import com.pennant.exceptions.DuplicateAccountTypeException;
import com.pennant.exceptions.InSufficientFunds;
import com.pennant.exceptions.InputMissMatchException;
import com.pennant.exceptions.PinMissMatchException;

public class BankAtm implements AtmServices, CustomerOperations, AtmVerficationProcess {
	double amount = 0.0;

	Scanner scanner = new Scanner(System.in);

	@Override
	public void getBalance(Card cards, AccountHolder accountHolders) {

		if (accountHolders.getId().substring(0, 2).equalsIgnoreCase("SA")) {
			if (accountHolders.getBalance() >= 500) {
				System.out.println("Your Balnce is :" + accountHolders.getBalance());
			} else {
				try {
					System.out.println("Your Balnce is :" + accountHolders.getBalance());
					throw new InSufficientFunds();
				} catch (InSufficientFunds e) {
					System.err.println(e.getMessageInSavingsAccount());
				}
			}
		} else if (accountHolders.getId().substring(0, 2).equalsIgnoreCase("CA")) {
			if (accountHolders.getBalance() >= 2000) {
				System.out.println("Your Balnce is :" + accountHolders.getBalance());
			} else {
				try {
					System.out.println("Your Balnce is :" + accountHolders.getBalance());
					throw new InSufficientFunds();
				} catch (InSufficientFunds e) {
					System.err.println(e.getMessageInSavingsAccount());
				}
			}
		}
	}

	@Override
	public void withDraw(Card cards, AccountHolder accountHolders) {
		System.out.println("Enter amount : ");
		amount = scanner.nextDouble();
		if (amount % 100 == 0) {
			if (accountHolders.getId().substring(0, 2).equalsIgnoreCase("SA")) {
				double todayLimit = 0.0;

				if (todayLimit <= 10000 && amount <= 10000) {

					if (amount <= accountHolders.getBalance()) {
						System.out.println("please collect your cash..");
						accountHolders.setBalance(accountHolders.getBalance() - amount);
						todayLimit = todayLimit + amount;
					} else {
						try {
							throw new InSufficientFunds();
						} catch (InSufficientFunds e) {

							System.err.println(e.getAmountInsufficientInAccount());
						}
					}

				} else {
					try {
						throw new DayLimitExceeded();
					} catch (DayLimitExceeded e) {
						System.err.println(e.getDayLimitExceptionForSavingsAccount());
					}
				}
			} else if (accountHolders.getId().substring(0, 2).equalsIgnoreCase("CA")) {
				double todayLimit = 0.0;

				if (todayLimit <= 50000 && amount <= 50000) {

					if (amount <= accountHolders.getBalance()) {
						System.out.println("please collect your cash..");
						accountHolders.setBalance(accountHolders.getBalance() - amount);
						todayLimit = todayLimit + amount;
					} else {
						try {
							throw new InSufficientFunds();
						} catch (InSufficientFunds e) {

							System.err.println(e.getAmountInsufficientInAccount());
						}
					}

				} else {
					try {
						throw new DayLimitExceeded();
					} catch (DayLimitExceeded e) {
						System.err.println(e.getDayLimitExceptionForCurrentAccount());
					}
				}
			}
		} else {
			try {
				throw new InputMissMatchException();
			} catch (InputMissMatchException e) {
				System.err.println(e.getAmountMissMatchException());
			}
		}
	}

	@Override
	public void transfer(Card[] cards, AccountHolder[] accountHolders, Card card, AccountHolder accountHolder) throws InterruptedException {

		System.out.println("Transfer Using 1.Card \t 2.AccountNumber");
		int value = scanner.nextInt();
		if (value == 1) {

			System.out.println("Enter Payee Card Number");
			long payeeCardNumber = scanner.nextLong();
			System.out.println("Enter your mobile number");
			long mobileNumber = scanner.nextLong();

			if (payeeCardNumber == card.getCardNumber()) {
				try {
					throw new DuplicateAccountTypeException();
				} catch (DuplicateAccountTypeException ex) {
					System.err.println(ex.sameAccountType());
				}
			} else {
				if (mobileNumber == accountHolder.getMobileNumber()) {
					long searchPayee = 0;
					for (int i = 0; i < cards.length; i++) {
						if (cards[i].getCardNumber() == payeeCardNumber) {
							searchPayee = payeeCardNumber;
						}
					}
					if (searchPayee != 0) {
						System.out.println("Enter amount to transfer : ");
						amount = scanner.nextDouble();
						if (accountHolder.getId().substring(0, 2).equalsIgnoreCase("SA")) {
							if (amount < accountHolder.getBalance() && amount <= 100000) {
								Thread.sleep(1500);
									System.out.println("Your amount is transfered successfully...");
									accountHolder.setBalance(accountHolder.getBalance()-amount);
							}else{
								try {
									throw new InSufficientFunds();
								} catch (InSufficientFunds e) {
									System.err.println(e.getYOurTransferLimitException());
								}
							}
						}else if(accountHolder.getId().substring(0, 2).equalsIgnoreCase("CA")){
							if (amount < accountHolder.getBalance() && amount <= 500000) {
								Thread.sleep(1500);
									System.out.println("Your amount is transfered successfully...");
									accountHolder.setBalance(accountHolder.getBalance()-amount);
							}else{
								try {
									throw new InSufficientFunds();
								} catch (InSufficientFunds e) {
									System.err.println(e.getYOurTransferLimitException());
								}
							}
						}
					} else {
						try {
							throw new DuplicateAccountTypeException();
						} catch (DuplicateAccountTypeException e) {
							System.err.println(e.noAccountInDataBase());
						}
					}
				}else{
					try {
						throw new DuplicateAccountTypeException();
					} catch (DuplicateAccountTypeException e) {
						System.err.println("Your Mobile number is not matched..");
					}
				}
			}
		}

		else if (value == 2) {
			System.out.println("Enter Payee Account Number");
			long payeeAccountNumber = scanner.nextLong();
			System.out.println("Enter your mobile number");
			long mobileNumber = scanner.nextLong();

			if (payeeAccountNumber == accountHolder.getAccountNumber()) {
				try {
					throw new DuplicateAccountTypeException();
				} catch (DuplicateAccountTypeException e) {
					System.err.println(e.sameAccountType());
				}
			} else {
				if (mobileNumber == accountHolder.getMobileNumber()) {
					long searchPayee = 0;
					for (int i = 0; i < cards.length; i++) {
						if (accountHolders[i].getAccountNumber() == payeeAccountNumber) {
							searchPayee = payeeAccountNumber;
						}
					}
					if (searchPayee != 0) {
						System.out.println("Enter amount to transfer : ");
						amount = scanner.nextDouble();
						if (accountHolder.getId().substring(0, 2).equalsIgnoreCase("SA")) {
							if (amount < accountHolder.getBalance() && amount <= 100000) {
								Thread.sleep(1500);
									System.out.println("Your amount is transfered successfully...");
									accountHolder.setBalance(accountHolder.getBalance()-amount);
							}else{
								try {
									throw new InSufficientFunds();
								} catch (InSufficientFunds e) {
									System.err.println(e.getYOurTransferLimitException());
								}
							}
						}else if(accountHolder.getId().substring(0, 2).equalsIgnoreCase("CA")){
							if (amount < accountHolder.getBalance() && amount <= 500000) {
								Thread.sleep(1500);
									System.out.println("Your amount is transfered successfully...");
									accountHolder.setBalance(accountHolder.getBalance()-amount);
							}else{
								try {
									throw new InSufficientFunds();
								} catch (InSufficientFunds e) {
									System.err.println(e.getYOurTransferLimitException());
								}
							}
						}
					} else {
						try {
							throw new DuplicateAccountTypeException();
						} catch (DuplicateAccountTypeException e) {
							System.err.println(e.noAccountInDataBase());
						}
					}
				}else{
					try {
						throw new DuplicateAccountTypeException();
					} catch (DuplicateAccountTypeException e) {
						System.err.println("Your Mobile number is not matched..");
					}
				}
			}
		} else {
			try {
				throw new InputMissMatchException();
			} catch (InputMissMatchException e) {
				System.err.println(e.getTransferTypeMissMatchException());
			}
		}

	}

	@Override
	public void deposit(Card cards, AccountHolder accountHolders) throws InterruptedException {

		System.out.println("Please Insert only 100,200,500,2000");
		System.out.println("Please enter no of notes in 100:-(if no, enter 0)");
		int hunNotes = scanner.nextInt();
		System.out.println("Please enter no of notes in 200:-(if no, enter 0)");
		int twoHNotes = scanner.nextInt();
		System.out.println("Please enter no of notes in 500:-(if no, enter 0)");
		int fivHNotes = scanner.nextInt();
		System.out.println("Please enter no of notes in 2000:-(if no, enter 0)");
		int twTNotes = scanner.nextInt();
		System.out.println("calculating your notes....");
		Thread.sleep(1500);
		int notes = hunNotes + twoHNotes + fivHNotes + twTNotes;
		int amount = (hunNotes * 100) + (twoHNotes * 200) + (fivHNotes * 500) + (twTNotes * 2000);

		System.out.println("Total notes :" + notes);
		System.out.println("Total Amount : " + amount);
		System.out.println("Are you sure to conform the Transaction...");

		System.out.println("1.Conform \t 2.Cancel");
		int conformation = scanner.nextInt();

		if (conformation == 1) {
			System.out.println("please wait...\n your request is processing..");
			Thread.sleep(1500);
			System.out.println("Amount is deposited successfully..");
			accountHolders.setBalance(accountHolders.getBalance() + amount);
			System.out.println("please wait......\n Printing your receipt.");
			Thread.sleep(1500);

		} else if (conformation == 2) {
			System.err.println("your transaction is canceled..\n please collect your notes..");
		}

	}

	@Override
	public boolean pinChange(Card cards, AccountHolder accountHolders) throws InterruptedException {
		boolean flag = false;
		System.out.println("please Enter old PIN:");
		int oldPin = scanner.nextInt();
		Thread.sleep(1500);
		if (oldPin == cards.getPin()) {
			System.out.println("Enter new PIN:");
			int newPin = scanner.nextInt();
			Thread.sleep(1500);
			if(newPin>999 && newPin<=9999){
			System.out.println("conform your new PIN:");
			int reEnterNewPin = scanner.nextInt();
			if (newPin == reEnterNewPin) {
				Thread.sleep(1500);
				System.out.println(" your PIN changed Successfully");
				cards.setPin(newPin);
				flag = true;

			} else {

				try {
					throw new PinMissMatchException();
				} catch (PinMissMatchException e) {
					System.err.println(e.getPinMissMatchException());
				}

			}
		}else{
			try {
				throw new PinMissMatchException();
			} catch (PinMissMatchException e) {
				System.err.println(e.getPinLengthMissMatch());
			}
		}
		}else {

			try {
				throw new PinMissMatchException();
			} catch (PinMissMatchException e) {
				System.err.println(e.getPinMissMatchException());
			}
		}

		Thread.sleep(2000);
		return flag;

	}

}
