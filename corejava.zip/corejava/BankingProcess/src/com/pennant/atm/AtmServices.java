package com.pennant.atm;

import com.pennant.accounts.AccountHolder;
import com.pennant.card.Card;

public interface AtmServices {

	
	boolean pinChange(Card cards,AccountHolder accountHolders) throws InterruptedException;

}