package com.pennant.exceptions;

public class PinMissMatchException extends Exception {

	private static final long serialVersionUID = 1L;
	public PinMissMatchException() {
		// TODO Auto-generated constructor stub
	}
public String getPinMissMatchException(){
	return "Your Pin is Not matched..";
	}
public String getDailyLimitPinMissMatchException(){
	return "Daily limit for wrong is exceded..check after 24 hours";
	}
public String getPinLengthMissMatch(){
	return "Pin having 4 digits compulsory";
}
}
