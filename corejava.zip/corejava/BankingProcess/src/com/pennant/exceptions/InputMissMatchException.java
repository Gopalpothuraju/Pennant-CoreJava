package com.pennant.exceptions;

public class InputMissMatchException extends Exception {

	private static final long serialVersionUID = 1L;
	public InputMissMatchException() {
		// TODO Auto-generated constructor stub
	}
	public String getInputMissMatchException(){
		return "Selected input is miss match";
	}
	public String getAmountMissMatchException(){
		return "entered amount is not matched...only multiples of (100,200,500,2000)";
	}
	public String getTransferTypeMissMatchException(){
		return "current we are transfer process only card and acount only...";
	}
}
