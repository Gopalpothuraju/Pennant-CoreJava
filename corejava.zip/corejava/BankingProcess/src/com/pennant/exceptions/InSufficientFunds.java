package com.pennant.exceptions;

public class InSufficientFunds extends Exception {

	private static final long serialVersionUID = 1L;
	public InSufficientFunds() {
		
	}
	public String getMessageInSavingsAccount(){
		return "Please maintain minimum balance 500";
	}
	public String getAmountInsufficientInAccount(){
		return "insuffient balance in your account";
	}
	public String getMessageInCurrentAccount(){
		return "Please maintain minimum balance 2000";
	}
	public String getYOurTransferLimitException(){
		return "You crosed your limit or you doesnt minimum balnce(100000 per day)";
	}
}
