package com.pennant.exceptions;

public class DuplicateAccountTypeException extends Exception {

	private static final long serialVersionUID = 1L;
	public DuplicateAccountTypeException() {
		// TODO Auto-generated constructor stub
	}
	public String sameAccountType(){
		return "Payee details And Payer details are same ";
	}
	public String noAccountInDataBase(){
		return "Your Payee details are not matched in our data base";
	}
}
