package com.pennant.exceptions;

public class DayLimitExceeded extends Exception {

	
	private static final long serialVersionUID = 1L;
	public DayLimitExceeded() {
		// TODO Auto-generated constructor stub
	}
	public String getDayLimitExceptionForSavingsAccount(){
		return "your day limit is 10000 only";
	}
	public String getDayLimitExceptionForCurrentAccount(){
		return "your day limit is 50000  only";
	}
}
