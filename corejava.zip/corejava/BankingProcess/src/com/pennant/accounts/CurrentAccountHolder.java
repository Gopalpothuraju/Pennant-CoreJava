package com.pennant.accounts;

public class CurrentAccountHolder extends AccountHolder {
private int businessId;

private static double minimumBalance=2000;
public CurrentAccountHolder(String id,long accountNumber, String holderName, double balance, long mobileNumber, String govtId,
		int businessId) {
	super(id,accountNumber, holderName, balance, mobileNumber, govtId);
	this.businessId = businessId;
}
public double getMinimumBalance() {
	return minimumBalance;
}
public int getBusinessId() {
	return businessId;
}
@Override
	public void getDetails() {
		
		super.getDetails();
	}
}