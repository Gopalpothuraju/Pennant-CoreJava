package com.pennant.accounts;


public class SavingsAccountHolder extends AccountHolder{

private static double minimumBalance=500;
	public SavingsAccountHolder(String id,long accountNumber, String holderName, double balance, long mobileNumber,
			String govtId) {
		super(id,accountNumber, holderName, balance, mobileNumber, govtId);
		
	}
	public double getMinimumBalance() {
		return minimumBalance;
	}
	@Override
	public void getDetails() {
		
		super.getDetails();
	}

	

}
