package com.pennant.accounts;

public class AccountHolder {
private String id;
private long accountNumber;
private String holderName;
private double balance;
private long mobileNumber;
private String govtId;
public AccountHolder(String id,long accountNumber, String holderName, double balance, long mobileNumber, String govtId) {
	super();
	this.id=id;
	this.accountNumber = accountNumber;
	this.holderName = holderName;
	this.balance = balance;
	this.mobileNumber = mobileNumber;
	this.govtId = govtId;
}
public String getId(){
	return id;
}


public long getAccountNumber() {
	return accountNumber;
}
public String getHolderName() {
	return holderName;
}
public double getBalance() {
	return balance;
}
public long getMobileNumber() {
	return mobileNumber;
}
public String getGovtId() {
	return govtId;
}

public void setBalance(double balance) {
	this.balance = balance;
}
//public abstract void getAmount(double balance);
public void getDetails(){
	System.out.println("Account Number : "+accountNumber);
	System.out.println("Account Holder Name : "+holderName);
	System.out.println("Mobile Number :"+mobileNumber);
	System.out.println("Balance :"+balance);
}
}
