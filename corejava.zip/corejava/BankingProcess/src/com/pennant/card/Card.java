package com.pennant.card;

public class Card {
private long cardNumber;
private String cardType;
private int cvv;
private int expiryDate;
private int pin;
public Card(long cardNumber, String cardType, int cvv, int expiryDate, int pin) {
	super();
	this.cardNumber = cardNumber;
	this.cardType = cardType;
	this.cvv = cvv;
	this.expiryDate = expiryDate;
	this.pin = pin;
}
public long getCardNumber() {
	return cardNumber;
}
public String getCardType() {
	return cardType;
}
public int getCvv() {
	return cvv;
}
public int getExpiryDate() {
	return expiryDate;
}
public int getPin() {
	return pin;
}
public void setPin(int pin){
	this.pin=pin;
}
}
