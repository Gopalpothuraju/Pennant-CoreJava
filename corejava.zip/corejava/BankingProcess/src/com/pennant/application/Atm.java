package com.pennant.application;

import java.util.Scanner;

import com.pennant.accounts.AccountHolder;
import com.pennant.accounts.CurrentAccountHolder;
import com.pennant.accounts.SavingsAccountHolder;
import com.pennant.atm.BankAtm;
import com.pennant.card.Card;
import com.pennant.exceptions.InputMissMatchException;
import com.pennant.exceptions.PinMissMatchException;

public class Atm {
	public static void main(String[] args) throws InterruptedException {
		Scanner scanner = new Scanner(System.in);
		Card[] cards = new Card[10];
		cards[0] = new Card(6902091003015536l, "Rupay", 861, 1224, 9899);
		cards[1] = new Card(6902091003321236l, "Rupay", 212, 1222, 5676);
		cards[2] = new Card(6902234454656677l, "Rupay", 898, 1022, 5432);
		cards[3] = new Card(6902432565767658l, "Rupay", 213, 1226, 1234);
		cards[4] = new Card(6902133467889090l, "Rupay", 777, 1024, 4444);
		cards[5] = new Card(6902090909887653l, "Rupay", 132, 1026, 5555);
		cards[6] = new Card(6902023469322468l, "Rupay", 342, 1220, 1111);
		cards[7] = new Card(6902091345566578l, "Rupay", 234, 1020, 7777);
		cards[8] = new Card(6902091454367888l, "Rupay", 909, 1124, 0000);
		cards[9] = new Card(6902093543657889l, "Rupay", 543, 1226, 2222);
		AccountHolder[] accountHolders = new AccountHolder[10];
		accountHolders[0] = new SavingsAccountHolder("SA1003", 100310100056769l, "Gopal", 600, 9908922714l, "CDE343");
		accountHolders[1] = new SavingsAccountHolder("SA1003", 100310100056770l, "Mani", 200, 7756878l, "CSF323");
		accountHolders[2] = new SavingsAccountHolder("SA1003", 100314345667778l, "Chandu", 2000, 77524556l, "CSXD309");

		accountHolders[3] = new SavingsAccountHolder("SA1003", 100310100056771l, "Ravi", 1600, 99084433714l, "CEG941");
		accountHolders[4] = new SavingsAccountHolder("SA1003", 100310100056772l, "Gopi", 8600, 990892354l, "DEA432");

		accountHolders[5] = new CurrentAccountHolder("CA1112", 111210100056319l, "Sachin", 45678, 4546543746l,
				"SWE4342", 456);
		accountHolders[6] = new CurrentAccountHolder("CA1112", 111210100325559l, "Dhoni", 34590, 4546543746l, "SQT1452",
				457);
		accountHolders[7] = new CurrentAccountHolder("CA1112", 111210100034589l, "Rohit", 12345, 4546543746l, "SWG543",
				458);
		accountHolders[8] = new CurrentAccountHolder("CA1112", 111210100067769l, "Dhawan", 20000, 4546543746l,
				"SWB6542", 459);
		accountHolders[9] = new CurrentAccountHolder("CA1112", 111210100053249l, "Hardik", 90000, 4546543746l, "SWM342",
				460);

		Object[][] mapping = new Object[cards.length][2];
		for (int i = 0; i < cards.length; i++) {
			for (int j = 0; j < 2; j++) {
				if (j == 0) {
					mapping[i][j] = cards[i];
				} else if (j == 1) {
					mapping[i][j] = accountHolders[i];
				}
			}

		}

		BankAtm atm = new BankAtm();
		boolean flag = true;

		System.out.println("Enter your card..");
		Thread.sleep(1500);
		System.out.println("Please enter your PIN : ");
		int pin = scanner.nextInt();
		int count = 0;

		for (int i = 0; i < cards.length; i++) {
			if (pin == cards[i].getPin()) {
				count++;
				while (flag) {
					System.out.println(
							"1.WithDraw \t 2.Deposit \n 3.Pin Change \t 4.Transfer\t 5.Check Balance \n 6.Exit");
					int option = scanner.nextInt();
					switch (option) {
					case 1:
						atm.withDraw(cards[i], accountHolders[i]);
						System.out.println("Do you want to check balance \n 1.Yes \n 2. No");
						int value = scanner.nextInt();
						Thread.sleep(1500);
						if (value == 1) {
							atm.getBalance(cards[i], accountHolders[i]);
						} else {
							flag = false;
							System.out.println("Thank You ...Visit again..!");
						}

						break;
					case 2:
						atm.deposit(cards[i], accountHolders[i]);
						System.out.println("Do you want to check balance \n 1.Yes \n 2. No");
						value = scanner.nextInt();
						Thread.sleep(1500);
						if (value == 1) {
							Thread.sleep(1500);
							atm.getBalance(cards[i], accountHolders[i]);
						} else {
							flag = false;
							System.out.println("Thank You ...Visit again..!");
						}
						break;
					case 3:
						int limit = 0;
						while (limit <= 3) {
							if (atm.pinChange(cards[i], accountHolders[i])) {
								limit = 4;
							} else {
								limit++;
							}
						}
						break;
					case 4:
						atm.transfer(cards, accountHolders, cards[i], accountHolders[i]);
						System.out.println("Do you want to check balance \n 1.Yes \n 2. No");
						value = scanner.nextInt();
						Thread.sleep(1500);
						if (value == 1) {
							Thread.sleep(1500);
							atm.getBalance(cards[i], accountHolders[i]);
						} else {
							flag = false;
							System.out.println("Thank You ...Visit again..!");
						}
						break;
					case 5:
						atm.getBalance(cards[i], accountHolders[i]);
						System.out.println("Do u want to continue \n1.Yes \t 2.No");
						value = scanner.nextInt();
						if (value == 1) {
							flag = true;
						} else {
							flag = false;
							System.out.println("Thank You ...Visit again..!");
						}
						break;
					case 6:
						System.exit(0);
						break;
					default:
						try {
							throw new InputMissMatchException();
						} catch (InputMissMatchException e) {

							System.err.println(e.getInputMissMatchException());
						}
						break;
					}
					break;
				}

			}

		}
		scanner.close();
		if (count == 0) {
			try {
				throw new PinMissMatchException();
			} catch (PinMissMatchException e) {

				System.err.println(e.getPinMissMatchException());
			}
		}

	}
}
