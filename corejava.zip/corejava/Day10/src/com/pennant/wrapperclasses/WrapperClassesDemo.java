package com.pennant.wrapperclasses;

public class WrapperClassesDemo {
public static void main(String[] args) {
	System.out.println("--primitive to object--");
	int i=10;
	Integer k=i;
	System.out.println("data type : "+i);
	System.out.println("convert to object : "+k);
	
	System.out.println("--object to primitive--");
	Integer j=20;
	int i1=j;
	System.out.println("Object : "+j);
	System.out.println("convert to data type : "+i1);
}
}
