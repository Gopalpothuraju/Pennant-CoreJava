package com.pennant.exceptions;

import java.util.Scanner;

public class UncheckedExceptionsDemo {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		try{
		System.out.println("Enter two values ");
		int numberOne=scanner.nextInt();
		int numberTwo=scanner.nextInt();
		System.out.println("Divison value "+(numberOne/numberTwo));
		
		String string1=null;
		
		if(string1==null){
			throw new StringException();
		}
		}catch(ArithmeticException e){
			System.err.println("Number cannot be divided by zero..");
		} catch (StringException e) {
			
		}
		
		finally{
			System.out.println("finally executed");
			scanner.close();
		}
	}

}
