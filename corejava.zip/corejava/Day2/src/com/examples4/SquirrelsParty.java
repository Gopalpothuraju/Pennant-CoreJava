package com.examples4;

import java.util.Scanner;


public class SquirrelsParty {

	public static void main(String[] args) {
	boolean weekDay;
	Scanner sc=new Scanner(System.in);
	System.out.println("its weekday (true/false)");
	weekDay=sc.nextBoolean();
	System.out.println("Enter number of cigars");
	int numberOfCigars=sc.nextInt();
	if(weekDay){
		if(numberOfCigars>=40 && numberOfCigars<=60){
			System.out.println("SUCCESS");
		}else{
			System.out.println("NOT SUCCESS");
		}
	}else {
		if(numberOfCigars>=40){
			System.out.println("SUCCESS");
		}else{
			System.out.println("NOT SUCCESS");
		}
	}
sc.close();
	}

}
