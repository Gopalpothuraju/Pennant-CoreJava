package com.conditionalstatements;

import java.util.Scanner;

public class CropLoan {
public static void main(String[] args) {
	int loanAmount;
	Scanner sc=new Scanner(System.in);
	loanAmount=sc.nextInt();
	if(loanAmount<=100000){
		loanAmount=0;
	}
	System.out.println("Your loan amount is:"+loanAmount);
	sc.close();
}
}
