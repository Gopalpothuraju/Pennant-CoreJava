package com.conditionalstatements;

import java.util.Scanner;

public class AbsoluteNumber {
public static void main(String[] args) {
	int number;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter number");
	number=sc.nextInt();
	if(number<0){
		number=-number;
	}
	System.out.println("absolute number is : "+number);
	sc.close();
}
}
