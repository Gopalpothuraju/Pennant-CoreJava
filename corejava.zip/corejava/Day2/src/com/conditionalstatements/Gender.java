package com.conditionalstatements;

import java.util.Scanner;

public class Gender {

	public static void main(String[] args) {
		String gender;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Gender");
		gender = sc.next();
		if (gender.charAt(0) == 'M' || gender.charAt(0) == 'm') {
			System.out.println("Gender is male");
		} else if (gender.charAt(0) == 'F' || gender.charAt(0) == 'f') {
			System.out.println("Gender is female");
		}else{
			System.out.println("its transgender");
		}
sc.close();
	}

}
