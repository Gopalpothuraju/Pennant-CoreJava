package com.conditionalstatements;

import java.util.Scanner;

public class MatchResult {

	public static void main(String[] args) {
		int team1Score=360;
		int team2Score;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter team 2 score score");
		team2Score=sc.nextInt();
		if(team2Score > team1Score){
			System.out.println("Team 2 is win");
		}else if(team2Score==team1Score){
			System.out.println("match is tie");
		}else{
			System.out.println("Team 1 is win");
		}
sc.close();
	}

}
