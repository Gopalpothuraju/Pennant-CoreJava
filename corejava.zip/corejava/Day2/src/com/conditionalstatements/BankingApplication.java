package com.conditionalstatements;

import java.util.Scanner;

public class BankingApplication {

	public static void main(String[] args) {
		int optionIndex;
		int damount=100;
		Scanner sc = new Scanner(System.in);
		System.out.println("Select your option");
		System.out.println("1.Deposit \t 2.WithDraw \n 3.Balance Enquiry \t 4.Mini Statement");
		optionIndex = sc.nextInt();
		switch (optionIndex) {
		case 1:
			System.out.println("Enter your amount to deposit");
			damount = sc.nextInt()+damount;
			System.out.println("amount is deposited");
			break;
		case 2:System.out.println("Enter amount to withdrawl");
		int wamount=sc.nextInt();
		if(damount>wamount){
		int remainingAmount=damount-wamount;
		System.out.println("Remaining amount is"+remainingAmount);
		}else{
			System.out.println("Insuffient Amount"+damount);
		}
		break;
		case 3:
			System.out.println("Your account balance is"+damount);
			break;
		case 4 : System.out.println("collect receipt");
		break;
		default : System.out.println("Please select above options only...");
		break;
		}
		sc.close();
	}

}
