package com.conditionalstatements;

import java.util.Scanner;

public class WithdrawMoney {

	public static void main(String[] args) {
		int balance=5000;
		int withDrawAmount;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter withdraw amount");
		withDrawAmount=sc.nextInt();
		if(withDrawAmount<balance){
			System.out.println("collect your cash");
			System.out.println("remaining balance is"+(balance-withDrawAmount));
		}else{
			System.out.println("Sorry..insufficient balance");
			System.out.println("your balance is"+balance);
		}
sc.close();
	}

}
