package com.conditionalstatements;

import java.util.Scanner;

public class Calculator {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number one");
		int numberOne = sc.nextInt();
		System.out.println("Enter number two");
		int numberTwo = sc.nextInt();

		System.out.println("Addition(+) \n Substraction(-) \n Multiplication(*) \n Division(/) \n modulos(%) ");
		System.out.println("Select your appropiate option");
		String option = sc.next();
		char choice = option.charAt(0);
		switch (choice) {
		case '+':
			System.out.println("Addition of given 2 numbers is : " + (numberOne + numberTwo));
			break;
		case '-':
			System.out.println("Substraction of given 2 numbers is : " + (numberOne - numberTwo));
			break;
		case '*':
			System.out.println("Multiplication of given 2 numbers is : " + (numberOne * numberTwo));
			break;
		case '/':
			System.out.println("Divison of given 2 numbers is : " + (numberOne / numberTwo));
			break;
		case '%':
			System.out.println("Remainder  of given 2 numbers is : " + (numberOne % numberTwo));
			break;
		default:
			System.out.println("please select above options only.........");
			break;
		}
		sc.close();

	}

}
