package com.pennant.jdbc.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.pennant.jdbc.employeedetails.Employee;

public class DataBaseConnection {
public static void main(String[] args)  {
	List<Employee> employeeList=new ArrayList<>();
	Scanner scanner=new Scanner(System.in);
	Connection connection=null;
	System.out.println("1.Insert 2.Delete 3.Update 4.Retreive");
	System.out.println("Enter your option: ");
	int option=scanner.nextInt();
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		 connection = DriverManager.getConnection("jdbc:oracle:thin:@192.168.1.27:1521:orcl", "DB344", "pass123");
		Statement createStatement = connection.createStatement();
		
		if(option==1){
			System.out.println("Enter employee details(id,name,salary,address)");
			int id=scanner.nextInt();
			String name=scanner.next();
			double salary=scanner.nextDouble();
			String address=scanner.next();
			int executeUpdate = createStatement.executeUpdate("insert into employee values("+id+",'"+name+"',"+salary+",'"+address+"')");
			System.out.println(executeUpdate+"rows effected");
		}else if(option==2){
			System.out.println("Select an option to delete employee...\n(1.Id \t 2.Name)");
			int value=scanner.nextInt();
			if(value==1){
			System.out.println("Enter employee id to delete : ");
			int id=scanner.nextInt();
			int executeUpdate = createStatement.executeUpdate("delete from employee where id="+id+"");
			System.out.println(executeUpdate+"rows effected");
			}else if(value==2){
				System.out.println("Enter employee name to delete : ");
				String name=scanner.next();
				int executeUpdate = createStatement.executeUpdate("delete from employee where name='"+name+"'");
				System.out.println(executeUpdate+"rows effected");
			}
		}else if(option==3){
			System.out.println("Enter id to update details..");
			int id=scanner.nextInt();
			System.out.println("Which data youv want to modify \t 1.name \t 2.salary \t 3.address");
			int value=scanner.nextInt();
			if(value==1){
				System.out.println("Enter name to modify");
				String name=scanner.next();
			
				int executeUpdate = createStatement.executeUpdate("update employee set name='"+name+"' where id="+id+"");
				System.out.println(executeUpdate+"rows effected");
			}else if(value==2){
				System.out.println("Enter salary to modify");
				int salary=scanner.nextInt();
			
				int executeUpdate = createStatement.executeUpdate("update employee set location="+salary+" where id="+id+"");
				System.out.println(executeUpdate+"rows effected");
			}else if(value==3){
				System.out.println("Enter location to modify");
				String address=scanner.next();
			
				int executeUpdate = createStatement.executeUpdate("update employee set location='"+address+"' where id="+id);
				System.out.println(executeUpdate+"rows effected");
			}
			
		}else if(option==4){
			ResultSet executeQuery = createStatement.executeQuery("select * from employee");
			while(executeQuery.next()){
				Employee employee=new Employee(executeQuery.getInt(1), executeQuery.getString(2), executeQuery.getDouble(3), executeQuery.getString(4));
				employeeList.add(employee);
			}
			Employee.displayEmployees(employeeList);
		}
	} catch (ClassNotFoundException e) {
		e.printStackTrace();
	} catch (SQLException e) {
		e.printStackTrace();
	}
	finally {
		try {
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		scanner.close();
	}
}
}
