package com.pennant.jdbc.employeedetails;

import java.util.List;

public class Employee {
	private int id;
	private String name;
	private double salary;
	private String address;
     
	public Employee(int id, String name, double salary, String address) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.address = address;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public static void displayEmployees(List<Employee> list) {
		System.out.println("===Employee Details===");
		System.out.println("Employe Id \t Employee Name \t Salary \t Address");
		System.out.println("----------------------------------------------------------");
		for (Employee employee : list) {
			System.out.println(employee.getId()+" \t \t  "+employee.getName()+"\t \t  "+employee.getSalary()+" \t "+employee.getAddress());
		}
		
	}
}
