package com.pennant.synchronization;

public class MyThreadDemo implements Runnable {
	int a;
	int b;
	public MyThreadDemo(int a,int b) {
		// TODO Auto-generated constructor stub
		this.a=a;
		this.b=b;
	}
/*public  void addition(){
	for (int i = 0; i < 10; i++) {
		int c=(a*i)+(i*b);
		System.out.println(Thread.currentThread().getName()+"\t "+c);
	}
}
public synchronized void multiplication(){
	for (int i = 0; i < 10; i++) {
		int c=(a*i)*(i*b);
		System.out.println(Thread.currentThread().getName()+"\t "+c);
	}
}*/
	
/*	
	public void objectLevellock(){
		for (int i = 0; i < 10; i++) {
			System.out.println(Thread.currentThread().getName());
		}
		synchronized (this) {
			for (int i = 0; i < 10; i++) {
				System.out.println(Thread.currentThread().getName()+"\t"+i);
			}
		}
	}
@Override
public void run() {
	// TODO Auto-generated method stub
	this.objectLevellock();
}*/
	
	public void classLevelLock(){
		for (int i = 0; i < 10; i++) {
			System.out.println(Thread.currentThread().getName());
		}
		synchronized (MyThreadDemo.class) {
			for (int i = 0; i < 10; i++) {
				System.out.println(Thread.currentThread().getName()+"\t"+i);
			}
		}
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		this.classLevelLock();
	}
}
