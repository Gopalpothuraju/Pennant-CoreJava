package com.pennant.annotations;

import java.lang.reflect.Method;

public class Test {

	public static void main(String[] args) throws NoSuchMethodException, SecurityException {
		// TODO Auto-generated method stub
		System.out.println("====Marker Annotation ====");
		MarkerClass mc=new MarkerClass();
		Method m1=mc.getClass().getMethod("info");
		MarkerAnnotation ma=m1.getAnnotation(MarkerAnnotation.class);
		System.out.println(ma);
		//System.out.println("value"+ma.hashCode());
		System.out.println("====Single Value Annotation ====");
		SingleAnnotationClass sva=new SingleAnnotationClass();
		Method m2=sva.getClass().getMethod("userValue");
		SingleValueAnnotation sv=m2.getAnnotation(SingleValueAnnotation.class);
		System.out.println("value is : "+sv.value());
		System.out.println("===Default Values===");
		Method m3=sva.getClass().getMethod("defaultValue");
		SingleValueAnnotation sv1=m3.getAnnotation(SingleValueAnnotation.class);
		System.out.println("value is : "+sv1.value());
		
		System.out.println("====Multi Value Annotation ====");
		
		MultiAnnotationClass mac=new MultiAnnotationClass();
		Method m4=mac.getClass().getMethod("details");
		MultiAnnotation mua=m4.getAnnotation(MultiAnnotation.class);
		System.out.println("Value :"+mua.value()+" Name : "+mua.name());
		System.out.println("===Default Values===");
		
		Method m5=mac.getClass().getMethod("details1");
		mua=m5.getAnnotation(MultiAnnotation.class);
		System.out.println("Value :"+mua.value()+" Name : "+mua.name());
	}

}
