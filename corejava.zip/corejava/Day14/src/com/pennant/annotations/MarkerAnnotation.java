package com.pennant.annotations;

public @interface MarkerAnnotation {

}
