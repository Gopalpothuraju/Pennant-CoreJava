package com.pennant.annotations;

public class MultiAnnotationClass {
	@MultiAnnotation(name = "gopal", value = 344)
public void details(){
	System.out.println("Its is multi value annotation");
}
	
	@MultiAnnotation(name = "", value = 0)
	public void details1(){
		System.out.println("Its is multi value annotation for default");
	}
}
