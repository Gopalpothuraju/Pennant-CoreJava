package com.pennant.annotations;


@MarkerAnnotation
public class MarkerClass {
	
	public void info(){
		System.out.println("Marker annotation...");
		
	}
	
}
