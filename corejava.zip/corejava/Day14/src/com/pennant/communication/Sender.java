package com.pennant.communication;

public class Sender implements Runnable {
	Chat chat;
	String[] string = { "Hai", "Good morning", "Ok Bye" };

	public Sender(Chat chat) {
		this.chat = chat;
		new Thread(this, "Sender").start();
	}

	@Override
	public void run() {
		for (int i = 0; i < string.length; i++) {
			chat.getQuestion(string[i]);
		}

	}

}
