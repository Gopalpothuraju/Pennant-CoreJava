package com.pennant.comparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Test {
public static void main(String[] args) {
	Employee empOne=new Employee(344, "Gopal", 12500.00);

	Employee empTwo=new Employee(345, "Hari", 112500.00);

	Employee empThree=new Employee(346, "Gopi", 98500.00);

	Employee empFour=new Employee(374, "Narendra", 6500.00);

	Employee empFive=new Employee(494, "Mani", 62500.00);

	Employee empSix=new Employee(220, "Varma", 19500.00);
	Scanner scanner=new Scanner(System.in);
	List<Employee> listData=new ArrayList<Employee>();
	listData.add(empOne);
	listData.add(empTwo);
	listData.add(empThree);
	listData.add(empFour);
	listData.add(empFive);
	listData.add(empSix);
	
	System.out.println("Enter which type of order you want : \n 1.Id \t 2.Name \t 3.Salary");
	int option=scanner.nextInt();
	
	switch(option){
	case 1:
	
		Collections.sort(listData,new Comparator<Employee>() {

			@Override
			public int compare(Employee o1, Employee o2) {
				return o1.getEmpId()-o2.getEmpId();
			}
		});
		System.out.println(listData);
		break;
	case 2:
		Collections.sort(listData,new Comparator<Employee>() {

			@Override
			public int compare(Employee o1, Employee o2) {
				return o1.getEmpname().compareTo(o2.getEmpname());
			}
		});
		System.out.println(listData);
		break;
	case 3:
		Collections.sort(listData,new Comparator<Employee>() {

			@Override
			public int compare(Employee o1, Employee o2) {
				return (int) (o1.getSalary()-o2.getSalary());
			}
		});
		System.out.println(listData);
		break;
	}
scanner.close();
}
}
