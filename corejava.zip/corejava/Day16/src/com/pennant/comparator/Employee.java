package com.pennant.comparator;

public class Employee {
private int empId;
private String empname;
private double salary;
public Employee(int empId, String empname, double salary) {
	super();
	this.empId = empId;
	this.empname = empname;
	this.salary = salary;
}
public int getEmpId() {
	return empId;
}
public String getEmpname() {
	return empname;
}
public double getSalary() {
	return salary;
}
@Override
public String toString() {
	return "Employee [empId=" + empId + ", empname=" + empname + ", salary=" + salary + "] \n";
}

}
