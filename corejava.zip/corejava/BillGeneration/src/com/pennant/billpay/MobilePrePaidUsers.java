package com.pennant.billpay;

public class MobilePrePaidUsers extends MobileSubscriber{
	private long voucherId;
	private int voucherAmount;

	public MobilePrePaidUsers(String subscriberName, int subscriberId, long subscriberPhoneNumber, long voucherId,
			int voucherAmount) {
		super(subscriberName, subscriberId, subscriberPhoneNumber);
		this.voucherId = voucherId;
		this.voucherAmount = voucherAmount;
	}
	public long getVoucherId() {
		return voucherId;
	}
	public int getVoucherAmount() {
		return voucherAmount;
	}
	@Override
	public void getMobilePrepaidUserDetails() {
		System.out.println("==========Subscriber Details===============");
		System.out.println("===You are Mobile Prepaid User===");
		super.getMobilePrepaidUserDetails();
	}
public double talkTime(){
	double talkTime=0;
	if(voucherAmount==222){
		talkTime=voucherAmount;
	}else{
	 talkTime=voucherAmount-(voucherAmount*2)/100;
	}
	return talkTime;
}
public double turnOverForMobilePrePaidUsers(double[] totalBillForPrePaid) {
	double turnOver = 0;
	for (int i = 0; i < totalBillForPrePaid.length; i++) {
		turnOver = turnOver + totalBillForPrePaid[i];
	}
	return turnOver;
	
}
	

}
