package com.pennant.billpay;

public class LandLineSubscriber extends Subscriber {
	private int noOfSTDCallsInMinutes;
	private double costPerEachSTDInMinute;

	public LandLineSubscriber(String subscriberName, int subscriberId, long subscriberPhoneNumber,
			String subscriberPlanName, int subscriberFreeCalls, double subscriberPlanCost,
			int subscriberExtraCallsInMinutes, double subscriberExtraCallCostPerMinute, int noOfSTDCallsInMinutes,
			double costPerEachSTDInMinute) {
		super(subscriberName, subscriberId, subscriberPhoneNumber, subscriberPlanName, subscriberFreeCalls,
				subscriberPlanCost, subscriberExtraCallsInMinutes, subscriberExtraCallCostPerMinute);
		this.noOfSTDCallsInMinutes = noOfSTDCallsInMinutes;
		this.costPerEachSTDInMinute = costPerEachSTDInMinute;
	}

	public int getNoOfSTDCallsInMinutes() {
		return noOfSTDCallsInMinutes;
	}

	public double getCostPerEachSTDInMinute() {
		return costPerEachSTDInMinute;
	}

	@Override
	public void getSubscriberDetails() {
		System.out.println("==========Subscriber Details===============");
		System.out.println("===You are LandLine User===");
		super.getSubscriberDetails();
		System.out.println("STD/mins       : " + noOfSTDCallsInMinutes);
		System.out.println("Cost/STDC      : " + costPerEachSTDInMinute);
	}

	public double generateBill() {
		double bill = 0;

		bill = getSubscriberPlanCost() + (getSubscriberExtraCallsInMinutes() * getSubscriberExtraCallCostPerMinute())
				+ (noOfSTDCallsInMinutes * costPerEachSTDInMinute);
		bill = bill + ((bill * 10) / 100);

		return bill;
	}



	public double turnOverForLandLineUsers(double[] totalBill) {
		double turnOver = 0;
		for (int i = 0; i < totalBill.length; i++) {
			turnOver = turnOver + totalBill[i];
		}
		return turnOver;
	}
}
