package com.pennant.billpay;

public class Subscriber {
	private String subscriberName;
	private int subscriberId;
	private long subscriberPhoneNumber;
	private String subscriberPlanName;
	private int subscriberFreeCalls;
	private double subscriberPlanCost;
	private int subscriberExtraCallsInMinutes;
	private double subscriberExtraCallCostPerMinute;
	private double subscriberTaxOnBill;


	public Subscriber(String subscriberName, int subscriberId, long subscriberPhoneNumber, String subscriberPlanName,
			int subscriberFreeCalls, double subscriberPlanCost, int subscriberExtraCallsInMinutes,
			double subscriberExtraCallCostPerMinute) {
		super();
		this.subscriberName = subscriberName;
		this.subscriberId = subscriberId;
		this.subscriberPhoneNumber = subscriberPhoneNumber;
		this.subscriberPlanName = subscriberPlanName;
		this.subscriberFreeCalls = subscriberFreeCalls;
		this.subscriberPlanCost = subscriberPlanCost;
		this.subscriberExtraCallsInMinutes = subscriberExtraCallsInMinutes;
		this.subscriberExtraCallCostPerMinute = subscriberExtraCallCostPerMinute;

	}
	public Subscriber(String subscriberName,int subscriberId,long subscriberPhoneNumber){
		this.subscriberName=subscriberName;
		this.subscriberId=subscriberId;
		this.subscriberPhoneNumber=subscriberPhoneNumber;
	}
	public String getSubscriberName() {
		return subscriberName;
	}

	public int getSubscriberId() {
		return subscriberId;
	}

	public long getSubscriberPhoneNumber() {
		return subscriberPhoneNumber;
	}

	public String getSubscriberPlanName() {
		return subscriberPlanName;
	}

	public int getSubscriberFreeCalls() {
		return subscriberFreeCalls;
	}

	public double getSubscriberPlanCost() {
		return subscriberPlanCost;
	}

	public int getSubscriberExtraCallsInMinutes() {
		return subscriberExtraCallsInMinutes;
	}

	public double getSubscriberExtraCallCostPerMinute() {
		return subscriberExtraCallCostPerMinute;
	}

	public double getSubscriberTaxOnBill() {
		return subscriberTaxOnBill;
	}
	public void getMobilePrepaidUserDetails(){
		System.out.println("Name          : " + subscriberName);
		System.out.println("Id 			  : " + subscriberId);
		System.out.println("PhoneNumber   : " + subscriberPhoneNumber);
	}
	public void getSubscriberDetails() {

		System.out.println("Name          : " + subscriberName);
		System.out.println("Id 			  : " + subscriberId);
		System.out.println("PhoneNumber   : " + subscriberPhoneNumber);
		System.out.println("Plan name     : " + subscriberPlanName);
		System.out.println("Plan Cost     : " + subscriberPlanCost);
		System.out.println("Calls/Free    : " + subscriberFreeCalls);
		System.out.println("Extra Calls   : " + subscriberExtraCallsInMinutes);
		System.out.println("Cost/ex.calls : " + subscriberExtraCallCostPerMinute);
	}



}
