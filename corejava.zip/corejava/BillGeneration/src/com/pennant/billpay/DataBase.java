package com.pennant.billpay;

public class DataBase {
	Subscriber[] subscribers=new Subscriber[3];
	
	public DataBase(LandLineSubscriber[] subscribers) {
		
		subscribers[0]=new LandLineSubscriber("Ammi", 144, 8121742472l, "one month", 2000, 150, 1500, 0.03,
				500, 0.20);
		subscribers[1]=new LandLineSubscriber("Vinay", 143, 8106015117l, "one month", 2000, 150, 1800, 0.03,
				260, 0.20);
		subscribers[2]=new LandLineSubscriber("Arjun", 142, 6300052229l, "one month", 2000, 150, 1000, 0.03,
				100, 0.20);
				}
	
	public  DataBase(MobilePostPaidUsers[] subscribers) {
		subscribers[0] = new MobilePostPaidUsers("Gopal", 344, 9908922714l, "one month", 2000, 250, 1000, 0.05,
				350, 0.09);
		subscribers[1] = new MobilePostPaidUsers("Mani", 1225, 9063370528l, "three months", 8000, 450, 1500, 0.05,
				290, 0.09);
		subscribers[2] = new MobilePostPaidUsers("Gopi", 1426, 7569216831l, "one month", 2000, 250, 1200, 0.05,
				180, 0.09);
	}
	public DataBase(MobilePrePaidUsers[] subscribers){
		subscribers[0] = new MobilePrePaidUsers("Balu", 121, 9989456229l, 32453212543l, 20);
		subscribers[1] = new MobilePrePaidUsers("Harish", 122, 9963966193l, 32124345534l, 100);
		subscribers[2] = new MobilePrePaidUsers("Mahesh", 123, 9866789327l, 31245445566l, 222);
	}

}
