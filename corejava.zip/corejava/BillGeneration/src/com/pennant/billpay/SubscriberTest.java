package com.pennant.billpay;

import java.util.Scanner;

public class SubscriberTest {

	public static void main(String[] args) {

		MobilePostPaidUsers[] moblieSubscribers = new MobilePostPaidUsers[3];
		moblieSubscribers[0] = new MobilePostPaidUsers("Gopal", 344, 9908922714l, "one month", 2000, 250, 1000, 0.05,
				350, 0.09);
		moblieSubscribers[1] = new MobilePostPaidUsers("Mani", 1225, 9063370528l, "three months", 8000, 450, 1500, 0.05,
				290, 0.09);
		moblieSubscribers[2] = new MobilePostPaidUsers("Gopi", 1426, 7569216831l, "one month", 2000, 250, 1200, 0.05,
				180, 0.09);

		LandLineSubscriber[] landLineSubscribers = new LandLineSubscriber[3];
		landLineSubscribers[0] = new LandLineSubscriber("Ammi", 144, 8121742472l, "one month", 2000, 150, 1500, 0.03,
				500, 0.20);
		landLineSubscribers[1] = new LandLineSubscriber("Vinay", 143, 8106015117l, "one month", 2000, 150, 1800, 0.03,
				260, 0.20);
		landLineSubscribers[2] = new LandLineSubscriber("Arjun", 142, 6300052229l, "one month", 2000, 150, 1000, 0.03,
				100, 0.20);

		MobilePrePaidUsers[] prePaidUsers = new MobilePrePaidUsers[3];
		prePaidUsers[0] = new MobilePrePaidUsers("Balu", 121, 9989456229l, 32453212543l, 20);
		prePaidUsers[1] = new MobilePrePaidUsers("Harish", 122, 9963966193l, 32124345534l, 100);
		prePaidUsers[2] = new MobilePrePaidUsers("Mahesh", 123, 9866789327l, 31245445566l, 222);
		
		System.out.println("1.Customer \n  2.HR \n 3.Management \n 4.exit");
		System.out.println("Select your Option: ");
		Scanner scanner = new Scanner(System.in);
		int option = scanner.nextInt();
		switch (option) {
		case 1:
			System.out.println("Are you 1.Pospaid User \n 2.Landine User \n 3.PrePaid User");
			int flag = scanner.nextInt();
			if (flag == 1) {
				System.out.println("Enter your Id: ");
				int id = scanner.nextInt();
				for (int i = 0; i < moblieSubscribers.length; i++) {
					if (id == moblieSubscribers[i].getSubscriberId()) {
						moblieSubscribers[i].getSubscriberDetails();
						System.out.println("Total Bill :" + moblieSubscribers[i].generateBill());
					}
				}
			} else if (flag == 2) {
				System.out.println("Enter your Id: ");
				int id = scanner.nextInt();
				for (int i = 0; i < landLineSubscribers.length; i++) {
					if (id == landLineSubscribers[i].getSubscriberId()) {
						landLineSubscribers[i].getSubscriberDetails();
						System.out.println("Total Bill :" + landLineSubscribers[i].generateBill());
					}
				}
			} else if (flag == 3) {
				System.out.println("Enter your Id: ");
				int id = scanner.nextInt();
				for (int i = 0; i < prePaidUsers.length; i++) {
					if (id == prePaidUsers[i].getSubscriberId()) {
						prePaidUsers[i].getMobilePrepaidUserDetails();
						System.out.println("Your talktime is :" + prePaidUsers[i].talkTime());
					}
				}
			}
			break;
		case 2:
			System.out.println("Hello HR ");
			System.out.println("Yopu want 1. Mobile postpaid users \n 2.Land line Users \n 3.Mobile PrePaid Users");
			int flag1 = scanner.nextInt();
			if (flag1 == 1) {
				for (int i = 0; i < landLineSubscribers.length; i++) {

					MobilePostPaidUsers ms = new MobilePostPaidUsers(moblieSubscribers[i].getSubscriberName(),
							moblieSubscribers[i].getSubscriberId(), moblieSubscribers[i].getSubscriberPhoneNumber(),
							moblieSubscribers[i].getSubscriberPlanName(), moblieSubscribers[i].getSubscriberFreeCalls(),
							moblieSubscribers[i].getSubscriberPlanCost(),
							moblieSubscribers[i].getSubscriberExtraCallsInMinutes(),
							moblieSubscribers[i].getSubscriberExtraCallCostPerMinute(),
							moblieSubscribers[i].getRoamingNofMinutes(),
							moblieSubscribers[i].getRoamingCostPerMinute());
					ms.getSubscriberDetails();
				}
			} else if (flag1 == 2) {
				for (int i = 0; i < landLineSubscribers.length; i++) {
					LandLineSubscriber lls = new LandLineSubscriber(landLineSubscribers[i].getSubscriberName(),
							landLineSubscribers[i].getSubscriberId(), landLineSubscribers[i].getSubscriberPhoneNumber(),
							landLineSubscribers[i].getSubscriberPlanName(),
							landLineSubscribers[i].getSubscriberFreeCalls(),
							landLineSubscribers[i].getSubscriberPlanCost(),
							landLineSubscribers[i].getSubscriberExtraCallsInMinutes(),
							landLineSubscribers[i].getSubscriberExtraCallCostPerMinute(),
							landLineSubscribers[i].getNoOfSTDCallsInMinutes(),
							landLineSubscribers[i].getCostPerEachSTDInMinute());
					lls.getSubscriberDetails();
				}
			} else if (flag1 == 3) {
				for (int i = 0; i < prePaidUsers.length; i++) {
					MobilePrePaidUsers pu = new MobilePrePaidUsers(prePaidUsers[i].getSubscriberName(),
							prePaidUsers[i].getSubscriberId(), prePaidUsers[i].getSubscriberPhoneNumber(),
							prePaidUsers[i].getVoucherId(), prePaidUsers[i].getVoucherAmount());
						pu.getMobilePrepaidUserDetails();
				}
			}
			break;
		case 3:
			double[] totalBillForLandLine = new double[landLineSubscribers.length];
			LandLineSubscriber landLineManagement = null;
			for (int i = 0; i < landLineSubscribers.length; i++) {
				landLineManagement = new LandLineSubscriber(landLineSubscribers[i].getSubscriberName(),
						landLineSubscribers[i].getSubscriberId(), landLineSubscribers[i].getSubscriberPhoneNumber(),
						landLineSubscribers[i].getSubscriberPlanName(), landLineSubscribers[i].getSubscriberFreeCalls(),
						landLineSubscribers[i].getSubscriberPlanCost(),
						landLineSubscribers[i].getSubscriberExtraCallsInMinutes(),
						landLineSubscribers[i].getSubscriberExtraCallCostPerMinute(),
						landLineSubscribers[i].getNoOfSTDCallsInMinutes(),
						landLineSubscribers[i].getCostPerEachSTDInMinute());

				totalBillForLandLine[i] = landLineManagement.generateBill();

			}

			double turnOverLandLine = landLineManagement.turnOverForLandLineUsers(totalBillForLandLine);
			System.out.println("Total turn over LandLine Users for this month is : " + turnOverLandLine);

			double[] totalBillForMobile = new double[moblieSubscribers.length];
			MobilePostPaidUsers mobileUsersManagement = null;
			for (int i = 0; i < moblieSubscribers.length; i++) {
				mobileUsersManagement = new MobilePostPaidUsers(moblieSubscribers[i].getSubscriberName(),
						moblieSubscribers[i].getSubscriberId(), moblieSubscribers[i].getSubscriberPhoneNumber(),
						moblieSubscribers[i].getSubscriberPlanName(), moblieSubscribers[i].getSubscriberFreeCalls(),
						moblieSubscribers[i].getSubscriberPlanCost(),
						moblieSubscribers[i].getSubscriberExtraCallsInMinutes(),
						moblieSubscribers[i].getSubscriberExtraCallCostPerMinute(),
						moblieSubscribers[i].getRoamingNofMinutes(), moblieSubscribers[i].getRoamingCostPerMinute());
				totalBillForMobile[i] = mobileUsersManagement.generateBill();

			}

			double turnOverMobilePostPaid = mobileUsersManagement.turnOverForMobilePostPaidUsers(totalBillForMobile);
			System.out.println("Total turn over Moble PostPaid Users for this month is : " + turnOverMobilePostPaid);

			double[] totalBillForPrePaid=new double[prePaidUsers.length];
			MobilePrePaidUsers prePaidUsersManagement=null;
			for (int i = 0; i < prePaidUsers.length; i++) {
				 prePaidUsersManagement = new MobilePrePaidUsers(prePaidUsers[i].getSubscriberName(),
						prePaidUsers[i].getSubscriberId(), prePaidUsers[i].getSubscriberPhoneNumber(),
						prePaidUsers[i].getVoucherId(), prePaidUsers[i].getVoucherAmount());
				totalBillForPrePaid[i]=prePaidUsersManagement.talkTime();
			}
			double turnOverMobilePrePaid = prePaidUsersManagement.turnOverForMobilePrePaidUsers(totalBillForPrePaid);
			System.out.println("Total turn over Moble PrePaid Users for this month is "+turnOverMobilePrePaid);
			
			System.out.println("Total Turn Over for Company : " + (turnOverMobilePostPaid + turnOverLandLine+turnOverMobilePrePaid));
			break;
		case 4:
			System.exit(0);
			break;
		default:
			System.err.println("please select appropiate option");
			break;
		}
		scanner.close();

	}
}
