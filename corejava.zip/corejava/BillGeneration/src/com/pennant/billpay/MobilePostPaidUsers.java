package com.pennant.billpay;

public class MobilePostPaidUsers extends MobileSubscriber{
	private int roamingNofMinutes;
	private double roamingCostPerMinute;

	public MobilePostPaidUsers(String subscriberName, int subscriberId, long subscriberPhoneNumber,
			String subscriberPlanName, int subscriberFreeCalls, double subscriberPlanCost,
			int subscriberExtraCallsInMinutes, double subscriberExtraCallCostPerMinute, int noOfSTDCallsInMinutes,
			double costPerEachSTDInMinute) {
		super(subscriberName, subscriberId, subscriberPhoneNumber, subscriberPlanName, subscriberFreeCalls,
				subscriberPlanCost, subscriberExtraCallsInMinutes, subscriberExtraCallCostPerMinute);
		this.roamingNofMinutes = noOfSTDCallsInMinutes;
		this.roamingCostPerMinute = costPerEachSTDInMinute;
	}

	public int getRoamingNofMinutes() {
		return roamingNofMinutes;
	}

	public double getRoamingCostPerMinute() {
		return roamingCostPerMinute;
	}

	@Override
	public void getSubscriberDetails() {
		System.out.println("==========Subscriber Details===============");
		System.out.println("===You are Mobile Postpaid User===");
		super.getSubscriberDetails();
		System.out.println("STD/mins       : " + roamingNofMinutes);
		System.out.println("Cost/STDC      : " + roamingCostPerMinute);
	}

	public double generateBill() {
		double bill = 0;

		bill = getSubscriberPlanCost() + (getSubscriberExtraCallsInMinutes() * getSubscriberExtraCallCostPerMinute())
				+ (roamingNofMinutes * roamingCostPerMinute);
		bill = bill + ((bill * 10) / 100);

		return bill;
	}



	public double turnOverForMobilePostPaidUsers(double[] totalBill) {
		double turnOver = 0;
		for (int i = 0; i < totalBill.length; i++) {
			turnOver = turnOver + totalBill[i];
		}
		return turnOver;
	}

}
