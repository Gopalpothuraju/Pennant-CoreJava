package com.pennant.billpay;

public class MobileSubscriber extends Subscriber {
	
	public MobileSubscriber(String subscriberName, int subscriberId, long subscriberPhoneNumber,
			String subscriberPlanName, int subscriberFreeCalls, double subscriberPlanCost,
			int subscriberExtraCallsInMinutes, double subscriberExtraCallCostPerMinute) {
		super(subscriberName, subscriberId, subscriberPhoneNumber, subscriberPlanName, subscriberFreeCalls,
				subscriberPlanCost, subscriberExtraCallsInMinutes, subscriberExtraCallCostPerMinute);
	
	}

	 public MobileSubscriber(String subscriberName,int subscriberId,long subscriberPhoneNumber) {
		super(subscriberName,subscriberId,subscriberPhoneNumber);
	}
	
}
