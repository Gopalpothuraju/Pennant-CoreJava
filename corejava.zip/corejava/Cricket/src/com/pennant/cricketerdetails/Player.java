package com.pennant.cricketerdetails;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Player {
	private String name;
	private int age;
	private String playerType;
	private String country;
	private int bestScoreInODI;
	private int totalScoreInODI;
	private int bestWicketsInODI;
	private int totalWicketsInODI;
	private int noOfMatchesInODI;
	private int bestScoreInTest;
	private int totalScoreInTest;
	private int bestWicketsInTest;
	private int totalWicketsInTest;
	private int noOfMatchesInTest;
	private int bestScoreInT20;
	private int totalScoreInT20;
	private int bestWicketsInT20;
	private int totalWicketsInT20;
	private int noOfMatchesInT20;
	List<Player> sortedList;
	private float averageEconomy;

	public Player(String name, int age, String playerType, String country, int bestScoreInODI, int totalScoreInODI,
			int bestWicketsInODI, int totalWicketsInODI, int noOfMatchesInODI, int bestScoreInTest,
			int totalScoreInTest, int bestWicketsInTest, int totalWicketsInTest, int noOfMatchesInTest,
			int bestScoreInT20, int totalScoreInT20, int bestWicketsInT20, int totalWicketsInT20,
			int noOfMatchesInT20) {
		super();
		this.name = name;
		this.age = age;
		this.playerType = playerType;
		this.country = country;
		this.bestScoreInODI = bestScoreInODI;
		this.totalScoreInODI = totalScoreInODI;
		this.bestWicketsInODI = bestWicketsInODI;
		this.totalWicketsInODI = totalWicketsInODI;
		this.noOfMatchesInODI = noOfMatchesInODI;
		this.bestScoreInTest = bestScoreInTest;
		this.totalScoreInTest = totalScoreInTest;
		this.bestWicketsInTest = bestWicketsInTest;
		this.totalWicketsInTest = totalWicketsInTest;
		this.noOfMatchesInTest = noOfMatchesInTest;
		this.bestScoreInT20 = bestScoreInT20;
		this.totalScoreInT20 = totalScoreInT20;
		this.bestWicketsInT20 = bestWicketsInT20;
		this.totalWicketsInT20 = totalWicketsInT20;
		this.noOfMatchesInT20 = noOfMatchesInT20;
	}

	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}

	public String getPlayerType() {
		return playerType;
	}

	public String getCountry() {
		return country;
	}

	public int getBestScoreInODI() {
		return bestScoreInODI;
	}

	public int getTotalScoreInODI() {
		return totalScoreInODI;
	}

	public int getBestWicketsInODI() {
		return bestWicketsInODI;
	}

	public int getTotalWicketsInODI() {
		return totalWicketsInODI;
	}

	public int getNoOfMatchesInODI() {
		return noOfMatchesInODI;
	}

	public int getBestScoreInTest() {
		return bestScoreInTest;
	}

	public int getTotalScoreInTest() {
		return totalScoreInTest;
	}

	public int getBestWicketsInTest() {
		return bestWicketsInTest;
	}

	public int getTotalWicketsInTest() {
		return totalWicketsInTest;
	}

	public int getNoOfMatchesInTest() {
		return noOfMatchesInTest;
	}

	public int getBestScoreInT20() {
		return bestScoreInT20;
	}

	public int getTotalScoreInT20() {
		return totalScoreInT20;
	}

	public int getBestWicketsInT20() {
		return bestWicketsInT20;
	}

	public int getTotalWicketsInT20() {
		return totalWicketsInT20;
	}

	public int getNoOfMatchesInT20() {
		return noOfMatchesInT20;
	}

	public float getAverageEconomy() {
		return averageEconomy;
	}

	public Player() {

	}

	public void displayPersonalDetails(List<Player> list) {

		System.out.println("--------------Cricketer Details---------");
		System.out.println("Index \t Player Name \tAge \t Role \t    Nationality");
		System.out.println("=========================================================");
		int i = 1;
		Iterator<Player> iterator;
		for (iterator = list.iterator(); iterator.hasNext();) {
			Player player = (Player) iterator.next();
			System.out.println(" " + i + "\t" + player.getName() + "    \t" + player.getAge() + "\t"
					+ player.getPlayerType() + "  \t" + player.getCountry());
			i++;
		}
		System.out.println("-------------------------------------------------------------------------------");

	}

	public void displayODIDetails(List<Player> list) {
		int i = 1;
		System.out.println("---------ODI Details------------");
		System.out.println("Index \t Matches \t High Score \t Runs \t Top wkts \t Total Wkts \t Average");
		System.out.println("=============================================================================================");
		for (Player player : list) {
			System.out.println("  " + i + "\t  " + player.getNoOfMatchesInODI() + "\t \t " + player.getBestScoreInODI()
					+ "\t \t  " + player.getTotalScoreInODI() + "\t     " + player.getBestWicketsInODI() + "\t \t "
					+ player.getTotalWicketsInODI()+"\t  \t   "+player.displayAverageBatting(player, 1));
			i++;
		}
		System.out.println("--------------------------------------------------------------------------------------------");
	}

	public void displayTestDetails(List<Player> list) {

		int i = 1;
		System.out.println("---------Test Details------------");
		System.out.println("Index \t Matches \t High Score \t Runs \t Top wkts \t Total Wkts \t Average");
		System.out.println("===============================================================================================");
		for (Player player : list) {
			System.out.println("  " + i + "\t  " + player.getNoOfMatchesInTest() + "\t \t "
					+ player.getBestScoreInTest() + "\t \t  " + player.getTotalScoreInTest() + "\t     "
					+ player.getBestWicketsInTest() + "\t \t " + player.getTotalWicketsInTest()+"\t  \t  "+player.displayAverageBatting(player, 2));
			i++;
		}
		System.out.println("-------------------------------------------------------------------------------------------------");
	}

	public void displayT20Details(List<Player> list) {
		int i = 1;
		System.out.println("---------T20 Details------------");
		System.out.println("Index \t Matches \t High Score \t Runs \t Top wkts \t Total Wkts \t Average");
		System.out.println("==============================================================================================");
		for (Player player : list) {
			System.out.println("  " + i + "\t  " + player.getNoOfMatchesInT20() + "\t \t " + player.getBestScoreInT20()
					+ "\t \t  " + player.getTotalScoreInT20() + "\t     " + player.getBestWicketsInT20() + "\t \t "
					+ player.getTotalWicketsInT20()+"\t \t   "+player.displayAverageBatting(player, 3));
			i++;
		}
		System.out.println("-----------------------------------------------------------------------------------------");
	}
	public double displayAverageBatting(Player player ,int option){
		double average=0.0;
		if(option==1 && player.getNoOfMatchesInODI()!=0){
			average=player.getTotalScoreInODI()/player.getNoOfMatchesInODI();
		}else if(option==2 && player.getNoOfMatchesInTest()!=0){
			average=player.getTotalScoreInTest()/player.getNoOfMatchesInTest();
		}else if(option==3 && player.getNoOfMatchesInT20()!=0){
			average=player.getTotalScoreInT20()/player.getNoOfMatchesInT20();
		}else{
			average=0.0;
		}
		return average+20;
	}
	
	public List<Player> countryDetails(List<Player> list, String countryName) {
		sortedList=new ArrayList<>();
	for (Player player : list) {
		if(player.getCountry().equalsIgnoreCase(countryName)){
			
			sortedList.add(player);
		}
	}
	
	return sortedList;
	}



	public List<Player> displayPlayerParticularDetails(List<Player> list, String playerName) {
	sortedList=new ArrayList<>();
	for (Player player : list) {
		if(player.getName().equalsIgnoreCase(playerName)){
			sortedList.add(player);
		}
	}
		return sortedList;
	}


	public List<Player> getBattingAverageOfPlayer(List<Player> list, int option) {
		double average=0.0;
		sortedList=new ArrayList<>();
		for (Player player : list) {
			average=displayAverageBatting(player, option);
			
			if(average>50.00 && player.getPlayerType().equalsIgnoreCase("Batsman")){
				sortedList.add(player);
			}
			
		}
	
		
		return sortedList;
	}

	public List<Player> getBowlingEcxonomyOfPlayers(List<Player> list, int option) {
		sortedList=new ArrayList<>();
		for (Player player : list) {
			if(option==1){
				if(player.getBestWicketsInODI()>=2 && player.getPlayerType().equalsIgnoreCase("Bowler")){
					sortedList.add(player);
				}
			}else if(option==2){
				if(player.getBestWicketsInTest()>=2 && player.getPlayerType().equalsIgnoreCase("Bowler")){
					sortedList.add(player);
				}
			}else if(option==3){
				if(player.getBestWicketsInT20()>=2 && player.getPlayerType().equalsIgnoreCase("Bowler")){
					sortedList.add(player);
				}
			}
		}
		return sortedList;
	}

	public List<Player> getAllRounderEcxonomyOfPlayers(List<Player> list, int option) {
		double average=0.0;
		sortedList=new ArrayList<>();
		for (Player player : list) {
			average=displayAverageBatting(player, option);
			if(option==1){
				if(average>=40.00 && player.getBestWicketsInODI()>=2 && player.getPlayerType().equalsIgnoreCase("AllRndr")){
					sortedList.add(player);
				}
			}else if(option==2){
				if(average>=40.00 && player.getBestWicketsInTest()>=2 && player.getPlayerType().equalsIgnoreCase("AllRndr")){
					sortedList.add(player);
				}
			}else if(option==3){
				if(average>=40.00 && player.getBestWicketsInT20()>=2 && player.getPlayerType().equalsIgnoreCase("AllRndr")){
					sortedList.add(player);
				}
			}
		}
		return sortedList;
	}


	

}
