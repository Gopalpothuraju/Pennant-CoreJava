package com.pennant.cricketerdetails;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class CricketerOperations {
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

		Player player1 = new Player("Sachin", 46, "Batsman", "india", 200, 18426, 5, 154, 463, 248, 15921, 2, 46, 200,
				10, 10, 1, 1, 1);
		Player player2 = new Player("Sehwag", 40, "Batsman", "india", 219, 8273, 2, 96, 251, 319, 8586, 5, 40, 104, 68,
				394, 0, 0, 19);
		Player player3 = new Player("de Villiers", 35, "Batsman", "south africa", 176, 9577, 1, 7, 228, 278, 8765, 1, 2,
				114, 79, 1672, 0, 0, 78);
		Player player4 = new Player("Dhoni", 37, "Batsman", "india", 183, 10561, 1, 1, 343, 224, 4876, 0, 0, 90, 56,
				1617, 0, 0, 98);
		Player player5 = new Player("V.Shankar", 28, "AllRndr", "india", 46, 165, 2, 18, 9, 0, 0, 0, 0, 0, 63, 557, 2,
				23, 15);
		Player player6 = new Player("H.Pandya", 25, "AllRndr", "india", 83, 794, 3, 44, 31, 108, 532, 5, 17, 11, 33,
				296, 3, 36, 24);
		Player player7 = new Player("Johnson", 37, "Bowler", "Australia", 73, 951, 5, 239, 91, 123, 2065, 10, 313, 70,
				28, 109, 2, 38, 17);
		Player player8 = new Player("Stoinis", 29, "AllRndr", "Australia", 146, 982, 2, 30, 33, 56, 1, 45, 2, 8, 33,
				136, 3, 12, 14);
		Player player9 = new Player("Bumrah", 25, "Bowler", "india", 10, 18, 5, 90, 51, 6, 14, 6, 49, 20, 7, 8, 4, 51,
				42);
		Player player10 = new Player("Bhuvneshwar", 29, "Bowler", "India", 53, 523, 5, 123, 107, 63, 522, 7, 63, 32, 9,
				23, 6, 36, 37);
		Player player11 = new Player("Russell", 31, "AllRndr", "West Indies", 92, 1013, 2, 69, 54, 2, 2, 1, 1, 1, 47,
				465, 1, 25, 47);

		Set<Player> setData = new HashSet<>();
		setData.add(player1);
		setData.add(player2);
		setData.add(player3);
		setData.add(player4);
		setData.add(player5);
		setData.add(player6);
		setData.add(player7);
		setData.add(player8);
		setData.add(player9);
		setData.add(player10);
		setData.add(player11);

		List<Player> list = new ArrayList<>();
		list.addAll(setData);
		Player playerDetails = new Player();

		System.out.println("1.Display All Details.  \t \t 2.Display All Details for particular Country");
		System.out.println("3.Display T20 Details for all players \t 4.Display T20 details for particular player");
		System.out.println("5.Display ODI Details for all players \t 6.Display ODI details for particular player");
		System.out.println("7.Display Test Details for all players \t 8.Display Test details for particular player");
		System.out.println("9.Best Batsman \t \t \t \t 10.Best Bowler ");
		System.out.println("11.Best All Rounder \t \t \t 12.All Cricketers Sort by Name  ");
		System.out.println(" 13.Top Runs \t \t \t \t 14.High Score  ");
		System.out.println("15.Top Wickets taken in career \t  \t 16.Best wickets in single match");
		System.out.println("17.Sort by country \t \t \t 18.Exit");
		System.out.println("----------------------------------------------------------------------------");
		
		System.out.println("\n Select Anyone option : ");
		int selectedOption = scanner.nextInt();

		switch (selectedOption) {
		case 1:
			playerDetails.displayPersonalDetails(list);

			playerDetails.displayODIDetails(list);

			playerDetails.displayTestDetails(list);

			playerDetails.displayT20Details(list);
			break;
		case 2:
			System.out.println("Enter country name : ");
			String countryName = scanner.next();
			list = playerDetails.countryDetails(list, countryName);
			playerDetails.displayPersonalDetails(list);
			playerDetails.displayODIDetails(list);
			playerDetails.displayTestDetails(list);
			playerDetails.displayT20Details(list);
			break;
		case 3:
			playerDetails.displayPersonalDetails(list);
			playerDetails.displayT20Details(list);
			break;
		case 4:
			System.out.println("Enter player Name : ");
			String playerName = scanner.next();
			list = playerDetails.displayPlayerParticularDetails(list, playerName);
			playerDetails.displayPersonalDetails(list);
			playerDetails.displayT20Details(list);
			break;
		case 5:
			playerDetails.displayPersonalDetails(list);
			playerDetails.displayODIDetails(list);
			break;
		case 6:
			System.out.println("Enter player Name : ");
			playerName = scanner.next();
			list = playerDetails.displayPlayerParticularDetails(list, playerName);
			playerDetails.displayPersonalDetails(list);
			playerDetails.displayODIDetails(list);
			break;
		case 7:
			playerDetails.displayPersonalDetails(list);
			playerDetails.displayTestDetails(list);
			break;
		case 8:
			System.out.println("Enter player Name : ");
			playerName = scanner.next();
			list = playerDetails.displayPlayerParticularDetails(list, playerName);
			playerDetails.displayPersonalDetails(list);
			playerDetails.displayTestDetails(list);
			break;
		case 9:
			System.out.println("1.ODI 2.Test 3.T20");
			int option = scanner.nextInt();
			list = playerDetails.getBattingAverageOfPlayer(list, option);
			playerDetails.displayPersonalDetails(list);

			playerDetails.displayODIDetails(list);

			playerDetails.displayTestDetails(list);
			playerDetails.displayT20Details(list);

			break;
		case 10:
			System.out.println("1.ODI 2.Test 3.T20");
			option = scanner.nextInt();
			list = playerDetails.getBowlingEcxonomyOfPlayers(list, option);
			playerDetails.displayPersonalDetails(list);

			playerDetails.displayODIDetails(list);

			playerDetails.displayTestDetails(list);
			playerDetails.displayT20Details(list);
			break;
		case 11:System.out.println("1.ODI 2.Test 3.T20");
		option = scanner.nextInt();
		list = playerDetails.getAllRounderEcxonomyOfPlayers(list, option);
		playerDetails.displayPersonalDetails(list);

		playerDetails.displayODIDetails(list);

		playerDetails.displayTestDetails(list);
		playerDetails.displayT20Details(list);
			break;
		case 12:Collections.sort(list,new Comparator<Player>() {

			@Override
			public int compare(Player o1, Player o2) {
				
				return o1.getName().compareToIgnoreCase(o2.getName());
			}
		});
		playerDetails.displayPersonalDetails(list);

		playerDetails.displayODIDetails(list);

		playerDetails.displayTestDetails(list);

		playerDetails.displayT20Details(list);
			break;
		case 13:System.out.println("1.ODI 2.Test 3.T20");
		option = scanner.nextInt();
			Collections.sort(list,new Comparator<Player>() {

			@Override
			public int compare(Player o1, Player o2) {
				
				if(option==1){
				return o2.getTotalScoreInODI()-o1.getTotalScoreInODI();
				}else if(option==2){
					return o2.getTotalScoreInTest()-o1.getTotalScoreInTest();
				}else if(option==3){
					return o2.getTotalScoreInT20()-o1.getTotalScoreInT20();
				}else{
					return 0;
				}
				
			}
		});
			playerDetails.displayPersonalDetails(list);

			playerDetails.displayODIDetails(list);

			playerDetails.displayTestDetails(list);

			playerDetails.displayT20Details(list);
			break;
		case 14:System.out.println("1.ODI 2.Test 3.T20");
		option = scanner.nextInt();
		Collections.sort(list,new Comparator<Player>() {

		@Override
		public int compare(Player o1, Player o2) {
			
			if(option==1){
			return o2.getBestScoreInODI()-o1.getBestScoreInODI();
			}else if(option==2){
				return o2.getBestScoreInTest()-o1.getBestScoreInTest();
			}else if(option==3){
				return o2.getBestScoreInT20()-o1.getBestScoreInT20();
			}else{
				return 0;
			}
			
		}
	});
		playerDetails.displayPersonalDetails(list);

		playerDetails.displayODIDetails(list);

		playerDetails.displayTestDetails(list);

		playerDetails.displayT20Details(list);
			break;
		case 15:System.out.println("1.ODI 2.Test 3.T20");
		option = scanner.nextInt();
		Collections.sort(list,new Comparator<Player>() {

		@Override
		public int compare(Player o1, Player o2) {
			
			if(option==1){
			return o2.getTotalWicketsInODI()-o1.getTotalWicketsInODI();
			}else if(option==2){
				return o2.getTotalWicketsInTest()-o1.getTotalWicketsInTest();
			}else if(option==3){
				return o2.getTotalWicketsInT20()-o1.getTotalWicketsInT20();
			}else{
				return 0;
			}
			
		}
	});
		playerDetails.displayPersonalDetails(list);

		playerDetails.displayODIDetails(list);

		playerDetails.displayTestDetails(list);

		playerDetails.displayT20Details(list);
			break;
		case 16:System.out.println("1.ODI 2.Test 3.T20");
		option = scanner.nextInt();
		Collections.sort(list,new Comparator<Player>() {

		@Override
		public int compare(Player o1, Player o2) {
			
			if(option==1){
			return o2.getBestWicketsInODI()-o1.getBestWicketsInODI();
			}else if(option==2){
				return o2.getBestWicketsInTest()-o1.getBestWicketsInTest();
			}else if(option==3){
				return o2.getBestWicketsInT20()-o1.getBestWicketsInT20();
			}else{
				return 0;
			}
			
		}
	});
		playerDetails.displayPersonalDetails(list);

		playerDetails.displayODIDetails(list);

		playerDetails.displayTestDetails(list);

		playerDetails.displayT20Details(list);
			break;
		case 17:Collections.sort(list,new Comparator<Player>() {

			@Override
			public int compare(Player o1, Player o2) {
				
				return o1.getCountry().compareToIgnoreCase(o2.getCountry());
			}
		});
		playerDetails.displayPersonalDetails(list);

		playerDetails.displayODIDetails(list);

		playerDetails.displayTestDetails(list);

		playerDetails.displayT20Details(list);
			break;
		case 18:
			System.exit(0);
			break;
		default:
			System.err.println("Please select appropiate options only..");
			break;

		}

		scanner.close();
	}
}
