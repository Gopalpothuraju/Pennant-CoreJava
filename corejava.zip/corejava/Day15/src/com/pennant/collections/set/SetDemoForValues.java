package com.pennant.collections.set;

import java.util.Set;
import java.util.TreeSet;

public class SetDemoForValues {

	public static void main(String[] args) {
		Set<Object> setNames=new TreeSet<>();
		String name1=new String("Gopal");
		String name2="gopi";
		String name3=new String("mani");
		String i="sai";
		
	//	int i=10;
		
		setNames.add(name1);
		setNames.add(name2);
		setNames.add(name3);
		setNames.add(i);
		System.out.println(setNames);
	}

}
