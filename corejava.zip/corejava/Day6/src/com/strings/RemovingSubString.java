package com.strings;

public class RemovingSubString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
