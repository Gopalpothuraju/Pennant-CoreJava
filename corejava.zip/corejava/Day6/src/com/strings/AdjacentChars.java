package com.strings;
public class AdjacentChars {
	public static int maxBlock(String string) {
	int count = 0;
		for (int i = 0; i < string.length(); i++) {
			int count1 = 1;
			for (int j = i + 1; j < string.length(); j++) {
				if (string.charAt(i) == string.charAt(j)) {
				count1++;
				}
				if (count1 > count) {
					count = count1;
				}
			}
		}
		return count;
	}
	public static void main(String[] args) {
		String str = new String("hoopla");
		System.out.println(maxBlock(str));
		String str1 = new String("aaaaabbbbbcc");
		System.out.println(maxBlock(str1));
	}
}
