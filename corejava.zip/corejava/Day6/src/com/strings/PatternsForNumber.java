package com.strings;

public class PatternsForNumber {

	public static void main(String[] args) {
	
	}

}
