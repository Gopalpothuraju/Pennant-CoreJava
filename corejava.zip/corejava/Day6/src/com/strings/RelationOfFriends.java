package com.strings;

public class RelationOfFriends {
	public static void retionShip(String[] string) {
		String[] bestFriends = new String[string.length];
		String[] goodFriends = new String[string.length];
		int index4 = 0;
		int index3 = 0;
		boolean[] flag = new boolean[string.length];
		for (int i = 0; i < flag.length; i++) {
			flag[i] = false;
		}
		for (int i = 0; i < string.length - 1; i++) {
			if (string[i].substring(0, 4).equalsIgnoreCase(string[i + 1].substring(0, 4))) {
				if (index4 == 0) {
					if (flag[i] == false) {
						bestFriends[index4] = string[i];
						flag[i] = true;
						index4++;

					}
				}
				if (flag[i + 1] == false) {
					bestFriends[index4] = string[i + 1];
					flag[i + 1] = true;
					index4++;
				}

			} else if (string[i].substring(0, 3).equalsIgnoreCase(string[i + 1].substring(0, 3))) {

				if (index3 == 0) {
					if (flag[i] == false) {
						goodFriends[index3] = string[i];
						flag[i] = true;
						index3++;
					}
				}
				if (flag[i + 1] == false) {
					goodFriends[index3] = string[i + 1];
					flag[i + 1] = true;
					index3++;
				}
			}

		}
	
		for (int i = 0; i < index4; i++) {
			System.out.print(bestFriends[i] + " ");
		}
		if (index4 >= 3) {
			System.out.println("Best Friends");
		} else {
			System.out.println("Not Friends");
		}

		for (int i = 0; i < index3; i++) {
			System.out.print(goodFriends[i] + " ");
		}
		if (index3 >= 3) {
			System.out.println("Good Friends");
		} else {
			System.out.println("Not Friends");
		}

	}

	public static void main(String[] args) {
		String[] string = new String[6];
		string[0] = "Rajesh";
		string[1] = "Rajendra";
		string[2] = "Rajeshwara";
		string[3] = "Ramesh";
		string[4] = "ramu";
		string[5] = "rams";
		retionShip(string);

	}

}
