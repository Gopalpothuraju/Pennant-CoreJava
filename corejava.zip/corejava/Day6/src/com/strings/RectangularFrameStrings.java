package com.strings;

public class RectangularFrameStrings {
	public static void rectangularFormat(String[] names){
		System.out.println("***********");
		for(int i=0;i<names.length;i++){
			System.out.print("* "+names[i]+" *");
			System.out.println();
		}
		System.out.println("***********");
	}
	public static void main(String[] args) {
		String[] strings=new String[5];
		strings[0]="Hello";
		strings[1]="Gopal";
		strings[2]="welcome";
		strings[3]="to";
		strings[4]=" world";
		rectangularFormat(strings);
	}

}
