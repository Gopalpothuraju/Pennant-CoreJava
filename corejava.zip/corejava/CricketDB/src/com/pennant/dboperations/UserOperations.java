package com.pennant.dboperations;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

import com.pennant.bean.Cricketer;
import com.pennant.display.DisplayOperations;

public class UserOperations {
	public static void userOperations(List<Cricketer> list) {

		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		DisplayOperations displayOperations = new DisplayOperations();
		String playerName = null;

		System.out.println("1.Display All Details  \t \t 2.Display All Details for particular Country");
		System.out.println("3.Best AllRounder \t 4.Display ODI details for particular player");
		System.out.println("5.Best Batsman \t \t \t 6.Best Bowler");
		System.out.println(" 7.Sort by Name  \t \t 8.All Cricketers Sort by Country ");
		System.out.println(" 9.Top Runs \t \t \t \t 10.Top Wickets taken in career  ");
		System.out.println("11.Best wickets in single match \t  \t 12.Best Score in single match");

		System.out.println("----------------------------------------------------------------------------");

		System.out.println("\n Select Any one option : ");
		int selectedOption = scanner.nextInt();

		switch (selectedOption) {
		case 1:
			displayOperations.displayPersonalDetails(list);
			displayOperations.displayODIDetails(list);

			break;
		case 2:
			System.out.println("Enter country name : ");
			String countryName = scanner.next();
			list = displayOperations.countryDetails(list, countryName);
			displayOperations.displayPersonalDetails(list);
			displayOperations.displayODIDetails(list);

			break;

		case 3:
			list = displayOperations.getBestPlayer(list, selectedOption);
			displayOperations.displayPersonalDetails(list);
			displayOperations.displayODIDetails(list);
			break;
		case 4:
			System.out.println("Enter player Name : ");
			playerName = scanner.next();
			list = displayOperations.displayPlayerParticularDetails(list, playerName);
			displayOperations.displayPersonalDetails(list);
			displayOperations.displayODIDetails(list);
			break;

		case 5:

			list = displayOperations.getBestPlayer(list, selectedOption);
			displayOperations.displayPersonalDetails(list);
			displayOperations.displayODIDetails(list);
			break;
		case 6:
			list = displayOperations.getBestPlayer(list, selectedOption);
			displayOperations.displayPersonalDetails(list);

			displayOperations.displayODIDetails(list);

			break;
		case 7:
			Collections.sort(list, new Comparator<Cricketer>() {
				@Override
				public int compare(Cricketer o1, Cricketer o2) {
					// TODO Auto-generated method stub
					return o1.getName().compareToIgnoreCase(o2.getName());
				}
			});
			displayOperations.displayPersonalDetails(list);
			displayOperations.displayODIDetails(list);
			break;

		case 8:
			Collections.sort(list, new Comparator<Cricketer>() {
				@Override
				public int compare(Cricketer o1, Cricketer o2) {
					// TODO Auto-generated method stub
					return o1.getCountry().compareToIgnoreCase(o2.getCountry());
				}
			});
			displayOperations.displayPersonalDetails(list);
			displayOperations.displayODIDetails(list);
			break;

		case 9:
			Collections.sort(list, new Comparator<Cricketer>() {

				@Override
				public int compare(Cricketer o1, Cricketer o2) {
					return o2.getTotalScoreInODI() - o1.getTotalScoreInODI();

				}
			});
			displayOperations.displayPersonalDetails(list);

			displayOperations.displayODIDetails(list);

			break;

		case 10:
			Collections.sort(list, new Comparator<Cricketer>() {

				@Override
				public int compare(Cricketer o1, Cricketer o2) {

					return o2.getTotalWicketsInODI() - o1.getTotalWicketsInODI();

				}
			});
			displayOperations.displayPersonalDetails(list);

			displayOperations.displayODIDetails(list);
			break;

		case 11:

			Collections.sort(list, new Comparator<Cricketer>() {

				@Override
				public int compare(Cricketer o1, Cricketer o2) {

					return o2.getBestWicketsInODI() - o1.getBestWicketsInODI();

				}
			});
			displayOperations.displayPersonalDetails(list);

			displayOperations.displayODIDetails(list);

			break;
		case 12:

			Collections.sort(list, new Comparator<Cricketer>() {

				@Override
				public int compare(Cricketer o1, Cricketer o2) {

					return o2.getBestScoreInODI() - o1.getBestScoreInODI();

				}
			});
			displayOperations.displayPersonalDetails(list);

			displayOperations.displayODIDetails(list);

			break;

		default:
			System.err.println("Please select appropiate options only..");
			break;

		}

	}
}
