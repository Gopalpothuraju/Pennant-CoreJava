package com.pennant.dboperations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.pennant.bean.Cricketer;
import com.pennant.db.connection.ConnectiongToDataBase;
import com.pennant.db.tableoperations.AlteringTableData;
import com.pennant.db.tableoperations.CreatingTable;
import com.pennant.db.tableoperations.DeleteInDB;
import com.pennant.db.tableoperations.InsertingData;
import com.pennant.db.tableoperations.RetreivingTableData;
import com.pennant.db.tableoperations.RetrivingTableNamesFromDB;
import com.pennant.db.tableoperations.UpdateDataInTable;

public class DataBaseOperations {
	

	public static void main(String[] args) throws Exception {
		List<Cricketer> employeeList = new ArrayList<>();
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		Connection connection = null;
		PreparedStatement prepareStatement=null;
		System.out.println("1.Insert 2.Delete 3.Update 4.Retreive 5.Create 6.Alter");
		System.out.println("Enter your option: ");
		int option = scanner.nextInt();
		connection=ConnectiongToDataBase.getConnectToDb();
		
			if (option == 1) {
				InsertingData.insertingValues(connection,prepareStatement);
			} else if (option == 2) {
				System.out.println("Do you want to delete particular 1.person or 2.table");
				int value=scanner.nextInt();
				if(value==1){
					DeleteInDB.deleteDataInTable(connection,prepareStatement);
				}
				else if(value==2){
					DeleteInDB.deleteTableInDB(connection, prepareStatement);
				}
			} else if (option == 3) {
				UpdateDataInTable.updatingData(connection,prepareStatement);
			} else if (option == 4) {
				employeeList=RetreivingTableData.retrieveTableValues(connection,prepareStatement);
				boolean flag = true;
				while (flag) {
					System.out.println("Do you want to display cricketer details (yes/no)");
					String displayOption = scanner.next();
					if (displayOption.equalsIgnoreCase("yes") || displayOption.charAt(0) == 'y') {
						UserOperations.userOperations(employeeList);
						flag = true;
					} else {
						flag = false;
					}
				}
			
			}else if(option==5){
				CreatingTable.creatingTable(connection, RetrivingTableNamesFromDB.getTables(connection));
			}else if(option==6){
				AlteringTableData.alteringTable(connection, RetrivingTableNamesFromDB.getTables(connection));
			}
		
		
	}
}
