package com.pennant.bean;

public class Cricketer {
	private String name;
	private int age;
	private String playerType;
	private String country;
	private int bestScoreInODI;
	private int totalScoreInODI;
	private int noOfMatchesInODI;
	private int totalWicketsInODI;
	private int bestWicketsInODI;
	private float strikeRate;
	private float economy;
	public Cricketer() {
		// TODO Auto-generated constructor stub
	}
	public Cricketer(String name, int age, String playerType, String country, int bestScoreInODI, int totalScoreInODI,
			 int noOfMatchesInODI, int totalWicketsInODI,int bestWicketsInODI, float strikeRate, float economy) {
		super();
		this.name = name;
		this.age = age;
		this.playerType = playerType;
		this.country = country;
		this.bestScoreInODI = bestScoreInODI;
		this.totalScoreInODI = totalScoreInODI;
		this.bestWicketsInODI = bestWicketsInODI;
		this.totalWicketsInODI = totalWicketsInODI;
		this.noOfMatchesInODI = noOfMatchesInODI;
		this.strikeRate = strikeRate;
		this.economy = economy;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getPlayerType() {
		return playerType;
	}
	public void setPlayerType(String playerType) {
		this.playerType = playerType;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public int getBestScoreInODI() {
		return bestScoreInODI;
	}
	public void setBestScoreInODI(int bestScoreInODI) {
		this.bestScoreInODI = bestScoreInODI;
	}
	public int getTotalScoreInODI() {
		return totalScoreInODI;
	}
	public void setTotalScoreInODI(int totalScoreInODI) {
		this.totalScoreInODI = totalScoreInODI;
	}
	public int getBestWicketsInODI() {
		return bestWicketsInODI;
	}
	public void setBestWicketsInODI(int bestWicketsInODI) {
		this.bestWicketsInODI = bestWicketsInODI;
	}
	public int getTotalWicketsInODI() {
		return totalWicketsInODI;
	}
	public void setTotalWicketsInODI(int totalWicketsInODI) {
		this.totalWicketsInODI = totalWicketsInODI;
	}
	public int getNoOfMatchesInODI() {
		return noOfMatchesInODI;
	}
	public void setNoOfMatchesInODI(int noOfMatchesInODI) {
		this.noOfMatchesInODI = noOfMatchesInODI;
	}
	public float getStrikeRate() {
		return strikeRate;
	}
	public void setStrikeRate(float strikeRate) {
		this.strikeRate = strikeRate;
	}
	public float getEconomy() {
		return economy;
	}
	public void setEconomy(float economy) {
		this.economy = economy;
	}
	@Override
	public String toString() {
		return "Cricketer [name=" + name + ", age=" + age + ", playerType=" + playerType + ", country=" + country
				+ ", bestScoreInODI=" + bestScoreInODI + ", totalScoreInODI=" + totalScoreInODI + ", bestWicketsInODI="
				+ bestWicketsInODI + ", totalWicketsInODI=" + totalWicketsInODI + ", noOfMatchesInODI="
				+ noOfMatchesInODI + ", strikeRate=" + strikeRate + ", economy=" + economy + "]";
	}
	
}
