package com.pennant.display;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.pennant.bean.Cricketer;


public class DisplayOperations {
	List<Cricketer> sortedList=null;
	
	public  void displayPersonalDetails(List<Cricketer> list) {
	
		System.out.println("--------------Cricketer Details---------");
		System.out.println("Index \t Player Name \tAge \t Role \t    Nationality");
		System.out.println("=========================================================");
		int i = 1;
		Iterator<Cricketer> iterator;
		for (iterator = list.iterator(); iterator.hasNext();) {
			Cricketer player = (Cricketer) iterator.next();
			System.out.println(" " + i + "\t" + player.getName() + "    \t" + player.getAge() + "\t"
					+ player.getPlayerType() + "  \t" + player.getCountry());
			i++;
		}
		System.out.println("-------------------------------------------------------------------------------");

	}

	public  void displayODIDetails(List<Cricketer> list) {
		int i = 1;
		System.out.println("---------ODI Details------------");
		System.out.println("Index \t High Score  \t Runs \t Matches \t Total wkts \t Top Wkts \t StrikeRate \t Economy");
		System.out.println("=============================================================================================");
		for (Cricketer player : list) {
			System.out.println("  " + i + "\t  " + player.getBestScoreInODI() + "\t \t " + player.getTotalScoreInODI()
					+ "\t  " + player.getNoOfMatchesInODI() + "\t  " + player.getTotalWicketsInODI() + "\t \t "
					+ player.getBestWicketsInODI()+"\t  \t   "+player.getStrikeRate()+"\t  \t "+player.getEconomy());
			i++;
		}
		System.out.println("--------------------------------------------------------------------------------------------");
	}
	public  List<Cricketer> countryDetails(List<Cricketer> list, String countryName) {
		sortedList=new ArrayList<>();
	for (Cricketer player : list) {
		if(player.getCountry().equalsIgnoreCase(countryName)){
			
			sortedList.add(player);
		}
	}
	
	return sortedList;
	}
	
	public  List<Cricketer> displayPlayerParticularDetails(List<Cricketer> list, String playerName) {
		sortedList=new ArrayList<>();
		for (Cricketer player : list) {
			if(player.getName().equalsIgnoreCase(playerName)){
				sortedList.add(player);
			}
		}
			return sortedList;
		}

	public List<Cricketer> getBestPlayer(List<Cricketer> list,int option) {
		 String player=null;
		 sortedList=new ArrayList<>();
		 float strikeRate=0.0f;
		 float economy=10.0f;
		 if(option==5){
		 for (Cricketer cricketer : list) {
			if(strikeRate<cricketer.getStrikeRate() && cricketer.getPlayerType().equalsIgnoreCase("Batsman")){
				strikeRate=cricketer.getStrikeRate();
				player=cricketer.getName();
			}
		}
		 }else if(option==6){
			 for (Cricketer cricketer : list) {
					if(economy>cricketer.getEconomy() && cricketer.getPlayerType().equalsIgnoreCase("Bowler")){
						economy=cricketer.getEconomy();
						player=cricketer.getName();
					}
				}
			
		 }else if(option==3){
			 for (Cricketer cricketer : list) {
				if(economy>cricketer.getEconomy() &&strikeRate<cricketer.getStrikeRate()&& cricketer.getPlayerType().equalsIgnoreCase("All Rounder")){
					economy=cricketer.getEconomy();
					strikeRate=cricketer.getStrikeRate();
					player=cricketer.getName();
				}
			}
		 }
		 for (Cricketer cricketer : list) {
			if(player.equalsIgnoreCase(cricketer.getName())){
				sortedList.add(cricketer);
			}
		}
		return sortedList;
		
	}
	

}
