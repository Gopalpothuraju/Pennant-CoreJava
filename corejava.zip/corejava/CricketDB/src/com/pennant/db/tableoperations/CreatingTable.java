package com.pennant.db.tableoperations;

import java.sql.Connection;
import java.sql.Statement;
import java.util.List;
import java.util.Scanner;

public class CreatingTable {

	
public static void creatingTable(Connection con,List<String> list) throws Exception{
	
	@SuppressWarnings("resource")
	Scanner scanner=new Scanner(System.in);
	int count=0;
	String[] columnNames=new String[100];
	String[] typeOfColumn=new String[100];
	int i=0;
	System.out.println("You are trying to create a table in your particular database"+con);
	Thread.sleep(500);
	System.out.println("Enter table name to create in data base : ");
	String tableName=scanner.next();
	for (String string : list) {
		if(string.equalsIgnoreCase(tableName)){
			count++;
			break;
		}
	}
	boolean flag=true;
	if(count==0){
		while(flag){
		System.out.println("Enter column name which you want to add in table");
		columnNames[i]=scanner.next();
		System.out.println("Enter type of data you can enter in "+columnNames[i]+" colum");
		typeOfColumn[i]=scanner.next();
		Statement createStatement = con.createStatement();
		if(i==0){
			
			int executeUpdate = createStatement.executeUpdate("create table "+tableName+"("+columnNames[i]+" "+typeOfColumn[i]+")");
			
				System.out.println("Table is created..."+executeUpdate);
			
			
		}else{
			int executeUpdate = createStatement.executeUpdate("alter table "+tableName+" add "+columnNames[i]+" "+typeOfColumn[i]);
			
				System.out.println("new column is created into your table..."+executeUpdate);
			
		}
		System.out.println("Do you want to add more number of columns in to "+tableName+"(y/n)");
		String option=scanner.next();
		if(option.equalsIgnoreCase("yes") || option.charAt(0)=='y'){
			i++;
			flag=true;
		}else{
			flag=false;
		}
		}
	}else{
		System.err.println(tableName+" Already exisit in your database");
	}
}
}
