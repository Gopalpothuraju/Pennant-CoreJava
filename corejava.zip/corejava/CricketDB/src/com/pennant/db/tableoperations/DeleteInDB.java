package com.pennant.db.tableoperations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class DeleteInDB {

	public static void deleteDataInTable(Connection connection, PreparedStatement prepareStatement) throws SQLException {
		@SuppressWarnings("resource")
		Scanner scanner=new Scanner(System.in);
		prepareStatement = connection.prepareStatement("delete from cricketer where name=?");
		System.out.println("---You can delete cricketer by using name only--- : ");
		System.out.println("Enter cricketer name to delete : ");
		String name = scanner.next();
		prepareStatement.setString(1, name);
		int executeUpdate = prepareStatement.executeUpdate();
		System.out.println(executeUpdate + "rows effected");
		
	}

	public static void deleteTableInDB(Connection connection, PreparedStatement prepareStatement) throws SQLException {
		@SuppressWarnings("resource")
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter table name to delete : ");
		String name = scanner.next();
		prepareStatement=connection.prepareStatement("drop table "+name);
		int executeUpdate = prepareStatement.executeUpdate();
		System.out.println(executeUpdate + "rows effected");
	}

}
