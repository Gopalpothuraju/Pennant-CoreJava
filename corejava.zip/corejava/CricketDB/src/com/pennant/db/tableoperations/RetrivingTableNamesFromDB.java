package com.pennant.db.tableoperations;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RetrivingTableNamesFromDB {
public static List<String> getTables(Connection con){
	List<String> tables=new ArrayList<>();
	 DatabaseMetaData dbmd;
	try {
		dbmd = con.getMetaData();
		String[] types = {"TABLE"};
	     ResultSet rs = dbmd.getTables(null, null, "%", types);
	     while (rs.next()) {
	        tables.add(rs.getString("TABLE_NAME"));
	     }
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
     
	return tables;
	
}
}
