package com.pennant.db.tableoperations;

import java.sql.Connection;
import java.sql.Statement;
import java.util.List;
import java.util.Scanner;

public class AlteringTableData {
//new column adding
//rename for column
//data type changing
//delete column
	public static void alteringTable(Connection con,List<String> tables) throws Exception{
		String columnName=null;
		String typeOfColumn=null;
		String modifyName=null;
		
		@SuppressWarnings("resource")
		Scanner scanner=new Scanner(System.in);
		int count=0;
		System.out.println("Enter table name to modify details");
		String tableName=scanner.next();
		for (String string : tables) {
			if(tableName.equalsIgnoreCase(string)){
				count++;
				break;
			}
		}
		Statement createStatement = con.createStatement();
		if(count>0){
			System.out.println("select your option : ");
			System.out.println("1.Add new Column \t 2.Rename For Existing column \n 3.Change data type \t 4.delete column");
			int option=scanner.nextInt();
			if(option==1){
				System.out.println("Enter column name which you want to add in table");
				columnName=scanner.next();
				System.out.println("Enter type of data you can enter in "+columnName+" colum");
				typeOfColumn=scanner.next();
				 
				int executeUpdate = createStatement.executeUpdate("alter table "+tableName+" add "+columnName+" "+typeOfColumn);
				
				System.out.println("new column is created into your table..."+executeUpdate);
			
			}else if(option==2){
				System.out.println("Enter column name which you want");
				columnName=scanner.next();
				
				System.out.println("Enter column which you want to modify");
				modifyName=scanner.next();
				if(columnName.equalsIgnoreCase(modifyName)){
					System.out.println("Old column name and new column are same");
				}else{
				int executeUpdate = createStatement.executeUpdate("alter table "+tableName+" rename "+modifyName+" to "+columnName);
				System.out.println("Column name is changed to"+columnName+" "+executeUpdate);
				}
			}else if(option==3){
				
				System.out.println("enter column name to modify data type :");
				columnName=scanner.next();
				System.out.println("Enter new data type to modify in "+columnName+"column");
				typeOfColumn=scanner.next();
				 int executeUpdate = createStatement.executeUpdate("alter table "+tableName+" modify column "+columnName+" "+typeOfColumn);
				 System.out.println("Column name is changed to"+columnName+" "+executeUpdate);
					
			}else if(option==4){
				System.out.println("Enter column name to delete : ");
				columnName=scanner.next();
	//			alter table tableName drop columnname
				int executeUpdate = createStatement.executeUpdate("alter table "+tableName+" drop "+columnName);
				 System.out.println(columnName+" is dropped "+executeUpdate);
			}
		}
		
	}
}
