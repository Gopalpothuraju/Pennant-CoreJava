package com.pennant.db.tableoperations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.pennant.bean.Cricketer;

public class RetreivingTableData {

	public static List<Cricketer> retrieveTableValues(Connection connection, PreparedStatement prepareStatement) throws SQLException {

		
		List<Cricketer> employeeList=new ArrayList<>();
		prepareStatement = connection.prepareStatement("select * from cricketer");
		ResultSet rs = prepareStatement.executeQuery();
		while (rs.next()) {
			Cricketer player = new Cricketer(rs.getString(1), rs.getInt(2), rs.getString(3), rs.getString(4),
					rs.getInt(5), rs.getInt(6), rs.getInt(7), rs.getInt(8), rs.getInt(9), rs.getFloat(10),
					rs.getFloat(11));
			employeeList.add(player);

		}
		
		return employeeList;
	}

}
