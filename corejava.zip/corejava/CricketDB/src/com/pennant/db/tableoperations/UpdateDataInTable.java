package com.pennant.db.tableoperations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class UpdateDataInTable {

	public static void updatingData(Connection connection, PreparedStatement prepareStatement) throws SQLException {
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		Statement createStatement = connection.createStatement();
		System.out.println("Enter name to update details..");
		String name = scanner.next();

		System.out.println("Which data you want to modify \n 1.age \t 2.Cricketer Played a match");
		int value = scanner.nextInt();
		switch (value) {
		case 1:
			System.out.println("Enter cricketer age to modify :");
			int age = scanner.nextInt();
			int executeUpdate = createStatement
					.executeUpdate("update cricketer set age=" + age + "where name='" + name + "'");
			System.out.println("Cricketer age is updated " + executeUpdate);
			break;
		case 2:
			System.out.println("Enter cricketer score in the today match and no of wikects he taken :");
			int scoreOfTheMatch = scanner.nextInt();
			int todayWickets = scanner.nextInt();
			int bestScore = 0;
			int topWickets = 0;
			int matchesPlayed = 1;
			ResultSet executeQuery = createStatement.executeQuery(
					"select bestScoreInODI,totalRunsInODI,numberOfMatches,totalWickets,topWickets from cricketer where name='"
							+ name + "'");
			while (executeQuery.next()) {
				if (scoreOfTheMatch > executeQuery.getInt(1)) {
					bestScore = scoreOfTheMatch;
				} else {
					bestScore = executeQuery.getInt(1);
				}
				if (todayWickets > executeQuery.getInt(5)) {
					topWickets = todayWickets;
				} else {
					topWickets = executeQuery.getInt(5);
				}
				scoreOfTheMatch = scoreOfTheMatch + executeQuery.getInt(2);
				todayWickets = todayWickets + executeQuery.getInt(4);
				matchesPlayed = matchesPlayed + executeQuery.getInt(3);
			}
			executeUpdate = createStatement.executeUpdate("update cricketer set bestScoreInODI=" + bestScore
					+ ",totalRunsInODI=" + scoreOfTheMatch + ",numberOfMatches=" + matchesPlayed + ",totalWickets="
					+ todayWickets + ",topWickets=" + topWickets + " where name='" + name + "'");
			System.out.println("Cricketer best score is updated " + executeUpdate);
			break;
		default:
			System.out.println("please enter appropiate option ");
		}
	}

}
