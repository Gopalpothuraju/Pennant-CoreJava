package com.pennant.db.tableoperations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class InsertingData {
public static void insertingValues(Connection connection,PreparedStatement prepareStatement) throws SQLException{
	@SuppressWarnings("resource")
	Scanner scanner=new Scanner(System.in);
	prepareStatement = connection
			.prepareStatement("insert into table cricketer values(?,?,?,?,?,?,?,?,?,?,?)");
	System.out.println(
			"Enter cricketer details(name,age,type,country,bestSocreInODI,TotalRunsInODI,No.MatchesInODI,TotalWickets,StrikeRakte,Exconomy)");
	String name = scanner.next();
	int age = scanner.nextInt();
	String type = scanner.next();
	String country = scanner.next();
	int bestScore = scanner.nextInt();
	int totalRuns = scanner.nextInt();
	int noOfMatches = scanner.nextInt();
	int totalWickets = scanner.nextInt();
	int topWickets = scanner.nextInt();
	float strikeRate = scanner.nextFloat();
	float economy = scanner.nextFloat();
	prepareStatement.setString(1, name);
	prepareStatement.setInt(2, age);
	prepareStatement.setString(3, type);
	prepareStatement.setString(4, country);
	prepareStatement.setInt(5, bestScore);
	prepareStatement.setInt(6, totalRuns);
	prepareStatement.setInt(7, noOfMatches);
	prepareStatement.setInt(8, totalWickets);
	prepareStatement.setInt(9, topWickets);
	prepareStatement.setFloat(10, strikeRate);
	prepareStatement.setFloat(11, economy);

	int executeUpdate = prepareStatement.executeUpdate();
	System.out.println(executeUpdate + "rows effected");
}
}
