package com.pennant.files;

import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class DateAppendingToFile {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws IOException {
		String date = null;
		Scanner scanner = new Scanner(System.in);
		CarDetails[] cars = new CarDetails[3];
		cars[0] = new CarDetails();
		cars[1] = new CarDetails();
		cars[2] = new CarDetails();
		String[] fileNames = new String[2];
		FileOutputStream fos = null;

		for (int i = 0; i < fileNames.length; i++) {
			System.out.println("Enter date to create file(mm/dd/yyyy)");
			date = scanner.next();

			fileNames[i] = "./car_details(" + new SimpleDateFormat("dd-MMM-yyyy").format(new Date(date)) + ").txt";
			fos = new FileOutputStream(fileNames[i]);

			for (int j = 0; j < cars.length; j++) {
				String string = cars[j].details();
				byte b[] = string.getBytes();
				fos.write(b);
			}

		}

		System.out.println("END");
		fos.close();

		scanner.close();
	}

}

/*
 * 06/03/2019 111 150 250 112 150 200 113 150 220 06/04/2019 111 250 350 112 200
 * 300 113 250 320
 */
