package com.pennant.files;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class RetrievingFilesData {
	public static double calculateOneDayFund(String[] strings, String carNumber) {
		int starMeter = Integer.parseInt(strings[1]);
		int endMeter = Integer.parseInt(strings[2]);

		double bill = (endMeter - starMeter) * 15;
		return bill;

	}

	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws IOException {
		String date = null;
		double bill = 0;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter your car number");
		String carNumber = scanner.next();

		System.out.println("Enter no of days data you want (max 2):");
		int input = scanner.nextInt();
		switch (input) {
		case 1:
			System.out.println("Enter date to retrive details(mm-dd-yyyy) :");
			date = scanner.next();
			FileInputStream fis = new FileInputStream(
					"./car_details(" + new SimpleDateFormat("dd-MMM-yyyy").format(new Date(date)) + ").txt");
			DataInputStream dis = new DataInputStream(fis);

					String data;
			while ((data = dis.readLine()) != null) {
				String[] strings = data.split("\\_");
				if (carNumber.equalsIgnoreCase(strings[0])) {
					bill = calculateOneDayFund(strings, carNumber);
				}

			}
			System.out.println("You get amount on " + date + ":" + bill);
			break;

		case 2:
			FileInputStream[] fisData = new FileInputStream[2];

		

			for (int i = 0; i < fisData.length; i++) {
				System.out.println("Enter date to retrive details(mm-dd-yyyy) :");
				date = scanner.next();
				fisData[i] = new FileInputStream(
						"./car_details(" + new SimpleDateFormat("dd-MMM-yyyy").format(new Date(date)) + ").txt");
				DataInputStream disData = new DataInputStream(fisData[i]);
				String dataValue;
				while ((dataValue = disData.readLine()) != null) {
					String[] strings = dataValue.split("\\_");
					if (carNumber.equalsIgnoreCase(strings[0])) {
						bill = bill + calculateOneDayFund(strings, carNumber);
					}

				}
			}
			System.out.println("Your total amount :" + bill);

			break;
		default:
			System.err.println("In our data base having 2 days only");
		}
		scanner.close();
	}

}
