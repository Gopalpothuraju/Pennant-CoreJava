package com.assignments;

import java.util.Scanner;

public class ChessGame {
	public static void main(String[] args) {
		int row = 8;
		int colomn = 8;
		int count = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Row value:");
		row = sc.nextInt();
		System.out.println("Enter colom value");
		colomn = sc.nextInt();

		if ((row == 0 && colomn == 0) || (row == 0 && colomn == 7) || (row == 7 && colomn == 0)
				|| (row == 7 && colomn == 7)) {
			count = 2;
		} else if ((row == 1 && colomn == 0) || (row == 1 && colomn == 7) || (row == 0 && colomn == 1)
				|| (row == 7 && colomn == 1) || (row == 6 && colomn == 0) || (row == 6 && colomn == 7)
				|| (row == 0 && colomn == 6) || (row == 7 && colomn == 6)) {
							
							count = 3;
							
		} else if ((row == 2 && colomn == 0) || (row == 5 && colomn == 0) || (row == 3 && colomn == 0)
				|| (row == 4 && colomn == 0) || (row == 2 && colomn == 7) || (row == 3 && colomn == 7)
				|| (row == 4 && colomn == 7) || (row == 5 && colomn == 7) || (row == 1 && colomn == 1)
				|| (row == 1 && colomn == 6) || (row == 6 && colomn == 1) || (row == 6 && colomn == 6)
				|| (row == 0 && colomn == 2) || (row == 0 && colomn == 3) || (row == 0 && colomn == 4)
				|| (row == 0 && colomn == 5) || (row == 7 && colomn == 2) || (row == 7 && colomn == 3)
				|| (row == 7 && colomn == 4) || (row == 7 && colomn == 5)) {
			
							count = 4;

		}else if((row == 2 && colomn == 1) || (row == 3 && colomn == 1) || (row == 4 && colomn == 1)
				|| (row == 2 && colomn == 6) || (row == 5 && colomn == 1) || (row == 3 && colomn == 6)
				|| (row == 4 && colomn == 6) || (row == 5 && colomn == 6) || (row == 1 && colomn == 2)
				|| (row == 1 && colomn == 3) || (row == 1 && colomn == 4) || (row == 1 && colomn == 5)
				|| (row == 6&& colomn == 2) || (row == 6 && colomn == 3) || (row == 6 && colomn == 4)
				|| (row == 6 && colomn == 5)){
					
						count=6;
						
		}else if((row == 2 && colomn == 2) || (row == 2 && colomn == 3) || (row == 2 && colomn == 4)
				|| (row == 2 && colomn == 5) || (row == 3 && colomn == 2) || (row == 3 && colomn == 3)
				|| (row == 3 && colomn == 4) || (row == 3 && colomn == 5) || (row == 4 && colomn == 2)
				|| (row == 4 && colomn == 3) || (row == 4 && colomn == 4) || (row == 4 && colomn == 5)
				|| (row == 5&& colomn == 2) || (row == 5 && colomn == 3) || (row == 5 && colomn == 4)
				|| (row == 5 && colomn == 5)){
					
						count=8;
		}else{
			System.out.println("your entered position is out of limit (limitg is (7,7)only)");
		}
		
		if(row<8 && colomn<8 &&row>=0 && colomn>=0)
		System.out.println("Horse moving only '" + count + "' places from given position (" + row + "," + colomn + ")");
		sc.close();
	}
}
