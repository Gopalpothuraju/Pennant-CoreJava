package com.assignments;

import java.util.Scanner;

public class DaysAlive {
	public static int yearsCalculate(boolean flag, int days, int leapYears, int totalYears) {
		days = (leapYears * 366) + ((totalYears - leapYears) * 365);

		return days;
	}

	public static int leapYearCalculate(int totalYears, int dobYear, int leapYears) {
		for (int i = 0; i <= totalYears; i++) {
			if (((dobYear + i) % 4 == 0) || (((dobYear + i) % 100 == 0) && ((dobYear + i) % 400 == 0))) {
				leapYears++;

			}
		}
		return leapYears;
	}

	public static int daysBeforeCurrent(int currentMonth, int currentDate, int[] months, boolean flag, int days) {

		for (int i = 1; i < currentMonth; i++) {
			if (flag) {
				months[1] = 29;
			}
			days = days + months[i];
		}
		for (int i = 1; i <= currentDate; i++) {
			days++;
		}

		return days;
	}

	public static int daysBeforeBirth(int dobMonth, boolean flag, int[] months, int days, int dobDate) {
		for (int i = 1; i < dobMonth; i++) {
			if (flag) {
				months[1] = 29;
			}
			days = days - months[i];
		}

		for (int i = 1; i <= dobDate; i++) {
			days--;
		}
		return days;
	}

	public static boolean checkCurrentYear(int currentYear, boolean flag) {

		if (currentYear % 4 == 0 || (currentYear % 100 == 0 && currentYear % 400 == 0)) {
			flag = true;
		}
		return flag;
	}

	public static void main(String[] args) {
		int[] months = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter your date of birth(year month date)");
		int dobYear = scanner.nextInt();
		int dobMonth = scanner.nextInt();
		int dobDate = scanner.nextInt();
		System.out.println("Enter current date (year month date)");
		int currentYear = scanner.nextInt();
		int currentMonth = scanner.nextInt();
		int currentDate = scanner.nextInt();
		int totalYears = (currentYear - dobYear);
		int leapYears = 0;
		int days = 0;
		boolean flag = false;
		if (currentDate <= 31 && currentMonth <= 12 && dobMonth <= 12 && dobDate <= 31) {
			flag = checkCurrentYear(currentYear, flag);
			leapYears = leapYearCalculate(totalYears, dobYear, leapYears);
			if (currentYear != dobYear) {
				days = yearsCalculate(flag, days, leapYears, totalYears);
			} else {
				days = 0;
			}

			days = daysBeforeCurrent(currentMonth, currentDate, months, flag, days);

			days = daysBeforeBirth(dobMonth, flag, months, days, dobDate);

			System.out.println("no of days alive:" + days);
		} else {
			System.out.println("please provide valid details ");
		}
		scanner.close();
	}
}
