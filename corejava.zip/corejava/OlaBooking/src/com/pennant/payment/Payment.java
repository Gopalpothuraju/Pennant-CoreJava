package com.pennant.payment;

public class Payment {
	private int kmsJourney;
	private double waitingTime;
	private double costPerKm;
	private double costPerWaitingTimePerMin;

	public Payment(int kmsJourney, double waitingTime, double costPerKm, double costPerWaitingTimePerMin) {
		super();
		this.kmsJourney = kmsJourney;
		this.waitingTime = waitingTime;
		this.costPerKm = costPerKm;
		this.costPerWaitingTimePerMin = costPerWaitingTimePerMin;

	}

	public int getKmsJourney() {
		return kmsJourney;
	}

	public double getWaitingTime() {
		return waitingTime;
	}

	public double getCostPerKm() {
		return costPerKm;
	}

	public double getCostPerWaitingTimePerMin() {
		return costPerWaitingTimePerMin;
	}

}
