package com.pennant.ola;
public class Car {
private int carId;
private String carNumber;
private String carType;
private int capacity;
public Car(int carId, String carNumber, String carType, int capacity) {
	super();
	this.carId = carId;
	this.carNumber = carNumber;
	this.carType = carType;
	this.capacity = capacity;
}
public int getCarId() {
	return carId;
}
public String getCarNumber() {
	return carNumber;
}
public String getCarType() {
	return carType;
}
public int getCapacity() {
	return capacity;
}
@Override
public String toString() {
	return "Car Details : \n  [carId=" + carId + ", carNumber=" + carNumber + ", carType=" + carType + ", capacity=" + capacity + "]";
}

}
