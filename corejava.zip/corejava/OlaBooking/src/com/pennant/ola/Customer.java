package com.pennant.ola;

public class Customer {
private long mobileNumber;
private String name;
private String emailId;
private String source;
private String destination;
public Customer(long mobileNumber, String name, String emailId, String source, String destination) {
	super();
	this.mobileNumber = mobileNumber;
	this.name = name;
	this.emailId = emailId;
	this.source = source;
	this.destination = destination;
}
public long getMobileNumber() {
	return mobileNumber;
}
public String getName() {
	return name;
}
public String getEmailId() {
	return emailId;
}
public String getSource() {
	return source;
}
public String getDestination() {
	return destination;
}

public void details() {
	System.out.println( "Customer [mobileNumber=" + mobileNumber + ", name=" + name + ", emailId=" + emailId + ", source=" + source
			+ ", destination=" + destination + "]");
}

}
