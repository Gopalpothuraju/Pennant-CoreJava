package com.pennant.ola;

import com.pennant.payment.Payment;

public class Driver {
	private int driverId;
	private String driverName;
	private long mobileNumber;
	private float rating;

	public Driver(int driverId, String driverName, long mobileNumber, float rating) {
		super();
		this.driverId = driverId;
		this.driverName = driverName;
		this.mobileNumber = mobileNumber;
		this.rating = rating;
	}

	public int getDriverId() {
		return driverId;
	}

	public String getDriverName() {
		return driverName;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	public double generateBillForRide(Payment payment) {
		double bill = 0;
		bill = (payment.getKmsJourney() * payment.getCostPerKm())
				+ (payment.getWaitingTime() * payment.getCostPerWaitingTimePerMin());
		double tax = bill * 3 / 100;
		double discount = bill * 3 / 100;
		bill = bill + tax - discount;

		return bill;

	}

	@Override
	public String toString() {
		return "Driver Details : \n [driverId=" + driverId + ", driverName=" + driverName + ", mobileNumber="
				+ mobileNumber + ", rating=" + rating + "]";
	}

}
