  package com.pennant;

import java.util.Scanner;


import com.pennant.ola.Car;
import com.pennant.ola.Customer;
import com.pennant.ola.Driver;
import com.pennant.payment.Payment;

public class BookCar {
	public static void main(String[] args) throws InterruptedException {
		Scanner scanner = new Scanner(System.in);
		Car[] cars = new Car[10];
		cars[0] = new Car(111, "AP05-1111", "swift-Dzire", 4);
		cars[1] = new Car(112, "AP05-143", "swift-Vdi", 4);
		cars[2] = new Car(113, "AP05-6", "Xcent", 6);
		cars[3] = new Car(114, "AP05-4565", "Xylo", 6);
		cars[4] = new Car(115, "AP05-1421", "Baleno", 4);
		cars[5] = new Car(116, "AP05-789", "Innovo", 6);
		cars[6] = new Car(117, "AP05-2212", "Duster", 6);
		cars[7] = new Car(118, "AP05-7890", "Breeza", 4);
		cars[8] = new Car(119, "AP05-4357", "WagonR", 4);
		cars[9] = new Car(120, "AP05-1111", "S-cross", 4);

		Driver[] drivers = new Driver[10];
		drivers[0] = new Driver(11, "Sai", 9989555221l, 3.5f);
		drivers[1] = new Driver(12, "Ammi", 9989555222l, 4.5f);
		drivers[2] = new Driver(13, "Vinay", 9989555223l, 3.0f);
		drivers[3] = new Driver(14, "Ashish", 9989555224l, 2.5f);
		drivers[4] = new Driver(15, "Krishna", 9989555230l, 4.5f);
		drivers[5] = new Driver(16, "Arjun", 9989555225l, 3.5f);
		drivers[6] = new Driver(17, "Mankanta", 9989555226l, 3.0f);
		drivers[7] = new Driver(18, "Bhaskar", 9989555227l, 4.5f);
		drivers[8] = new Driver(19, "Chandu", 9989555228l, 4.0f);
		drivers[9] = new Driver(20, "Ravi", 9989555229l, 3.5f);

		Object[][] mapping = new Object[cars.length][2];

		for (int i = 0; i < cars.length; i++) {
			for (int j = 0; j < 2; j++) {
				if (j == 0) {

					mapping[i][j] = cars[i];
				} else if (j == 1) {

					mapping[i][j] = drivers[i];
				}
			}
		}
		Customer customer=new Customer(9908922714l, "Gopal", "pothurajugopal@gmail.com", "S.R.Nagar", "Hitech City");
		
		System.out.println("Please enter no of pessangers(max 6) : ");
		int noOfPessangers=scanner.nextInt();
		if(noOfPessangers<=4 && noOfPessangers>=1){
			for(int i=0;i<cars.length;i++){
				if(cars[i].getCapacity()==4){
					System.out.println(cars[i].getCarId());
				}
			}
		}else if(noOfPessangers>4 && noOfPessangers<=6){
			for (int i = 0; i < cars.length; i++) {
				if(cars[i].getCapacity()==6){
					System.out.println(cars[i].getCarId());
				}
			}
		}
		
		System.out.println("Enter Car Id : ");
		int id=scanner.nextInt();
		int driverIdForPayment=0;
		for (int i = 0; i < mapping.length; i++) {
			for(int j=0;j<2;j++){
			if(id==cars[i].getCarId()){
				System.out.println(mapping[i][j] +"\n");
				driverIdForPayment=drivers[i].getDriverId();
			}
		}
		}
		System.out.println("Calling to driver..\n Driver picked Up(yes/no)");
		String option=scanner.next();
		if(option.equalsIgnoreCase("yes")){
		System.out.println("Ride Started....");
		Thread.sleep(1500);
		customer.details();
		System.out.println("Ride Finished...");
		Payment payment=new Payment(20, 0, 4, 2);
		double bill=0;
	
		for (int i = 0; i < drivers.length; i++) {
			if(drivers[i].getDriverId()==driverIdForPayment){
			bill=drivers[i].generateBillForRide(payment);
			}
		}
		System.out.println("Amount on ride is :"+bill);
		}else{
			System.out.println("Sorry for the inconvinence ..your ride is cancelled...");
			System.out.println("Please select another cab...");
		}
		scanner.close();
	}

}
