package com.pennant.queue;

import java.util.ArrayDeque;
import java.util.Deque;

public class QueueDemo {

	public static void main(String[] args) {
		Deque<Integer> dequeue=new ArrayDeque<>();
		dequeue.push(345);
		dequeue.add(23);
		dequeue.push(34);
		dequeue.push(369);
		dequeue.addFirst(12);
		dequeue.addLast(89);
		dequeue.offerFirst(233);
		dequeue.offerLast(124);
		System.out.println(dequeue);
		dequeue.pollFirst();
		dequeue.pollLast();
		dequeue.pollLast();
		System.out.println(dequeue);
	}

}
