package com.pennant.listinterface;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class CopyingList {
public static void main(String[] args) {
	List<String> list=new CopyOnWriteArrayList<>();
	//List<String> list=new ArrayList<>();
	list.add("Gopal");
	list.add("Mani");
	list.add("Gopi");
	list.add("ammi");
	list.add("ashish");
	Iterator<String> itr=list.iterator();
	while (itr.hasNext()) {
		String string = (String) itr.next();
		if(string.equalsIgnoreCase("Gopi")){
			//itr.remove();
			list.remove(string);
		}else
		{
		System.out.println(string);
		}
		}
	System.out.println(list);
}
}
