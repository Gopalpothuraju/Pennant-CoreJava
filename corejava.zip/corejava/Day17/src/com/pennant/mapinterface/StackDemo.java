package com.pennant.mapinterface;

import java.util.Stack;

public class StackDemo {

	public static void main(String[] args) {
		Stack<Integer> list=new Stack<>();
		list.push(12);
		list.push(34);
		list.push(67);
		list.push(47);
		list.push(90);
		System.out.println(list);
		System.out.println(list.size());
		System.out.println(list.pop());
		System.out.println(list.size());
		System.out.println(list.peek());
		System.out.println(list.size());
	}

}
