package com.pennant.application;

import java.util.Scanner;

import com.pennant.hotel.cutomer.FirstTImeVisitor;
import com.pennant.hotel.cutomer.MembershipVisitor;
import com.pennant.hotel.cutomer.RegularVisitor;
import com.pennant.hotel.cutomer.Visitor;
import com.pennant.hotel.management.Hotel;

public class CheckIntoHotel {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Hotel[] hotel = new Hotel[5];
		hotel[0] = new Hotel(12, "Deluxe", 150, 180);
		hotel[1] = new Hotel(10, "Luxury", 200, 240);
		hotel[2] = new Hotel(8, "AC", 250, 280);
		hotel[3] = new Hotel(32, "Non-AC", 100, 80);
		hotel[4] = new Hotel(2, "Suit", 350, 280);
		for (int i = 0; i < hotel.length; i++) {
			hotel[i].getHotelDetails();
		}

		System.out.println("Are You: \n 1.First Time Visitor \n 2.Regular Visitor \n 3.MemberShip Visitor \n 4.Exit");
		int option = scanner.nextInt();
		switch (option) {
		case 1:
			System.out.println("-----First Time Visitor---");
			Visitor firstTimeVisitor = new FirstTImeVisitor(360272707392l, "Gopal", 23, 9908922714l, 2, 36, true,
					"Antarvedi", "Interview");
			System.out.println("Select type of room you want");
			String typeOfRoom = scanner.next(); // AC
			for (int i = 0; i < hotel.length; i++) {
				if (typeOfRoom.equalsIgnoreCase(hotel[i].getTypesOfRoom()) && (hotel[i].getNoOfRoomsInHotel() != 0)) {
					System.out.println("Room is allocated...");
					double bill = firstTimeVisitor.generateBill(hotel[i].getRoomCostPerHour(),
							hotel[i].getFoodCostPerOnce());
					System.out.println("Your Bill is" + bill);
					double tax = firstTimeVisitor.payTax(bill);
					System.out.println("Your Tax is" + tax);
					double discount = firstTimeVisitor.discount(bill);
					System.out.println("first time users have discount " + discount);
					System.out.println("Your Total bill is :" + (bill + tax - discount));

					System.out.println("Sir/Madam, Do you want hotelID(yes/no) : ");
					String hotelId = scanner.next();
					if (hotelId.equalsIgnoreCase("yes")) {
						System.out.println(hotel[i].generateHotelID());
					}
					System.out.println("Thank You ...\n visit again..");
				}
			}

			break;
		case 2:
			
			System.out.println("---Regular Visitor----");
			Visitor regularVisitor=new RegularVisitor(2, 48, true, 1234);
			System.out.println("Select which type of room you want : ");
			typeOfRoom = scanner.next();
			for (int i = 0; i < hotel.length; i++) {
			if (typeOfRoom.equalsIgnoreCase(hotel[i].getTypesOfRoom()) && (hotel[i].getNoOfRoomsInHotel() != 0)) {
				System.out.println("Room is allocated...");
				double bill=regularVisitor.generateBill(hotel[i].getRoomCostPerHour(), hotel[i].getFoodCostPerOnce());
				System.out.println("Your Bill is" + bill);
				double tax = regularVisitor.payTax(bill);
				System.out.println("Your Tax is" + tax);
				double discount = regularVisitor.discount(bill);
				System.out.println("regular users have discount " + discount);
				System.out.println("Your Total bill is :" + (bill + tax - discount));
				System.out.println("Sir/Madam, Do you want membership(yes/no) : ");
				String hotelId = scanner.next();
				if (hotelId.equalsIgnoreCase("yes")) {
					RegularVisitor re=(RegularVisitor)regularVisitor;
					re.setWantMemberShip(true);
					if(re.getWantMemberShip()){
					System.out.println("You got membership sir");
					}else{
						System.out.println("Sorry sir,please try after some time...");
					}
				}
				System.out.println("Thank You ...\n visit again..");
			}
			}
			break;
		case 3:	System.out.println("----Membership visitor---");
				Visitor memberShipVisitor=new MembershipVisitor(2, 24, true, 1234, true);
				System.out.println("Select which type of room you want : ");
				typeOfRoom = scanner.next();
				for (int i = 0; i < hotel.length; i++) {
					if (typeOfRoom.equalsIgnoreCase(hotel[i].getTypesOfRoom()) && (hotel[i].getNoOfRoomsInHotel() != 0)) {
				System.out.println("Room is allocated...");
				double bill=memberShipVisitor.generateBill(hotel[i].getRoomCostPerHour(), hotel[i].getFoodCostPerOnce());
				System.out.println("Your Bill is" + bill);
				double tax = memberShipVisitor.payTax(bill);
				System.out.println("Your Tax is" + tax);
				double discount = memberShipVisitor.discount(bill);
				System.out.println("membership users have discount " + discount);
				System.out.println("Your Total bill is :" + (bill + tax - discount));
				System.out.println("Thank You ...\n visit again..");
					}
				}
			break;
		case 4:
			System.exit(0);
			break;
		default:
			System.err.println("Please select appropiate options only....");
			break;
		}
		scanner.close();
	}

}
