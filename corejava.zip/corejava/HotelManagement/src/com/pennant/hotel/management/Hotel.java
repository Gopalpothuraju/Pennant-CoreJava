package com.pennant.hotel.management;

import java.util.Random;

public class Hotel {
	static String hotelName = "NOVOTEL";

	private int noOfRoomsInHotel;
	private String typesOfRoom;
	private double roomCostPerHour;
	private double foodCostPerOnce;

	public Hotel(int noOfRoomsInHotel, String typesOfRoom, double roomCostPerHour, double foodCostPerOnce) {
		super();
		this.noOfRoomsInHotel = noOfRoomsInHotel;
		this.typesOfRoom = typesOfRoom;
		this.roomCostPerHour = roomCostPerHour;
		this.foodCostPerOnce = foodCostPerOnce;
	}

	public static String getHotelName() {
		return hotelName;
	}

	public int getNoOfRoomsInHotel() {
		return noOfRoomsInHotel;
	}

	public String getTypesOfRoom() {
		return typesOfRoom;
	}

	public double getRoomCostPerHour() {
		return roomCostPerHour;
	}

	public double getFoodCostPerOnce() {
		return foodCostPerOnce;
	}

	public void getHotelDetails() {
		System.out.println("-----Welcome to " + hotelName+"-----");
		System.out.println("Type Of Room   : "+typesOfRoom);
		System.out.println("Availability   : "+noOfRoomsInHotel);
		System.out.println("Cost Per Hour  : "+roomCostPerHour);
		System.out.println("Food Cost      : "+foodCostPerOnce);
		System.out.println("==================================");
	}

	public int generateHotelID(){
		int hotelID;
		Random r=new Random();
		hotelID=r.nextInt(1000);
		return hotelID;
	}
	
	public boolean generateMemberShip(){
		boolean memberShip=true;
		return memberShip;
		
	}
}
