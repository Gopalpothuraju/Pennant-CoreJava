package com.pennant.hotel.cutomer;

public abstract class Visitor implements Taxable{
	private long govtIdNumber;
	private String visitorName;
	private int age;
	private long phoneNumber;
	private int noOfMembersStay;
	private int stayAtHotelInHours;
	private boolean wantFood;
	private int hotelId;
	private boolean memberShip;
	private String address;
	
	
	public Visitor(int noOfMembersStay, int stayAtHotelInHours, boolean wantFood, int hotelId, boolean memberShip) {
		super();
		this.noOfMembersStay = noOfMembersStay;
		this.stayAtHotelInHours = stayAtHotelInHours;
		this.wantFood = wantFood;
		this.hotelId = hotelId;
		this.memberShip = memberShip;
	}


	public long getGovtIdNumber() {
		return govtIdNumber;
	}


	public String getVisitorName() {
		return visitorName;
	}


	public int getAge() {
		return age;
	}


	public long getPhoneNumber() {
		return phoneNumber;
	}


	public int getNoOfMembersStay() {
		return noOfMembersStay;
	}


	public int getStayAtHotelInHours() {
		return stayAtHotelInHours;
	}


	public boolean isWantFood() {
		return wantFood;
	}


	public int getHotelId() {
		return hotelId;
	}


	public boolean isMemberShip() {
		return memberShip;
	}


	public String getAddress() {
		return address;
	}


	public Visitor(long govtIdNumber, String visitorName, int age, long phoneNumber, int noOfMembersStay,
			int stayAtHotelInHours, boolean wantFood, String address) {
		super();
		this.govtIdNumber = govtIdNumber;
		this.visitorName = visitorName;
		this.age = age;
		this.phoneNumber = phoneNumber;
		this.noOfMembersStay = noOfMembersStay;
		this.stayAtHotelInHours = stayAtHotelInHours;
		this.wantFood = wantFood;
		this.address = address;
	}


	public Visitor(int noOfMembersStay, int stayAtHotelInHours, boolean wantFood, int hotelId) {
		super();
		this.noOfMembersStay = noOfMembersStay;
		this.stayAtHotelInHours = stayAtHotelInHours;
		this.wantFood = wantFood;
		this.hotelId = hotelId;
	}



	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}
	
	public abstract double generateBill(double roomCostPerHour, double foodCostPerOnce);
	
	}
