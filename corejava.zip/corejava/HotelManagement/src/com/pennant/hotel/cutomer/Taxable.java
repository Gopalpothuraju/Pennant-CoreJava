package com.pennant.hotel.cutomer;

public interface Taxable {
	double payTax(double bill);
	double discount(double bill);
}
