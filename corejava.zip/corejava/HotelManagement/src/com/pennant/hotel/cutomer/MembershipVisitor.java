package com.pennant.hotel.cutomer;

public class MembershipVisitor extends Visitor{

	public MembershipVisitor(int noOfMembersStay, int stayAtHotelInHours, boolean wantFood, int hotelId,
			boolean memberShip) {
		super(noOfMembersStay, stayAtHotelInHours, wantFood, hotelId, memberShip);
		
	}

	@Override
	public double generateBill(double roomCostPerHour, double foodCostPerOnce) {
		double bill=0.0;
		if(!super.isWantFood()){
			foodCostPerOnce=0;
		}
		bill=((super.getStayAtHotelInHours()/8)*foodCostPerOnce)+(super.getStayAtHotelInHours()*roomCostPerHour);
		
		return bill;
	}

	@Override
	public double payTax(double bill) {
		
		int per=1;
		double tax=0;
		tax=(bill*per/100);
		return tax;
		
		
	}

	@Override
	public double discount(double bill) {
		double discount=0;
		int per=1;
		discount=bill*per/100;
		return discount;
	}

	

}
