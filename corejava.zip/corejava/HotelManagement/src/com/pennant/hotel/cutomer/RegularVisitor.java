package com.pennant.hotel.cutomer;

public class RegularVisitor extends Visitor{
	private boolean wantMemberShip;

	public RegularVisitor(int noOfMembersStay, int stayAtHotelInHours, boolean wantFood, int hotelId) {
		super(noOfMembersStay, stayAtHotelInHours, wantFood, hotelId);
	
	}

	public boolean getWantMemberShip() {
		return wantMemberShip;
	}

	public void setWantMemberShip(boolean wantMemberShip) {
		this.wantMemberShip = wantMemberShip;
	}

	@Override
	public double generateBill(double roomCostPerHour, double foodCostPerOnce) {
		double bill=0.0;
		if(!super.isWantFood()){
			foodCostPerOnce=0;
		}
		bill=((super.getStayAtHotelInHours()/8)*foodCostPerOnce)+(super.getStayAtHotelInHours()*roomCostPerHour);
		
		return bill;
	}

	@Override
	public double payTax(double bill) {
		int per=3;
		double tax=0;
		tax=(bill*per/100);
		return tax;
	}

	@Override
	public double discount(double bill) {
		double discount=0;
		int per=5;
		discount=bill*per/100;
		return discount;
	
	}
	
}
