package com.pennant.exam;

public class Example1 {

}
