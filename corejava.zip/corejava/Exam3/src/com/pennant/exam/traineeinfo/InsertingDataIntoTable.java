package com.pennant.exam.traineeinfo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class InsertingDataIntoTable {
public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	Connection connection=null;
	System.out.println("Enter id : ");
	int id=scanner.nextInt();
	System.out.println("Enter name : ");
	String name=scanner.next();
	System.out.println("Enter course name");
	String course=scanner.next();
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		connection=DriverManager.getConnection("jdbc:oracle:thin:@192.168.1.27:1521:orcl", "DB344","pass123");
		PreparedStatement prepareStatement = connection.prepareStatement("insert into Trainee values(?,?,?)");
		prepareStatement.setInt(1, id);
		prepareStatement.setString(2, name);
		prepareStatement.setString(3, course);
		
		int i = prepareStatement.executeUpdate();
		System.out.println(i+"Rows Effected");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally {
		try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		scanner.close();
	}
	
}
}
