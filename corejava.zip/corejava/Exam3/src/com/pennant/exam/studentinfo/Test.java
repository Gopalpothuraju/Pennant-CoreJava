package com.pennant.exam.studentinfo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Test {
	public static void main(String[] args) {
		StudentServices ss=new StudentServices();
		Student[] students=new Student[5];
		students[0]=new Student(1225, "Gopal", 35000.00);
		students[1]=new Student(1226, "Vineeth", 100000.00);
		students[2]=new Student(1227, "Satish", 52000.00);
		students[3]=new Student(1228, "Vinay", 31000.00);
		students[4]=new Student(1232, "Amaresh", 44000.00);
		List<Student> studentList=new ArrayList<>();
		studentList.add(students[0]);
		studentList.add(students[1]);
		studentList.add(students[2]);
		studentList.add(students[3]);
		studentList.add(students[4]);
		Scanner scanner=new Scanner(System.in);
		System.out.println("1.Details Id \t 2.All Students \t  3.Sorting by fees");
		int option=scanner.nextInt();
		switch(option){
		case 1:
			System.out.println("Enter student id to retrive details : ");
			int id=scanner.nextInt();
			studentList=ss.getStudentDetailsById(studentList,id);
			System.out.println(studentList);
			break;
		case 2:System.out.println(studentList);
			break;
		case 3:Collections.sort(studentList,new Comparator<Student>() {

			@Override
			public int compare(Student o1, Student o2) {
			
				return (int) (o1.getFees()-o2.getFees());
			}
		});
		System.out.println(studentList);
			break;
			default:System.exit(0);
				break;
		}
		
		
		scanner.close();
}
}
