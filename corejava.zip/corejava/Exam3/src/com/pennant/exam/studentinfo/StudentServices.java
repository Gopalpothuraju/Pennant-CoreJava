package com.pennant.exam.studentinfo;

import java.util.ArrayList;
import java.util.List;

public class StudentServices {
	List<Student> sortedList;
	public List<Student> getStudentDetailsById(List<Student> studentlist, int id) {
		sortedList=new ArrayList<>();
		for (Student student : studentlist) {
			if(student.getId()==id){
				sortedList.add(student);
		}
		
	}
		return sortedList;

}
}
