package com.pennant.exams.files.bytes;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ReadAndWriteUsingBytes {
public static void main(String[] args) throws IOException {
	FileOutputStream fos=new FileOutputStream("examData.txt",true);
	DataOutputStream dos=new DataOutputStream(fos);
	String string="Hai, Gopal  Welcome to pennant";
	byte[] bytes=string.getBytes();
	dos.write(bytes);
	System.out.println("Writing to file is done...");
	dos.close();
	FileInputStream fis=new FileInputStream("examData.txt");
	DataInputStream dis=new DataInputStream(fis);
	
		@SuppressWarnings("deprecation")
		String data=dis.readLine();
	
	System.out.println(data);
	dis.close();
}
}
