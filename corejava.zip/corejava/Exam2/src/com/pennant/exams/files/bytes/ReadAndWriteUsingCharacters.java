package com.pennant.exams.files.bytes;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ReadAndWriteUsingCharacters {

	public static void main(String[] args) throws IOException {
		String string = "Welcome to my world";
		FileReader fr = new FileReader("examDataInCharacters.txt");
		BufferedReader br = new BufferedReader(fr);
		FileWriter fw = new FileWriter("examDataInCharacters.txt", true);
		BufferedWriter bw = new BufferedWriter(fw);
		char[] characters = string.toCharArray();
		bw.write(characters);
		System.out.println("Done writing...");
		bw.close();
		String st = br.readLine();
		System.out.println(st);
		br.close();

	}

}
