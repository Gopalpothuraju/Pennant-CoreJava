package com.pennant.exams.exceptions;

public class LeaveQuotaExceedingException extends Exception {

	
	private static final long serialVersionUID = 1L;
public LeaveQuotaExceedingException() {

}
	public String getLeaveQuotaExcedding(){
		return "As per company rules,Employee having 11 only.but you trying to apply more leaves.";
	}
}
