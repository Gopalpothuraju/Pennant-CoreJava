package com.pennant.exams.exceptions;

import java.util.Scanner;

public class Test {

	public static void main(String[] args)  {
		Scanner scanner=new Scanner(System.in);
		EmployeeLeave empLeave=new EmployeeLeave(344, "Gopal");
		boolean flag=true;
		while(flag){
			
				int wantLeaves;
				try {
					wantLeaves = empLeave.applyForLeave();
					if(wantLeaves!=0){
						System.out.println("Leaves Accepted..");
					}System.out.println("You want more leaves in this month..(yes or no)");
					String option=scanner.next();
					if(option.equalsIgnoreCase("yes")){
						flag=true;
					}else{
						flag=false;
					}
				} catch (LeaveQuotaExceedingException e) {
					System.err.println(e.getLeaveQuotaExcedding());
				}
				
				

		
					}
		scanner.close();
	}

}
