package com.pennant.exams.exceptions;

import java.util.Scanner;

public class EmployeeLeave {
	private static int noOfLeaves = 11;
	private int empId;
	private String name;
	private int wantLeaves;
	private int takenLeaves = 0;
	Scanner scanner = new Scanner(System.in);

	public EmployeeLeave(int empId, String name) {
		super();
		this.empId = empId;
		this.name = name;

	}

	public static int getNoOfLeaves() {
		return noOfLeaves;
	}

	public int getEmpId() {
		return empId;
	}

	public String getName() {
		return name;
	}

	public int getWantLeaves() {
		return wantLeaves;
	}

	public int applyForLeave() throws LeaveQuotaExceedingException {
		System.out.println("Enter no of day you want leave :");
		wantLeaves = scanner.nextInt();
		
		if (wantLeaves + takenLeaves <= noOfLeaves) {
			takenLeaves = wantLeaves;
			return wantLeaves;
		} else {

			throw new LeaveQuotaExceedingException();

		}
	}
}
