package com.pennant.db.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectiongToDataBase {
	public static Connection getConnectToDb() {
		Connection con=null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			 con = DriverManager.getConnection("jdbc:oracle:thin:@192.168.1.27:1521:orcl", "DB344",
					"pass123");

		} catch (ClassNotFoundException e) {
		
			e.printStackTrace();
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		return con;
	}
}
