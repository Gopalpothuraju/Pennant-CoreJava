package com.pennant.db.operations;

import java.sql.Connection;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.pennant.db.connection.ConnectiongToDataBase;
import com.pennant.db.tableoperations.AlteringTableData;
import com.pennant.db.tableoperations.CreatingTable;
import com.pennant.db.tableoperations.RetrivingTableNamesFromDB;

public class ApllicationInfo {
	public static void main(String[] args) throws Exception {
		Connection con = ConnectiongToDataBase.getConnectToDb();
		Scanner scanner = new Scanner(System.in);
		List<String> tables = new ArrayList<>();
		boolean flag = true;
		tables = RetrivingTableNamesFromDB.getTables(con);
		for (String string : tables) {
			System.out.println(string);
		}
		while (flag) {
			
			System.out.println("Select your operation:\n 1.Create Table \t 2.Alter Table \n 3.Delete Table \t 4.Insert Data \n 5.Modify Data \t 6.Delete Data \n Retrive Data \t 7.Exit");
			int option = scanner.nextInt();
			switch (option) {
			case 1:
				CreatingTable.creatingTable(con, tables);
				break;
			case 2:AlteringTableData.alteringTable(con, tables);
				break;
			case 3:System.out.println("Enter table name to delete ");
			     String tableName=scanner.next();
			     for (String string : tables) {
					if(string.equalsIgnoreCase(tableName)){
						Statement createStatement = con.createStatement();
						int executeUpdate = createStatement.executeUpdate("drop table "+tableName);
						System.out.println(tableName+"dropped"+executeUpdate);
					}
				}
				break;
			case 4:
				break;
			case 5:
				break;
			case 6:
				break;
			case 7:
				break;
			case 8:
				System.exit(0);
				break;
			default:
				System.err.println("please select appropiate option only...");
			}
			System.out.println("Do u want to continue on your table(y/n)");
			String value = scanner.next();
			if (value.equalsIgnoreCase("yes") || value.charAt(0) == 'y') {
				flag = true;
			} else {
				flag = false;
			}

		}
		scanner.close();
	}
}
