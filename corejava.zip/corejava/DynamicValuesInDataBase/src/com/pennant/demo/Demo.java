package com.pennant.demo;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Demo {
public static void main(String[] args) {
	List<String> tables=new ArrayList<>();
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@192.168.1.27:1521:orcl", "DB344", "pass123");
		 DatabaseMetaData dbmd = connection.getMetaData();
         String[] types = {"TABLE"};
         ResultSet rs = dbmd.getTables(null, null, "%", types);
         while (rs.next()) {
            tables.add(rs.getString("TABLE_NAME"));
         }
		
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
}
