import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Scanner;

public class CollableStatments {

	public static void main(String[] args) {
		Connection connetion=null;
		Scanner scanner=new Scanner(System.in);
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connetion=DriverManager.getConnection("jdbc:oracle:thin:@192.168.1.27:1521:orcl", "DB344", "pass123");
			CallableStatement prepareCall = connetion.prepareCall("{?= call additionOfNumbers(?,?)}");
			System.out.println("Enter 2 numbers : ");
			int number1=scanner.nextInt();
			int number2=scanner.nextInt();
			prepareCall.setInt(2, number1);
			prepareCall.setInt(3,number2);
			prepareCall.registerOutParameter(1, Types.NUMERIC);
			prepareCall.executeUpdate();
			System.out.println(prepareCall.getInt(1));
			
		} catch (ClassNotFoundException e) {
		
			e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		finally {
			scanner.close();
			try {
				connetion.close();
			} catch (SQLException e) {
			
				e.printStackTrace();
			}
		}
	}

}
