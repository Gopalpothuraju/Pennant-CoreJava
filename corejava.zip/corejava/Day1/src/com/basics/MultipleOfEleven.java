package com.basics;

import java.util.Scanner;

public class MultipleOfEleven {
	public static void main(String[] args) {
		int number;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number");
		number = sc.nextInt();
		if (number >= 0) {
			if (number % 11 == 0 || number % 11 == 1) {
				System.out.println("its special number");
			} else {
				System.out.println("its not special number");
			}
		}
	else{
		System.out.println("entered negative number");
	}
		sc.close();
}
} 