package com.basics;

public class PrintDigits {
	public static void main(String[] args) {
		int numberOne=2345;
		int resultOne=numberOne/1000;
		
		System.out.println(resultOne); 
		
		int remainderOne=numberOne%1000;
		
		int resultTwo=remainderOne/100;
		
		int remainderTwo=remainderOne%100;
		
		System.out.println(resultTwo); 
		
		int resultThree=remainderTwo/10;
		
		int remainderThree=remainderTwo%10;
		
		System.out.println(resultThree); 
		
		System.out.println(remainderThree);
		
		
	}
}
