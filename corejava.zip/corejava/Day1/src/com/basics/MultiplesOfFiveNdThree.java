package com.basics;

import java.util.Scanner;

public class MultiplesOfFiveNdThree {
public static void main(String[] args) {
	int number;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter number");
	number=sc.nextInt();
	if (number >= 0) {
	
	if(number%3==0 && number%5==0){
		System.out.println(false);
	}
	else if(number%3==0 || number%5==0){
		System.out.println(true);
	}
	else{
		System.out.println(false);
	}
	}else{
		System.out.println("entered negative number");
	}
	sc.close();
}
}
