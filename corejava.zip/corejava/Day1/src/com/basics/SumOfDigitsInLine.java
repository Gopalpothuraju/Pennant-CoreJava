package com.basics;

public class SumOfDigitsInLine {
public static void main(String[] args) {
	int numberOne=2345;
	System.out.println("Sum of Digits");
	System.out.println((numberOne/1000)+((numberOne%1000)/100)+(((numberOne%1000)%100)/10)+(numberOne%10));
	System.out.println("Individual Digits");
	System.out.println((numberOne/1000)+"\n"+((numberOne%1000)/100)+"\n"+(((numberOne%1000)%100)/10)+"\n"+(numberOne%10));
}
}
