package com.details.customer;

import java.util.Scanner;

import com.details.product.Product;

public class Customer {
	public int customerID;
	String customerName;
	long mobileNumber;
	String address;
	boolean membership=false;
	Product[] products;
	Scanner scanner = new Scanner(System.in);

	public Customer() {

	}

	public void customerDetails() {
		System.out.println("Enter your id:");
		customerID = scanner.nextInt();
		System.out.println("Enter your name : ");
		customerName = scanner.next();
		System.out.println("Enter mobile number : ");
		mobileNumber = scanner.nextLong();
		System.out.println("Enter your Address");
		address = scanner.next();
		System.out.println("Your have membership (true or false)");
		String member=scanner.next();
		if(member.equalsIgnoreCase("true")){
			membership=true;
		}

	}

	public int[] chooseProtsducToBuy(Product[] products) {
		boolean flag = true;
		int[] productId = new int[products.length];
		int i = 0;
		while (flag) {
			System.out.println("Continue with shoping..(yes / no)");
			String str = scanner.next();
			if (str.equalsIgnoreCase("yes")) {
				flag = true;
				System.out.println("Enter product id do you want");
				productId[i] = scanner.nextInt();
				i++;
			} else {
				flag = false;
			}

		}
		int[] selectedProducts=new int[i];
		for(int j=0;j<selectedProducts.length;j++){
			selectedProducts[j]=productId[j];
		}
		return selectedProducts;
	}
}
