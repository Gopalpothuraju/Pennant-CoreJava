package com.details.product;

public class Product {
	public int productID;
	public String productName;
	double price;
	String productType;
	double discount;
	public Product(int productID, String productName, double price, String productType, double discount) {
		super();
		this.productID = productID;
		this.productName = productName;
		this.price = price;
		this.productType = productType;
		this.discount = discount;
	}
	public  void getDetails(){
		
		
			System.out.println("  "+productID+" \t \t "+productName+" \t \t"+price+" \t \t "+productType+" \t \t "+discount);
		
	}
}
