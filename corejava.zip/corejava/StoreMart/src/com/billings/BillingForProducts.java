package com.billings;

import com.details.customer.Customer;
import com.details.product.Product;

public class BillingForProducts {

	public static void main(String[] args) {
		Product[] products=new Product[10];
		products[0]=new Product(111, "Rice",  34.5,"Grocery",0.2);
		products[1]=new Product(112, "tomato",34.5,"Grocery",0.2);
		products[2]=new Product(113, "Thumps Up",34.5,"Grocery",0.2);
		products[3]=new Product(114, "Brinjal",34.5,"Grocery",0.2);
		products[4]=new Product(115, "Soap",   34.5,"Grocery",0.2);
		products[5]=new Product(116, "Paste",  34.5,"Grocery",0.2);
		products[6]=new Product(117, "Onion",  34.5,"Grocery",0.2);
		products[7]=new Product(118, "Laddu",  34.5,"Grocery",0.2);
		products[8]=new Product(119, "ice cream",  34.5,"Grocery",0.2);
		products[9]=new Product(120, "Sprite", 34.5,"Grocery",0.2);
		System.out.println("welcome to grocery");
		System.out.println("Product ID \t Product Name \t Price \t \t Product Type \t discount");
		for(int i=0;i<products.length;i++){
			products[i].getDetails();
		}
		Customer[] customers=new Customer[10];
		customers[0]=new Customer();
		customers[0].customerDetails();
		
		int[] productIDs=customers[0].chooseProtsducToBuy(products);
	
		 for(int i=0;i<productIDs.length;i++){
			 System.out.println(productIDs[i]);
		 }
		 int mapping[][]=new int[products.length][2];
		 int customerId=customers[0].customerID;
		 for (int i = 0; i < productIDs.length; i++) {
			for(int j=0;j<=1;j++){
				if(j==0){
				mapping[i][j]=customerId;
				}else if(j==1){
					mapping[i][j]=productIDs[i];
				}
			}
		}
		 System.out.println("Customer ID \t ProductId");
		for (int i = 0; i < productIDs.length; i++) {
			for (int j = 0; j <=1; j++) {
				System.out.print(mapping[i][j]+" \t \t ");
			}
			System.out.println("\n");
		}

	}
	
}
