package com.pennant.jdbc.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.pennant.jdbc.employeedetails.Employee;

public class DataBaseConnection {
public static void main(String[] args)  {
	List<Employee> employeeList=new ArrayList<>();
	Scanner scanner=new Scanner(System.in);
	Connection connection=null;
	PreparedStatement prepareStatement=null;
	System.out.println("1.Insert 2.Delete 3.Update 4.Retreive");
	System.out.println("Enter your option: ");
	int option=scanner.nextInt();
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		 connection = DriverManager.getConnection("jdbc:oracle:thin:@192.168.1.27:1521:orcl", "DB344", "pass123");
	
		if(option==1){
			System.out.println("Enter employee details(id,name,salary,address)");
			int id=scanner.nextInt();
			String name=scanner.next();
			double salary=scanner.nextDouble();
			String address=scanner.next();
			 prepareStatement = connection.prepareStatement("insert into employee values(?,?,?,?)");
			 prepareStatement.setInt(1, id);
			 prepareStatement.setString(2, name);
			 prepareStatement.setDouble(3, salary);
			 prepareStatement.setString(4, address);
			int executeUpdate = prepareStatement.executeUpdate();
			System.out.println(executeUpdate+"rows effected");
		}else if(option==2){
			System.out.println("Select an option to delete employee...\n(1.Id \t 2.Name)");
			int value=scanner.nextInt();
			if(value==1){
			System.out.println("Enter employee id to delete : ");
			int id=scanner.nextInt();
			 prepareStatement = connection.prepareStatement("delete from employee where id=?");
			 prepareStatement.setInt(1, id);
			int executeUpdate = prepareStatement.executeUpdate();
			System.out.println(executeUpdate+"rows effected");
			}else if(value==2){
				System.out.println("Enter employee name to delete : ");
				String name=scanner.next();
				 prepareStatement = connection.prepareStatement("delete from employee where name=?");
				 prepareStatement.setString(1, name);
				int executeUpdate = prepareStatement.executeUpdate();
				System.out.println(executeUpdate+"rows effected");
			}
		}else if(option==3){
			System.out.println("Enter id to update details..");
			int id=scanner.nextInt();
			System.out.println("Which data you want to modify \t 1.name \t 2.salary \t 3.address");
			int value=scanner.nextInt();
			if(value==1){
				System.out.println("Enter name to modify");
				String name=scanner.next();
			
				prepareStatement = connection.prepareStatement("update employee set name=? where id=?");
				 prepareStatement.setString(1, name);
				 prepareStatement.setInt(2, id);
				int executeUpdate = prepareStatement.executeUpdate();
				System.out.println(executeUpdate+"rows effected");
			}else if(value==2){
				System.out.println("Enter salary to modify");
				int salary=scanner.nextInt();
				prepareStatement = connection.prepareStatement("update employee set salary=? where id=?");
				
				prepareStatement.setDouble(1, salary);
				 prepareStatement.setInt(2, id);
				int executeUpdate = prepareStatement.executeUpdate();
				System.out.println(executeUpdate+"rows effected");
			}else if(value==3){
				System.out.println("Enter location to modify");
				String address=scanner.next();
			
				prepareStatement = connection.prepareStatement("update employee set location=? where id=?");
				 prepareStatement.setString(1, address);
				 prepareStatement.setInt(2, id);
				int executeUpdate = prepareStatement.executeUpdate();
				System.out.println(executeUpdate+"rows effected");
			}
			
		}else if(option==4){
			 prepareStatement = connection.prepareStatement("select * from employee");
			ResultSet executeQuery = prepareStatement.executeQuery();
			while(executeQuery.next()){
				Employee employee=new Employee(executeQuery.getInt(1), executeQuery.getString(2), executeQuery.getDouble(3), executeQuery.getString(4));
				employeeList.add(employee);
			}
			Employee.displayEmployees(employeeList);
		}
	} catch (ClassNotFoundException e) {
		e.printStackTrace();
	} catch (SQLException e) {
		e.printStackTrace();
	}
	finally {
		try {
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		scanner.close();
	}
}
}
