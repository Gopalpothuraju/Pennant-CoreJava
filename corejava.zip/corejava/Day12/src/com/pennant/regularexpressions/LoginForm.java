package com.pennant.regularexpressions;

import java.util.Scanner;
import java.util.regex.Pattern;

public class LoginForm {

	public static void main(String[] args) {
		String userName;
		String password;
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter user name : ");
		userName=scanner.nextLine();
		
		System.out.println("Enter user password : ");
		password=scanner.nextLine();
		String userRegix="^[\\S][a-zA-z]{1}[a-zA-z0-9\\W]{0,20}[@]{1}[a-z]{0,8}[.]{1}[a-z]{2,3}$";
		String passRegix="^[\\S][a-zA-Z0-9@$_]{8,16}$";
		boolean flagUser=Pattern.matches(userRegix, userName);
		boolean flagPass=Pattern.matches(passRegix, password);
		if(flagUser && flagPass){
			System.out.println("Login");
		}
		else{
			System.out.println("not login");
		}
		
		scanner.close();
	}

}
//pothurajugopal1@gmail.com