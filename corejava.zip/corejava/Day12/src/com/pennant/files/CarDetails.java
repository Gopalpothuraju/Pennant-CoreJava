package com.pennant.files;

import java.util.Scanner;

public class CarDetails {
	Scanner scanner =new Scanner(System.in);
String carNumber;
String startMeter;
String endMeter;
public String details(){
	System.out.println("Enter car number");
	carNumber=scanner.nextLine();
	
	System.out.println("Enter car start meter");
	startMeter=scanner.next();
	scanner.nextLine();
	System.out.println("Enter car end meter");
	endMeter=scanner.next();
	String string=carNumber+"_"+startMeter+"_"+endMeter;
	return string;
}

}
