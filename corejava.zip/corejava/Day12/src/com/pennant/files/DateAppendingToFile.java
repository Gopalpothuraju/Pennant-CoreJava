package com.pennant.files;
 
import java.io.DataOutputStream;

import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class DateAppendingToFile {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws IOException {
		String date=null;
		Scanner scanner=new Scanner(System.in);
		CarDetails cd=new CarDetails();
		String[] fileNames=new String[3];
		FileOutputStream fos=null;
		DataOutputStream dos=null;
		for (int i = 0; i < fileNames.length; i++) {
			System.out.println("Enter date to create file(mm/dd/yyyy)");
			date=scanner.next();
			fileNames[i]="./abc("+new SimpleDateFormat("dd-MMM-yyyy").format(new Date(date))+").txt";
			 fos = new FileOutputStream(fileNames[i]);
			dos = new DataOutputStream(fos);
			String string=cd.details();
		
			dos.writeChars(string);
		}
	
		System.out.println("END");
		fos.close();
		dos.close();
		scanner.close();
	}

}
