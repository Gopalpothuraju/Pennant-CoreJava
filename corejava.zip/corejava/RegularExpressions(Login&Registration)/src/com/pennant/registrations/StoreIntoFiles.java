package com.pennant.registrations;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Scanner;

public class StoreIntoFiles {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws IOException {
		Scanner scanner = new Scanner(System.in);
		boolean flag = true;
		RegistrationForm registration = new RegistrationForm();
		FileOutputStream fos = new FileOutputStream("./registereduserdetails.txt", true);
		LoginForm logindata = new LoginForm();
		while (flag) {
			System.out.println("1.Registration \n 2.Login \n 3.Exit");
			int option = scanner.nextInt();

			switch (option) {
			case 1:

				String dataToStore = registration.userRegisteration();
				if (dataToStore != null) {
					byte b[] = dataToStore.getBytes();
					fos.write(b);
				} else {
					System.err.println("Please verify your details....");
				}

				System.out.println("do u want to continue(yes/no)");
				String value = scanner.next();
				if (value.equalsIgnoreCase("yes")) {
					flag = true;
				} else {
					flag = false;
				}

				break;

			case 2:
				int count = 0;
				String loginDetails = logindata.loginDetails();
				String[] split = loginDetails.split("\\_");
				FileInputStream fis = new FileInputStream("./registereduserdetails.txt");
				DataInputStream dis = new DataInputStream(fis);
				String dataFromFile;

				while ((dataFromFile = dis.readLine()) != null) {
					String[] strings = dataFromFile.split("\\_");
					if ((strings[0].equalsIgnoreCase(split[0])) && (strings[1].equalsIgnoreCase(split[1]))) {
						count++;
						System.out.println("Login succesfully...");
						flag = false;
						break;
					}
				}
				dis.close();
				fis.close();
				if (count == 0) {
					System.out.println("1.forget password \n 2.cancel");

					int value1 = scanner.nextInt();

					if (value1 == 1) {
						System.out.println("Enter your mobile number : ");
						String mobile = scanner.next();
						String dataFromFiles;

						RandomAccessFile rac = new RandomAccessFile("./registereduserdetails.txt", "rw");

						int count1 = 0;
						while ((dataFromFiles = rac.readLine()) != null) {

							String[] strings = dataFromFiles.split("\\_");
							if (mobile.equalsIgnoreCase(strings[2])) {
								count1++;
								String s = registration.forgetPassword(mobile);
								strings[1] = s;

								String str = strings[0]+"_" + strings[1] +"_"+ strings[2] + "\n";

								System.out.println("Password Changed...");

								byte b[] = str.getBytes();
								for (byte c : b) {
									fos.write(c);
								}
								/*
								 * int
								 * length1=(int)rac.getFilePointer()-strings[2].
								 * length()-strings[1].length()-1;
								 * 
								 * byte[] b=s.getBytes();
								 * System.out.println(length1);
								 * System.out.println(b.length);
								 * System.out.println(length1+b.length);
								 * 
								 * 
								 * rac.write(b, length1, length1+b.length);
								 * 
								 */

								flag = false;
								break;
							}
						}
						if (count1 == 0) {
							System.out.println("please check your number");
							flag = false;
						}
						rac.close();
					}
				} else {
					System.exit(0);
				}

				break;
			case 3:
				System.exit(0);
				break;
			default:
				System.err.println("please select appripiate option...");
			}

		}
		fos.close();
		scanner.close();
	}
}
/*
 * pothurajugopal@gmail.com gopalP@1426 9908922714
 * 
 * pothuraju@gmail.com gopiP@1426 7569216831
 * 
 * gopal@gmail.com maniP@1426 9492456998
 */
