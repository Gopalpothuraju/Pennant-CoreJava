package com.pennant.registrations;

import java.util.Scanner;

public class LoginForm {

	
		String userName;
		String password;
		Scanner scanner=new Scanner(System.in);
		public String loginDetails(){
			
		
		System.out.println("Enter user name : ");
		userName=scanner.nextLine();
		
		System.out.println("Enter user password : ");
		password=scanner.nextLine();
		String append=userName+"_"+password;
		//scanner.close();
		return append;
	}
		

}
//pothurajugopal1@gmail.com