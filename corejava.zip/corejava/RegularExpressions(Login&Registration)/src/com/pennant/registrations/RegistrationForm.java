package com.pennant.registrations;

import java.util.Random;
import java.util.Scanner;
import java.util.regex.Pattern;

public class RegistrationForm {
String email;
String password;
String mobileNumber;
Scanner scanner=new Scanner(System.in);
String emailPattern="^[\\S][a-zA-Z]{1}[\\w]{0,20}[@]{1}[a-z]{0,8}[.]{1}[a-z]{2,3}$";
String passwordPattern="^[\\S][a-zA-Z0-9@$_]{8,16}$";
String mobilePattern="^[0-9]{10}$";
String append=null;
public String userRegisteration(){
	
	System.out.println("Enter mail id : ");
	email=scanner.next();
	System.out.println("Enter your password : ");
	password=scanner.next();
	System.out.println("Enter mobile number : ");
	mobileNumber=scanner.next();
	
	boolean flagUser=Pattern.matches(emailPattern, email);
	boolean flagPass=Pattern.matches(passwordPattern, password);
	boolean flagMobile=Pattern.matches(mobilePattern, mobileNumber);
	if(flagUser && flagPass && flagMobile){
		append=email+"_"+password+"_"+mobileNumber+"\n";
	return append;
	}
	else{
		return null;
		
	}
	
}
public String forgetPassword(String mobile) {
	
	Random r=new Random();
	int otp=r.nextInt(999999);
	System.out.println("Enter your otp: \n");
	try {
		Thread.sleep(500);
		System.out.println(otp);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println("Enter your new password : ");
	password=scanner.next();
	boolean flagPass=Pattern.matches(passwordPattern, password);
	if(flagPass){
		append=password;
	}
	return append;
}
}
