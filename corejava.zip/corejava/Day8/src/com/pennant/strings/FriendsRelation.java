package com.pennant.strings;

public class FriendsRelation {
	public static void main(String[] args) {
		String[] strings = new String[8];
		strings[0] = "Rajesh";
		strings[1] = "Rajendra";
		strings[2] = "Rajeshwara";
		strings[3] = "Ramesh";
		strings[4] = "ramu";
		strings[5] = "rams";
		strings[6] = "rani";
		strings[7] = "rajeshrao ";
		friendsRelations(strings);
	}

	public static void friendsRelations(String[] strings) {

		boolean[] flag = new boolean[strings.length];
		String[] bestFriends = new String[strings.length];
		int indexBF = 0;
		String[] goodFriends = new String[strings.length];
		int indexGF = 0;
		String[] niceFriends = new String[strings.length];
		int indexNF = 0;
		for (int i = 0; i < strings.length; i++) {
			for (int j = i + 1; j < strings.length; j++) {
				if (strings[i].substring(0, 4).equalsIgnoreCase(strings[j].substring(0, 4))) {
					if (flag[i] == false) {
						bestFriends[indexBF] = strings[i];
						indexBF++;
						flag[i] = true;
					}
					if (flag[j] == false) {
						bestFriends[indexBF] = strings[j];
						indexBF++;
						flag[j] = true;
					}
				}

			}
		}
		for (int i = 0; i < strings.length; i++) {
			for (int j = i + 1; j < strings.length; j++) {
				if (strings[i].substring(0, 3).equalsIgnoreCase(strings[j].substring(0, 3))) {

					if (flag[i] == false) {

						goodFriends[indexGF] = strings[i];
						indexGF++;

						flag[i] = true;
					}
					if (flag[j] == false) {

						goodFriends[indexGF] = strings[j];
						indexGF++;

						flag[j] = true;
					}
				}
			}
		}
		for (int i = 0; i < strings.length; i++) {
			for (int j = i + 1; j < strings.length; j++) {
				if (strings[i].substring(0, 2).equalsIgnoreCase(strings[j].substring(0, 2))) {

					if (flag[i] == false) {

						niceFriends[indexNF] = strings[i];
						indexNF++;

						flag[i] = true;
					}
					if (flag[j] == false) {

						niceFriends[indexNF] = strings[j];
						indexNF++;

						flag[j] = true;
					}
				}
			}

		}
		
		
		
		for (int i = 0; i < indexBF; i++) {
			System.out.print(bestFriends[i]+" ");
		}if(indexBF>=3){
			System.out.println("Best Friends");
		}else{
			System.out.println("Not Friends");
		}
		
		for (int i = 0; i < indexGF; i++) {
			System.out.print(goodFriends[i]+" ");
		}if(indexGF>=3){
			System.out.println("Good Friends");
		}else{
			System.out.println("Not Friends");
		}

		for (int i = 0; i < indexNF; i++) {
			System.out.print(niceFriends[i]+" ");
		}if(indexNF>=3){
			System.out.println("Best Friends");
		}else{
			System.out.println("Not Friends");
		}

	}

}
