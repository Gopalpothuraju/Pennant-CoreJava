package com.pennant.exam.employeemanagementsystem;

import java.util.Scanner;


/*author : Gopal, Date :03/06/2019 ,Class Purpose : Operations for Employee. */

public class Employee {
	Scanner scanner = new Scanner(System.in);
	private int id;
	private String name;
	private double salary;

	public Employee() {

	}

	public Employee(int id, String name, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public double getSalary() {
		return salary;
	}

	// this method is used to insert new employees into data base.
	public Employee[] insertEmployee(Employee[] employees, int count) {
		System.out.println("Enter Employe id : ");
		id = scanner.nextInt();
		System.out.println("Enter Employee name : ");
		name = scanner.next();
		System.out.println("Enter Employe salary : ");
		salary = scanner.nextDouble();
		employees[count] = new Employee(id, name, salary);

		return employees;

	}

	// this method is used to update the employee and display here.
	public void updateEmployee(Employee[] employees,int count) {
		System.out.println("Enter Employe id : ");
		id = scanner.nextInt();
		for (int i = 0; i < count; i++) {
			if(id==employees[i].getId()){
				System.out.println("Enter Employee name : ");
				name = scanner.next();
				System.out.println("Enter Employe salary : ");
				salary = scanner.nextDouble();
				employees[i]=new Employee(id, name, salary);
			}
		}
		

		System.out.println("Employee Updated....");
		
		System.out.println("-----Updated Employee Details---");
	
		for (int i = 0; i < count; i++) {
			System.out.println("Id : "+employees[i].getId()+"\t Name : "+employees[i].getName()+"\t Salary : "+employees[i].getSalary());
			
		}
	}

	// this method is used to retrieve particular employee.

	public Employee retrieveEmployee(Employee[] employees, int employeeId,int count) {
		Employee emp = null;
		
		for (int i = 0; i < count; i++) {
			
			if (employeeId == employees[i].getId()) {
			
				emp = employees[i];
			}

		}
		return emp;

	}

	// this method is used to retrieve all the employee.
	public void retrieveEmployees(Employee[] employees,int count) {
		for (int i = 0; i < count; i++) {
			System.out.println("Id : "+employees[i].getId()+"\t Name : "+employees[i].getName()+"\t Salary : "+employees[i].getSalary());
		}
		
	}
	
}
