package com.pennant.exam.employeemanagementsystem;

import java.util.Scanner;

/*author : Gopal, Date :03/06/2019 ,Class Purpose : Storing Employee details and modifying operations. */

public class Test {

	public static void main(String[] args) {
		int count = 0;
		Scanner scanner = new Scanner(System.in);
		Employee employee = new Employee();
		Employee[] employees = new Employee[10];
		employees[count] = new Employee(344, "Gopal", 12500.00);
		count++;
		employees[count] = new Employee(345, "Suraj", 12500.00);
		count++;
		employees[count] = new Employee(343, "Chandu", 12500.00);
		count++; 

		System.out.println("1.Insert Employee \t 2.Update Employee \n 3.Retrieve Employee \t 4.Retrieve Employees ");
		int option = scanner.nextInt();
		switch (option) {

		case 1:
		Employee[]	emp = employee.insertEmployee(employees, count);
			System.out.println("-----Employee Details(inserted)----");
			for (int i = 0; i <= count; i++) {

				System.out.println("Id : " + emp[i].getId() + "\t Name : " + emp[i].getName() + "\t Salary : "
						+ emp[i].getSalary());
			}

			break;
		case 2:
			employee.updateEmployee(employees,count);
			break;
		case 3:
			System.out.println("Enter your id to retrieve details");
			int employeeId = scanner.nextInt();
			employee = employee.retrieveEmployee(employees, employeeId,count);
			System.out.println(
					"Id : " + employee.getId() + "\t Name : " + employee.getName() + "\t Salary : " + employee.getSalary());
			break;
		case 4:
			employee.retrieveEmployees(employees,count);
			break;
		default:
			System.exit(0);

		}

		scanner.close();
	}

}
