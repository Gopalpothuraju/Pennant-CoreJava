package com.pennant.exam.span;

/*author : Gopal, Date :03/06/2019 ,Class Purpose : Print the length of largest span. */
public class LargestSpanFound {

	public static void main(String[] args) {

		// int[] array={1,2,1,1,3};
		 int[] array={1,4,2,1,4,1,4};
		//int[] array = { 1, 4, 2, 1, 4, 4, 4 };

		int length = maxSpan(array);
		System.out.println(length);
	}

	// methods will return the largest length of span
	public static int maxSpan(int[] array) {
		int temporary = array[0];
		int count = 0;
		for (int i = array.length - 1; i > 0; i--) {
			if (temporary == array[i]) {
				count = i;
				break;
			}
		}
		// TODO Auto-generated method stub
		return count + 1;
	}

}
