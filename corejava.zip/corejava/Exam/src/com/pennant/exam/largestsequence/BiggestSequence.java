package com.pennant.exam.largestsequence;
/*author : Gopal, Date :03/06/2019 ,Class Purpose : Print the biggestSequence. */

public class BiggestSequence {
public static void main(String[] args) {
	
//	int[] array={1,2,3,67,34,2,1};
//	int[] array={1,2,3,67,34,5,6,7,8,1,2};
	int[] array={1,2,3,56,57,58,59,60,61,7,8};
	int length=bigSequence(array);
	System.out.println(length);
}
//this method will print length of the biggest sequence
public static int bigSequence(int[] array) {
	int length = 0;
	for (int i = 0; i < array.length; i++) {
		int count1 = 1;
		for (int j = i + 1; j < array.length; j++) {
			if (array[i]+1==array[j]) {
			count1++;
			break;
			}
			if (count1 > length) {
				length = count1;
			}
		}
	}

	return length+1;
}
}
