package com.pennant.exam.matrixform;

public class SquareMatrix {
	public static void main(String[] args) {
		int n = 4;
		int[][] array = squareUp(n);
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array.length; j++) {
				System.out.print(array[i][j] + " ");
			}
			System.out.println();
		}
	}

	public static int[][] squareUp(int n) {
		int[][] array = new int[n][n];
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array.length; j++) {
				if(i==0){
					if(j==array.length-1){
						array[i][j]=1;
					}else{
						array[i][j]=0;
					}
				}
			}
		}

		return array;

	}
}
