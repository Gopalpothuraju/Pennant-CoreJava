package com.pennant.exam.mirror;
/*author : Gopal, Date :03/06/2019 ,Class Purpose : Print the mirror length. */

public class Mirror {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array={1,2,3,8,9,3,2,1};
		//int[] array={7,1,2,9,7,2,1};
		int length=maxMirror(array);
		System.out.println(length);
	}
	//this method will returns the length of the mirror
	public static int maxMirror(int[] array) {
		int[] temporaryArray=new int[array.length];
		int index=0;
		int length=0;
		int count=0;
		for(int i=0;i<array.length-1;i++){
			
			if(array[i]+1==array[i+1]){
				count++;
				if(index==0){
				temporaryArray[index]=array[i];
				index++;
				
				}
				temporaryArray[index]=array[i+1];
				index++;
			}else if(count!=0){
				break;
			}
		}
		
		for (int i = 0; i <index; i++) {
			for (int j = array.length-1; j >0 ; j--) {
				if(array[j]==temporaryArray[i]){
					
					length++;
					break;
				}
			}
		}
		
	
	return length;
		
	}

}
