package com.arrays;

public class DefineDeclareInitialArray {

	public static void main(String[] args) {

		int array1[];
		array1 = new int[5];
		array1[0] = 10;
		array1[1] = 20;
		array1[2] = 30;
		System.out.println("intial nd declare define done in 3 line");
		for (int i = 0; i < array1.length; i++) {
			System.out.print(array1[i] + " ");
		}

		System.out.println("\n intial nd declare define done in 2 line");
		int[] array2 = new int[5];
		for (int i = 0; i < array2.length; i++) {
			array2[i] = i * i + (i * (i + i));
			System.out.print(array2[i] + " ");
		}
		System.out.println("\n intial nd declare define done in 1 line");

		int[] array3 = { 23, 45, 65, 67 };
		for (int i = 0; i < array3.length; i++) {
			System.out.print(array3[i] + " ");
		}
	}

}
