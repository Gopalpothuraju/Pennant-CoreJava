package com.arrays;

public class ClumpsInArray {

	public static void main(String[] args) {
		int[] array = { 1, 2, 2, 3, 3, 5, 4, 4, 4, 6, 6, 9, 8, 9, 9 };

		int clumps = 0;
		for (int i = 0; i < array.length; i++) {
			int count = 0;
			for (int j = i + 1; j < array.length; j++) {
				if (array[i] != array[j]) {
					i = j - 1;
					break;
				} else if (array[i] == array[j]) {

					count++;
				}
			}
			if (count != 0) {
				clumps++;
			}
		}
		System.out.println(clumps+" clumps");
	}

}
