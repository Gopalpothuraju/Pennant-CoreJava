package com.arrays;

public class Duplicates {

	public static void main(String[] args) {
		int[] array = { 1,3,4,1,3,5 };
		System.out.println("length of initial array"+array.length);
		int count=0;
		int temp = 0;
		int flag = 0;
		System.out.print("Initial array : ");
		for(int i=0;i<array.length;i++){
			System.out.print(array[i]);
		}
		System.out.println("\n");
		for(int i = 0; i < array.length; i++) {
			for (int j = i + 1; j < array.length; j++) {

				if (array[i] > array[j]) {
					flag = array[i];

					array[i] = array[j];
					array[j] = flag;
				}
			}
		}for (int i = 0; i < array.length; i++) {
		
			for (int j = i + 1; j < array.length; j++) {
				if (array[i] != array[j]) {
					i = j - 1;
					break;
				} else if (array[i] == array[j]) {

					count++;
				}
			}
		}
		int[] finalArray = new int[array.length-count];
		for (int i = 0; i < array.length - 1; i++) {
			//int j = i + 1;
			if (array[i] == array[i+1]) {
				continue;
			} else {
				finalArray[temp] = array[i];
				++temp;

			}
		}
		
		finalArray[temp] = array[array.length - 1];
		
		
		System.out.println("length of the final array : "+finalArray.length);
		System.out.print("Final array : ");
		for (int a : finalArray) {
			System.out.print(a);
		}
	}

}
