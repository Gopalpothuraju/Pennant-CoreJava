package com.arrays;

public class SubsetOfArrays {

	public static void main(String[] args) {
		int[] array = { 1, 2, 4, 5, 2, 4, 6, 3, 2, 3, 4, 10 }; // {1,2,4,6 };

		int[] subarray = { 2, 4, 3, 10, 1, 5, 6,8 }; // { 4, 2 };

		int count = 0;

		if (array.length >= subarray.length) {

			for (int i = 0; i < array.length; i++) {
				for (int j = i + 1; j < array.length; j++) {
					if (array[i] == array[j]) {
						array[j] = 0;
					}
				}
			}

			for (int i = 0; i < subarray.length; i++) {
				for (int j = 0; j < array.length; j++) {
					if (array[j] == subarray[i]) {
						count++;
					}
				}
			}
			if (count == subarray.length) {
				System.out.println(true);
			} else {
				System.out.println(false);
			}

		} else {
			System.out.println(false);
		}

	}
}
