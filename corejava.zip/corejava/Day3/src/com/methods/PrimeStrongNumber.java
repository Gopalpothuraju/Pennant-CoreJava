package com.methods;

import java.util.Scanner;

public class PrimeStrongNumber {
	
	static boolean primeNumber(int number) {
		
		boolean value = false;
		int count = 0;

		for (int i = 1; i <= number; i++) {
			if (number % i == 0) {
				count++;
			}
		}
		if (count == 2) {
			value = true;
		} else {
			value = false;
		}
		return value;

	}

	static boolean factorial(int number) {
		boolean value = false;
		
		if (primeNumber(number)) {
			int res;
			int sum = 0;// 120
			int fact;
			int fnumber = number;
			while (number != 0) {
				res = number % 10; // 5//4
				fact = 1;
				for (int i = 1; i <= res; i++) {

					fact = fact * i; // 1//2-//6//24---120

				}
				sum=sum(sum, fact);
				
				number /= 10;

			}
			if (sum == fnumber) {
				value = true;
			} else {
				value = false;
			}
		}
		return value;

	} 

	static int sum(int sum, int fact) {
		sum = sum + fact;
		return sum;
	}

	public static void main(String[] args) {
		int number;
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter number");
		number = sc.nextInt();
		
		boolean flag=factorial(number);
		if(flag){
			System.out.println("Its is prime strong number");
		}else{
			System.out.println("Its is not prime strong number");
		}
		sc.close();
	}

}
